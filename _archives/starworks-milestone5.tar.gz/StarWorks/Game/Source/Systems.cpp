#include "Systems.hpp"

#include <cmath>

namespace game
{
    void SnapshotSystem::update(sw::ecs::World& world, sw::f32 /*deltaSeconds*/)
    {
        world.forEach<TransformComponent, PreviousTransformComponent>(
            [](sw::ecs::Entity, const TransformComponent& transform,
               PreviousTransformComponent& previous) {
                previous.position = transform.position;
                previous.rotation = transform.rotation;
            });
    }

    void DebrisFlowSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<DebrisComponent, OrbitComponent>(
            [deltaSeconds](sw::ecs::Entity, DebrisComponent& debris, OrbitComponent& orbit) {
                debris.modulationPhase += 0.35f * deltaSeconds;
                if (debris.modulationPhase > sw::math::kTwoPi)
                {
                    debris.modulationPhase -= sw::math::kTwoPi;
                }
                // ±2% only: at orbital angular velocities, larger deviations
                // would shear the debris cluster apart within minutes.
                orbit.radiansPerSecond =
                    debris.baseOrbitSpeed *
                    (1.0 + 0.02 * static_cast<sw::f64>(std::sin(debris.modulationPhase)));
            });
    }

    void StatsSystem::update(sw::ecs::World& world, sw::f32 /*deltaSeconds*/)
    {
        // Every 30 ticks of the 1 Hz World lane ≈ every 30 simulated seconds.
        if ((m_ticks++ % 30) == 0)
        {
            SW_LOG_INFO("Game", "[World lane] tick {}: {} entities alive", m_ticks - 1,
                        world.aliveCount());
        }
    }

    void OrbitSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        const sw::f64 dt = static_cast<sw::f64>(deltaSeconds);
        world.forEach<TransformComponent, OrbitComponent>(
            [dt](sw::ecs::Entity, TransformComponent& transform, OrbitComponent& orbit) {
                orbit.phase += orbit.radiansPerSecond * dt;
                if (orbit.phase > static_cast<sw::f64>(sw::math::kTwoPi))
                {
                    orbit.phase -= static_cast<sw::f64>(sw::math::kTwoPi);
                }

                // Full f64: orbital radii are in the millions of meters.
                transform.position =
                    orbit.center +
                    sw::WorldVec3{orbit.radius * std::cos(orbit.phase),
                                  orbit.verticalWobble * std::sin(orbit.phase * 2.0),
                                  orbit.radius * std::sin(orbit.phase)};
            });
    }

    void SpinSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, SpinComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           const SpinComponent& spin) {
                const sw::Quat step =
                    glm::angleAxis(spin.radiansPerSecond * deltaSeconds, spin.axis);
                transform.rotation = glm::normalize(step * transform.rotation);
            });
    }
} // namespace game
