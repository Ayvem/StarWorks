#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 5: REAL astronomical scale.
//
//  - Terra: radius 6,371 km at the origin; Luna: radius 1,737 km at
//    384,400 km — true real-world dimensions (f64 world coordinates).
//  - The player starts in low orbit (400 km) inside a debris belt of
//    thousands of instanced objects around a station cluster.
//  - Celestial bodies pick their sphere LOD from their ANGULAR size, so a
//    distant moon costs a few dozen triangles while the planet below shows
//    its full silhouette.
//  - The renderer receives camera-relative DrawItems and performs frustum
//    culling + one instanced draw per mesh.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        [[nodiscard]] CelestialLodComponent makeSphereLodSet(const sw::Vec4& color);
        void buildScene();
        void collectDrawItems();
        [[nodiscard]] sw::u32 selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const;

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Mesh table: components reference meshes by index (asset-ID
        // precursor; becomes the Assets registry in a later milestone).
        std::vector<sw::Mesh> m_meshes;

        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation

        std::vector<sw::DrawItem> m_drawItems;
        sw::f64 m_lastStatsLogSeconds = 0.0;
    };
} // namespace game
