#pragma once

// ============================================================================
// Components.hpp — game-side ECS components.
//
// The game runs at REAL astronomical scale: world positions are f64
// (sw::WorldVec3) everywhere. Rendering narrows to f32 only after
// subtracting the camera position (see StarWorksGame::collectDrawItems).
//
// All components follow the engine rule: trivially copyable, no owning
// members. Meshes are referenced by index into the game's mesh table (an
// asset-ID precursor), never by pointer — save-file friendly by design.
// ============================================================================

#include <Engine.hpp>

namespace game
{
    struct TransformComponent
    {
        sw::WorldVec3 position{0.0};
        sw::Quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
        /// Uniform scale in meters (meshes are authored at unit size).
        sw::f32 uniformScale = 1.0f;
    };

    /// Snapshot of the transform at the PREVIOUS Physics tick. Written by
    /// SnapshotSystem at the start of each tick; the renderer interpolates
    /// between this and TransformComponent using the Physics lane's alpha.
    struct PreviousTransformComponent
    {
        sw::WorldVec3 position{0.0};
        sw::Quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
    };

    /// Bounding sphere radius in mesh-local units (world radius =
    /// localRadius * uniformScale). Used for frustum culling.
    struct BoundsComponent
    {
        sw::f32 localRadius = 1.0f;
    };

    /// Constant-rate self rotation around a fixed axis.
    struct SpinComponent
    {
        sw::Vec3 axis{0.0f, 1.0f, 0.0f};
        sw::f32 radiansPerSecond = 1.0f;
    };

    /// Circular orbit around a fixed center (placeholder until real orbital
    /// mechanics arrive with the Physics module). Full f64: orbital radii
    /// reach millions of meters.
    struct OrbitComponent
    {
        sw::WorldVec3 center{0.0};
        sw::f64 radius = 5.0;
        sw::f64 radiansPerSecond = 0.3;
        sw::f64 phase = 0.0; // current angle, integrated each tick
        sw::f64 verticalWobble = 0.0;
    };

    /// Logistics-lane data: modulates a debris orbit speed over time.
    struct DebrisComponent
    {
        sw::f64 baseOrbitSpeed = 0.001;
        sw::f32 modulationPhase = 0.0f;
    };

    /// Fixed-mesh renderable (index into the game mesh table).
    struct MeshComponent
    {
        sw::u32 meshIndex = 0;
    };

    /// Celestial body renderable with distance-based level of detail:
    /// meshes[0] is the most detailed sphere, meshes[kLodLevels-1] the
    /// coarsest. The level is chosen from the body's ANGULAR size on screen,
    /// so a moon 384,000 km away costs a few dozen triangles while the
    /// planet you are orbiting gets full geometry. (The Planet module's
    /// quadtree surface will later replace level 0 near the ground.)
    struct CelestialLodComponent
    {
        static constexpr sw::u32 kLodLevels = 5;
        sw::u32 meshIndex[kLodLevels] = {0, 0, 0, 0, 0};
    };

    static_assert(std::is_trivially_copyable_v<TransformComponent>);
    static_assert(std::is_trivially_copyable_v<PreviousTransformComponent>);
    static_assert(std::is_trivially_copyable_v<BoundsComponent>);
    static_assert(std::is_trivially_copyable_v<SpinComponent>);
    static_assert(std::is_trivially_copyable_v<OrbitComponent>);
    static_assert(std::is_trivially_copyable_v<DebrisComponent>);
    static_assert(std::is_trivially_copyable_v<MeshComponent>);
    static_assert(std::is_trivially_copyable_v<CelestialLodComponent>);
} // namespace game
