#pragma once

// ============================================================================
// Engine.hpp
// Public umbrella header for game code. Games include this single header;
// the engine's internal headers stay free to reorganize underneath it.
// ============================================================================

#include "Assets/GltfLoader.hpp"
#include "Assets/MeshData.hpp"
#include "Assets/PrimitiveFactory.hpp"
#include "Core/Application.hpp"
#include "Core/Assert.hpp"
#include "Core/Clock.hpp"
#include "Core/Error.hpp"
#include "Core/FileSystem.hpp"
#include "Core/Log.hpp"
#include "Core/ThreadPool.hpp"
#include "Core/Types.hpp"
#include "ECS/CommandBuffer.hpp"
#include "ECS/System.hpp"
#include "ECS/SystemScheduler.hpp"
#include "ECS/World.hpp"
#include "Input/Input.hpp"
#include "Math/Frustum.hpp"
#include "Math/Math.hpp"
#include "Platform/Window.hpp"
#include "Simulation/Simulation.hpp"
#include "Renderer/Mesh.hpp"
#include "Renderer/Renderer.hpp"
#include "Scene/Camera.hpp"
#include "Scene/FreeCameraController.hpp"
