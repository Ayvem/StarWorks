#pragma once

// ============================================================================
// Renderer/Renderer.hpp
// Renderer front-end: owns the Vulkan objects and the frame loop's GPU side.
//
// Mass-rendering pipeline (Milestone 5):
//  1. The game submits DrawItems (mesh + camera-relative transform + bounding
//     sphere) — positions were narrowed from f64 world space by the caller.
//  2. CPU frustum culling rejects everything outside the view.
//  3. Survivors are sorted by mesh and written to a per-frame storage buffer
//     of instance transforms; ONE indexed draw is issued per distinct mesh
//     (vertex shader reads its matrix via gl_InstanceIndex).
// GPU culling / indirect draws will slot in behind this same DrawItem API.
//
// Frame model: kFramesInFlight (2) frames in a ring; per frame: command
// pool + buffer, acquire semaphore, fence, camera UBO, instance SSBO and a
// descriptor set. Per swapchain image: a render-finished semaphore.
// Depth: reverse-Z (clear 0, GREATER) — mandatory at planetary scales.
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Frustum.hpp"
#include "Math/Math.hpp"
#include "Renderer/Mesh.hpp"
#include "Renderer/Vulkan/VulkanMemory.hpp"

#include <vulkan/vulkan.h>

#include <array>
#include <memory>
#include <span>
#include <string>
#include <vector>

namespace sw
{
    class Window;
    class Camera;
} // namespace sw

namespace sw::vulkan
{
    class VulkanInstance;
    class VulkanDevice;
    class VulkanSwapchain;
    class VulkanPipeline;
} // namespace sw::vulkan

namespace sw
{
    struct RendererConfig
    {
        std::string applicationName = "StarWorks";
        bool enableValidation =
#if defined(SW_DEBUG)
            true;
#else
            false;
#endif
        /// Prefer a CPU/software Vulkan implementation (llvmpipe, SwiftShader)
        /// over hardware GPUs during device selection. Rendering code is
        /// identical either way — this only inverts the selection scoring.
        bool preferCpuDevice = false;
    };

    /// One draw request, in CAMERA-RELATIVE space (see Camera).
    struct DrawItem
    {
        const Mesh* mesh = nullptr;
        Mat4 transform{1.0f};
        /// Bounding sphere for frustum culling, camera-relative center.
        Vec3 boundsCenter{0.0f};
        f32 boundsRadius = 0.0f;
    };

    struct RenderStats
    {
        u32 itemsSubmitted = 0;
        u32 itemsCulled = 0;
        u32 instancesDrawn = 0;
        u32 drawCalls = 0;
        /// CPU milliseconds spent in renderFrame (fence wait included /
        /// excluded) — the difference exposes GPU-bound frames.
        f32 cpuFenceWaitMs = 0.0f;
        f32 cpuPrepareMs = 0.0f; // culling + sort + instance upload
        f32 cpuTotalMs = 0.0f;
    };

    class Renderer
    {
    public:
        static constexpr u32 kFramesInFlight = 2;

        Renderer(Window& window, const RendererConfig& config);
        ~Renderer();

        Renderer(const Renderer&) = delete;
        Renderer& operator=(const Renderer&) = delete;
        Renderer(Renderer&&) = delete;
        Renderer& operator=(Renderer&&) = delete;

        /// Uploads a CPU mesh to the GPU. Valid for the renderer's lifetime.
        [[nodiscard]] Mesh createMesh(const MeshData& data);

        /// Culls, batches and submits one frame. Handles swapchain
        /// recreation internally; never throws on recoverable paths.
        void renderFrame(const Camera& camera, std::span<const DrawItem> items);

        /// Statistics of the most recently submitted frame.
        [[nodiscard]] const RenderStats& stats() const { return m_stats; }

        /// Called by the Application when the framebuffer size changes.
        void onFramebufferResized(u32 width, u32 height);

        /// Direction TOWARD the scene from the sun (world space, normalized).
        void setSunDirection(const Vec3& direction);

        /// Blocks until the GPU has finished all submitted work.
        void waitIdle() const;

        [[nodiscard]] f32 aspectRatio() const;

    private:
        /// Layout must match the Camera uniform block in Shaders/Mesh.vert.
        struct CameraUniforms
        {
            Mat4 viewProjection{1.0f};
            Vec4 cameraPosition{0.0f}; // (0,0,0): rendering is camera-relative
            Vec4 sunDirection{0.0f, -1.0f, 0.0f, 0.0f};
        };

        /// Per-instance GPU data (std430 layout in Shaders/Mesh.vert).
        struct InstanceData
        {
            Mat4 model{1.0f};
        };

        struct FrameResources
        {
            VkCommandPool commandPool = VK_NULL_HANDLE;
            VkCommandBuffer commandBuffer = VK_NULL_HANDLE;
            VkSemaphore imageAvailable = VK_NULL_HANDLE;
            VkFence inFlight = VK_NULL_HANDLE;
            vulkan::VulkanBuffer cameraUbo;     // persistently mapped
            vulkan::VulkanBuffer instanceBuffer; // persistently mapped SSBO
            u32 instanceCapacity = 0;
            VkDescriptorSet descriptorSet = VK_NULL_HANDLE;
        };

        struct DrawBatch
        {
            const Mesh* mesh = nullptr;
            u32 firstInstance = 0;
            u32 instanceCount = 0;
        };

        void createDepthResources();
        void createDescriptorResources();
        void destroyDescriptorResources();
        void createFrameResources();
        void destroyFrameResources();
        void createSwapchainSemaphores();
        void destroySwapchainSemaphores();
        void recreateSwapchain();
        void ensureInstanceCapacity(FrameResources& frame, u32 required);
        void writeFrameDescriptorSet(FrameResources& frame) const;

        /// Culling + mesh sort + instance upload; fills m_batches.
        void prepareBatches(FrameResources& frame, const Camera& camera,
                            std::span<const DrawItem> items);
        void recordCommands(VkCommandBuffer cmd, u32 imageIndex,
                            const FrameResources& frame) const;
        [[nodiscard]] VkFormat findDepthFormat() const;

        Window& m_window;

        std::unique_ptr<vulkan::VulkanInstance> m_instance;
        VkSurfaceKHR m_surface = VK_NULL_HANDLE;
        std::unique_ptr<vulkan::VulkanDevice> m_device;
        // m_memory must outlive every buffer/image below (declaration order
        // drives destruction order — do not reorder).
        std::unique_ptr<vulkan::VulkanMemory> m_memory;
        std::unique_ptr<vulkan::VulkanSwapchain> m_swapchain;
        vulkan::VulkanImage m_depthImage;
        std::unique_ptr<vulkan::VulkanPipeline> m_meshPipeline;

        VkDescriptorSetLayout m_descriptorSetLayout = VK_NULL_HANDLE;
        VkDescriptorPool m_descriptorPool = VK_NULL_HANDLE;

        std::array<FrameResources, kFramesInFlight> m_frames{};
        /// One per swapchain image, signaled when rendering to it completes.
        std::vector<VkSemaphore> m_renderFinished;

        // Per-frame scratch (persistent to avoid reallocation).
        std::vector<u32> m_visibleIndices;
        std::vector<DrawBatch> m_batches;
        RenderStats m_stats{};

        Vec3 m_sunDirection{-0.45f, -0.8f, -0.4f};
        u32 m_currentFrame = 0;
        bool m_framebufferResized = false;
        u32 m_pendingWidth = 0;
        u32 m_pendingHeight = 0;
    };
} // namespace sw
