#include "StarWorksGame.hpp"

namespace game
{
    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.1f, 10000.0f);
        // Start a few units back so the triangle (at the origin) is in view.
        m_cameraController.setPose({0.0f, 0.0f, 3.0f}, 0.0f, 0.0f);

        SW_LOG_INFO("Game", "Controls: RMB + mouse = look, WASD = move, Q/E = down/up, "
                            "Shift = boost, wheel = speed, Esc = quit");
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        m_cameraController.update(input(), window(), deltaSeconds);
        m_camera.setAspectRatio(renderer().aspectRatio());
    }

    void StarWorksGame::onRender()
    {
        renderer().renderFrame(m_camera);
    }
} // namespace game
