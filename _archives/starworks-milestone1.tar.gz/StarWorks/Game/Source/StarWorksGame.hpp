#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Owns game-side state (for now: a camera and its
// controller) and drives the engine through the Application hooks.
// ============================================================================

#include <Engine.hpp>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;
    };
} // namespace game
