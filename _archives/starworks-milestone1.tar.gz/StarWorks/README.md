# StarWorks

An industrial space simulation game — mine, automate, build ships and stations, and grow a civilization that spans a star system. Powered by a bespoke C++20 / Vulkan engine written exclusively for this game.

## Current state — Milestone 1: Engine Bootstrap

The project opens a window, initializes modern Vulkan (1.3, dynamic rendering, synchronization2) and renders a triangle in world space with a free-fly camera.

Included systems: logging, assertions/error handling, high-precision frame clock, GLFW window layer, input snapshots, perspective camera + free camera controller, swapchain with live resize, build-time GLSL → SPIR-V compilation.

## Requirements

- CMake ≥ 3.24
- A C++20 compiler (Visual Studio 2022 on Windows, GCC 13+/Clang 16+ on Linux)
- The [Vulkan SDK](https://vulkan.lunarg.com/) (headers, loader, glslangValidator, validation layers)
- A GPU + driver supporting Vulkan 1.3

GLFW 3.4 and GLM 1.0.1 are fetched and built automatically by CMake.

## Building (Windows / Visual Studio 2022)

```powershell
cmake --preset windows-msvc
cmake --build --preset windows-debug
build\windows\bin\Debug\StarWorks.exe
```

Or open `build/windows/StarWorks.sln` in Visual Studio and run the `StarWorks` startup project (F5).

## Building (Linux)

```bash
cmake --preset linux-debug
cmake --build --preset linux-debug -j
./build/linux-debug/bin/StarWorks
```

## Controls

Hold the right mouse button to look around. `WASD` to move, `Q`/`E` down/up, `Shift` to boost, mouse wheel to change speed, `Esc` to quit.

## Useful flags

`--frames N` exits after N frames (soak testing); `--log-file path.log` mirrors the log to a file.

## Repository layout

See `docs/Architecture.md` for the module map, engineering conventions, and the development log.
