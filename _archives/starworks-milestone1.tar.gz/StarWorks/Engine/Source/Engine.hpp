#pragma once

// ============================================================================
// Engine.hpp
// Public umbrella header for game code. Games include this single header;
// the engine's internal headers stay free to reorganize underneath it.
// ============================================================================

#include "Core/Application.hpp"
#include "Core/Assert.hpp"
#include "Core/Clock.hpp"
#include "Core/Error.hpp"
#include "Core/Log.hpp"
#include "Core/Types.hpp"
#include "Input/Input.hpp"
#include "Math/Math.hpp"
#include "Platform/Window.hpp"
#include "Renderer/Renderer.hpp"
#include "Scene/Camera.hpp"
#include "Scene/FreeCameraController.hpp"
