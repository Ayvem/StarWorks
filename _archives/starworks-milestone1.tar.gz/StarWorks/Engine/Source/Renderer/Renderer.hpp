#pragma once

// ============================================================================
// Renderer/Renderer.hpp
// Renderer front-end: owns the Vulkan objects and the frame loop's GPU side.
//
// Frame model:
//  - kFramesInFlight (2) frames are recorded/submitted in a ring so the CPU
//    prepares frame N+1 while the GPU renders frame N.
//  - Per frame in flight: command pool + primary command buffer,
//    an image-acquire semaphore and an in-flight fence.
//  - Per swapchain image: a render-finished semaphore (indexed by image, as
//    required for correct present synchronization).
//
// This class will shrink over time: pass orchestration moves to RenderGraph,
// resources to Assets/RHI wrappers. Its public surface is already minimal so
// that migration will not ripple through game code.
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Math.hpp"

#include <vulkan/vulkan.h>

#include <array>
#include <memory>
#include <string>
#include <vector>

namespace sw
{
    class Window;
    class Camera;
} // namespace sw

namespace sw::vulkan
{
    class VulkanInstance;
    class VulkanDevice;
    class VulkanSwapchain;
    class VulkanPipeline;
} // namespace sw::vulkan

namespace sw
{
    struct RendererConfig
    {
        std::string applicationName = "StarWorks";
        bool enableValidation =
#if defined(SW_DEBUG)
            true;
#else
            false;
#endif
    };

    class Renderer
    {
    public:
        static constexpr u32 kFramesInFlight = 2;

        Renderer(Window& window, const RendererConfig& config);
        ~Renderer();

        Renderer(const Renderer&) = delete;
        Renderer& operator=(const Renderer&) = delete;
        Renderer(Renderer&&) = delete;
        Renderer& operator=(Renderer&&) = delete;

        /// Records and submits one frame. Handles swapchain recreation
        /// (resize, out-of-date) internally; never throws on those paths.
        void renderFrame(const Camera& camera);

        /// Called by the Application when the framebuffer size changes.
        void onFramebufferResized(u32 width, u32 height);

        /// Blocks until the GPU has finished all submitted work.
        void waitIdle() const;

        [[nodiscard]] f32 aspectRatio() const;

    private:
        struct FrameResources
        {
            VkCommandPool commandPool = VK_NULL_HANDLE;
            VkCommandBuffer commandBuffer = VK_NULL_HANDLE;
            VkSemaphore imageAvailable = VK_NULL_HANDLE;
            VkFence inFlight = VK_NULL_HANDLE;
        };

        void createFrameResources();
        void destroyFrameResources();
        void createSwapchainSemaphores();
        void destroySwapchainSemaphores();
        void recreateSwapchain();
        void recordCommands(VkCommandBuffer cmd, u32 imageIndex, const Camera& camera) const;

        Window& m_window;

        std::unique_ptr<vulkan::VulkanInstance> m_instance;
        VkSurfaceKHR m_surface = VK_NULL_HANDLE;
        std::unique_ptr<vulkan::VulkanDevice> m_device;
        std::unique_ptr<vulkan::VulkanSwapchain> m_swapchain;
        std::unique_ptr<vulkan::VulkanPipeline> m_trianglePipeline;

        std::array<FrameResources, kFramesInFlight> m_frames{};
        /// One per swapchain image, signaled when rendering to it completes.
        std::vector<VkSemaphore> m_renderFinished;

        u32 m_currentFrame = 0;
        bool m_framebufferResized = false;
        u32 m_pendingWidth = 0;
        u32 m_pendingHeight = 0;
    };
} // namespace sw
