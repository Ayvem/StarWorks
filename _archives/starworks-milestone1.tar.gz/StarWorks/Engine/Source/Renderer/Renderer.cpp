#include "Renderer/Renderer.hpp"

#include "Core/FileSystem.hpp"
#include "Core/Log.hpp"
#include "Platform/Window.hpp"
#include "Renderer/Vulkan/VulkanCommon.hpp"
#include "Renderer/Vulkan/VulkanDevice.hpp"
#include "Renderer/Vulkan/VulkanInstance.hpp"
#include "Renderer/Vulkan/VulkanPipeline.hpp"
#include "Renderer/Vulkan/VulkanSwapchain.hpp"
#include "Scene/Camera.hpp"

namespace sw
{
    namespace
    {
        constexpr const char* kLogCat = "Renderer";

        /// Push-constant block layout shared with Shaders/Triangle.vert.
        struct TrianglePushConstants
        {
            Mat4 viewProjection;
        };
        static_assert(sizeof(TrianglePushConstants) == 64,
                      "Push constant layout must match Triangle.vert");
    } // namespace

    Renderer::Renderer(Window& window, const RendererConfig& config)
        : m_window(window)
    {
        // ---- instance + surface + device -------------------------------------
        vulkan::VulkanInstance::Config instanceConfig{};
        instanceConfig.applicationName = config.applicationName;
        instanceConfig.requiredExtensions = Window::requiredVulkanInstanceExtensions();
        instanceConfig.enableValidation = config.enableValidation;
        m_instance = std::make_unique<vulkan::VulkanInstance>(instanceConfig);

        m_surface = m_window.createVulkanSurface(m_instance->handle());
        m_device = std::make_unique<vulkan::VulkanDevice>(m_instance->handle(), m_surface);

        // ---- swapchain ---------------------------------------------------------
        u32 width = 0;
        u32 height = 0;
        m_window.framebufferSize(width, height);
        m_swapchain =
            std::make_unique<vulkan::VulkanSwapchain>(*m_device, m_surface, width, height);

        // ---- triangle pipeline ---------------------------------------------------
        vulkan::VulkanPipeline::Config pipelineConfig{};
        pipelineConfig.vertexSpirv =
            FileSystem::readBinaryFile(FileSystem::resolve("Shaders/Triangle.vert.spv"));
        pipelineConfig.fragmentSpirv =
            FileSystem::readBinaryFile(FileSystem::resolve("Shaders/Triangle.frag.spv"));
        pipelineConfig.colorAttachmentFormat = m_swapchain->imageFormat();
        pipelineConfig.pushConstantSize = sizeof(TrianglePushConstants);
        m_trianglePipeline =
            std::make_unique<vulkan::VulkanPipeline>(m_device->handle(), pipelineConfig);

        createFrameResources();
        createSwapchainSemaphores();

        SW_LOG_INFO(kLogCat, "Renderer initialized ({} frames in flight)", kFramesInFlight);
    }

    Renderer::~Renderer()
    {
        // Destruction order matters; wait for the GPU before touching anything.
        if (m_device)
        {
            m_device->waitIdle();
        }

        destroySwapchainSemaphores();
        destroyFrameResources();
        m_trianglePipeline.reset();
        m_swapchain.reset();
        m_device.reset();

        if (m_surface != VK_NULL_HANDLE && m_instance)
        {
            vkDestroySurfaceKHR(m_instance->handle(), m_surface, nullptr);
            m_surface = VK_NULL_HANDLE;
        }
        m_instance.reset();
    }

    void Renderer::onFramebufferResized(u32 width, u32 height)
    {
        m_framebufferResized = true;
        m_pendingWidth = width;
        m_pendingHeight = height;
    }

    void Renderer::waitIdle() const
    {
        if (m_device)
        {
            m_device->waitIdle();
        }
    }

    f32 Renderer::aspectRatio() const
    {
        const VkExtent2D extent = m_swapchain->extent();
        if (extent.height == 0)
        {
            return 16.0f / 9.0f;
        }
        return static_cast<f32>(extent.width) / static_cast<f32>(extent.height);
    }

    void Renderer::renderFrame(const Camera& camera)
    {
        // Never render while minimized (zero-sized swapchains are invalid).
        if (m_window.isMinimized())
        {
            return;
        }

        FrameResources& frame = m_frames[m_currentFrame];
        const VkDevice device = m_device->handle();

        // ---- wait until this frame slot is free -------------------------------
        vkWaitForFences(device, 1, &frame.inFlight, VK_TRUE, UINT64_MAX);

        if (m_framebufferResized)
        {
            recreateSwapchain();
            m_framebufferResized = false;
        }

        // ---- acquire ------------------------------------------------------------
        u32 imageIndex = 0;
        const VkResult acquireResult =
            m_swapchain->acquireNextImage(frame.imageAvailable, imageIndex);
        if (acquireResult == VK_ERROR_OUT_OF_DATE_KHR)
        {
            recreateSwapchain();
            return; // retry next frame with fresh images
        }
        if (acquireResult != VK_SUCCESS && acquireResult != VK_SUBOPTIMAL_KHR)
        {
            SW_LOG_ERROR(kLogCat, "vkAcquireNextImageKHR failed: {}",
                         vulkan::toString(acquireResult));
            return;
        }

        // Only reset the fence once we know work will be submitted.
        vkResetFences(device, 1, &frame.inFlight);

        // ---- record --------------------------------------------------------------
        vkResetCommandPool(device, frame.commandPool, 0);

        VkCommandBufferBeginInfo beginInfo{};
        beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
        beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        SW_VK_CHECK(vkBeginCommandBuffer(frame.commandBuffer, &beginInfo));
        recordCommands(frame.commandBuffer, imageIndex, camera);
        SW_VK_CHECK(vkEndCommandBuffer(frame.commandBuffer));

        // ---- submit (synchronization2) --------------------------------------------
        VkSemaphoreSubmitInfo waitInfo{};
        waitInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO;
        waitInfo.semaphore = frame.imageAvailable;
        waitInfo.stageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

        VkSemaphoreSubmitInfo signalInfo{};
        signalInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO;
        signalInfo.semaphore = m_renderFinished[imageIndex];
        signalInfo.stageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

        VkCommandBufferSubmitInfo cmdInfo{};
        cmdInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO;
        cmdInfo.commandBuffer = frame.commandBuffer;

        VkSubmitInfo2 submitInfo{};
        submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO_2;
        submitInfo.waitSemaphoreInfoCount = 1;
        submitInfo.pWaitSemaphoreInfos = &waitInfo;
        submitInfo.commandBufferInfoCount = 1;
        submitInfo.pCommandBufferInfos = &cmdInfo;
        submitInfo.signalSemaphoreInfoCount = 1;
        submitInfo.pSignalSemaphoreInfos = &signalInfo;

        SW_VK_CHECK(vkQueueSubmit2(m_device->graphicsQueue(), 1, &submitInfo, frame.inFlight));

        // ---- present ---------------------------------------------------------------
        const VkResult presentResult = m_swapchain->present(
            m_device->presentQueue(), m_renderFinished[imageIndex], imageIndex);
        if (presentResult == VK_ERROR_OUT_OF_DATE_KHR || presentResult == VK_SUBOPTIMAL_KHR)
        {
            recreateSwapchain();
        }
        else if (presentResult != VK_SUCCESS)
        {
            SW_LOG_ERROR(kLogCat, "vkQueuePresentKHR failed: {}",
                         vulkan::toString(presentResult));
        }

        m_currentFrame = (m_currentFrame + 1) % kFramesInFlight;
    }

    void Renderer::recordCommands(VkCommandBuffer cmd, u32 imageIndex,
                                  const Camera& camera) const
    {
        const VkExtent2D extent = m_swapchain->extent();
        const VkImage swapImage = m_swapchain->image(imageIndex);

        VkImageSubresourceRange colorRange{};
        colorRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        colorRange.levelCount = 1;
        colorRange.layerCount = 1;

        // ---- transition: UNDEFINED -> COLOR_ATTACHMENT_OPTIMAL ---------------
        {
            VkImageMemoryBarrier2 barrier{};
            barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
            barrier.srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barrier.srcAccessMask = VK_ACCESS_2_NONE;
            barrier.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barrier.dstAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
            barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            barrier.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.image = swapImage;
            barrier.subresourceRange = colorRange;

            VkDependencyInfo dependency{};
            dependency.sType = VK_STRUCTURE_TYPE_DEPENDENCY_INFO;
            dependency.imageMemoryBarrierCount = 1;
            dependency.pImageMemoryBarriers = &barrier;
            vkCmdPipelineBarrier2(cmd, &dependency);
        }

        // ---- dynamic rendering pass -------------------------------------------
        VkClearValue clearColor{};
        // Deep-space blue-black; linear values (swapchain is sRGB).
        clearColor.color = {{0.004f, 0.006f, 0.015f, 1.0f}};

        VkRenderingAttachmentInfo colorAttachment{};
        colorAttachment.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO;
        colorAttachment.imageView = m_swapchain->imageView(imageIndex);
        colorAttachment.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        colorAttachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        colorAttachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        colorAttachment.clearValue = clearColor;

        VkRenderingInfo renderingInfo{};
        renderingInfo.sType = VK_STRUCTURE_TYPE_RENDERING_INFO;
        renderingInfo.renderArea = {{0, 0}, extent};
        renderingInfo.layerCount = 1;
        renderingInfo.colorAttachmentCount = 1;
        renderingInfo.pColorAttachments = &colorAttachment;

        vkCmdBeginRendering(cmd, &renderingInfo);

        VkViewport viewport{};
        viewport.width = static_cast<f32>(extent.width);
        viewport.height = static_cast<f32>(extent.height);
        viewport.minDepth = 0.0f;
        viewport.maxDepth = 1.0f;
        vkCmdSetViewport(cmd, 0, 1, &viewport);

        VkRect2D scissor{{0, 0}, extent};
        vkCmdSetScissor(cmd, 0, 1, &scissor);

        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, m_trianglePipeline->handle());

        TrianglePushConstants push{};
        push.viewProjection = camera.viewProjectionMatrix();
        vkCmdPushConstants(cmd, m_trianglePipeline->layout(), VK_SHADER_STAGE_VERTEX_BIT, 0,
                           sizeof(push), &push);

        vkCmdDraw(cmd, 3, 1, 0, 0);

        vkCmdEndRendering(cmd);

        // ---- transition: COLOR_ATTACHMENT_OPTIMAL -> PRESENT_SRC ---------------
        {
            VkImageMemoryBarrier2 barrier{};
            barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
            barrier.srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barrier.srcAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
            barrier.dstStageMask = VK_PIPELINE_STAGE_2_NONE;
            barrier.dstAccessMask = VK_ACCESS_2_NONE;
            barrier.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            barrier.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.image = swapImage;
            barrier.subresourceRange = colorRange;

            VkDependencyInfo dependency{};
            dependency.sType = VK_STRUCTURE_TYPE_DEPENDENCY_INFO;
            dependency.imageMemoryBarrierCount = 1;
            dependency.pImageMemoryBarriers = &barrier;
            vkCmdPipelineBarrier2(cmd, &dependency);
        }
    }

    void Renderer::recreateSwapchain()
    {
        u32 width = 0;
        u32 height = 0;
        m_window.framebufferSize(width, height);
        if (width == 0 || height == 0)
        {
            return; // minimized; the frame loop skips rendering anyway
        }

        m_device->waitIdle();
        const u32 previousImageCount = m_swapchain->imageCount();
        m_swapchain->recreate(width, height);

        // Semaphores are indexed per swapchain image; rebuild if the count moved.
        if (m_swapchain->imageCount() != previousImageCount)
        {
            destroySwapchainSemaphores();
            createSwapchainSemaphores();
        }

        SW_LOG_DEBUG(kLogCat, "Swapchain recreated: {}x{}", width, height);
    }

    void Renderer::createFrameResources()
    {
        const VkDevice device = m_device->handle();

        for (FrameResources& frame : m_frames)
        {
            VkCommandPoolCreateInfo poolInfo{};
            poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
            poolInfo.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
            poolInfo.queueFamilyIndex = m_device->graphicsFamilyIndex();
            SW_VK_CHECK(vkCreateCommandPool(device, &poolInfo, nullptr, &frame.commandPool));

            VkCommandBufferAllocateInfo allocInfo{};
            allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
            allocInfo.commandPool = frame.commandPool;
            allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
            allocInfo.commandBufferCount = 1;
            SW_VK_CHECK(vkAllocateCommandBuffers(device, &allocInfo, &frame.commandBuffer));

            VkSemaphoreCreateInfo semaphoreInfo{};
            semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
            SW_VK_CHECK(
                vkCreateSemaphore(device, &semaphoreInfo, nullptr, &frame.imageAvailable));

            VkFenceCreateInfo fenceInfo{};
            fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
            fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT; // first wait must pass
            SW_VK_CHECK(vkCreateFence(device, &fenceInfo, nullptr, &frame.inFlight));
        }
    }

    void Renderer::destroyFrameResources()
    {
        const VkDevice device = m_device ? m_device->handle() : VK_NULL_HANDLE;
        if (device == VK_NULL_HANDLE)
        {
            return;
        }
        for (FrameResources& frame : m_frames)
        {
            if (frame.inFlight != VK_NULL_HANDLE)
            {
                vkDestroyFence(device, frame.inFlight, nullptr);
            }
            if (frame.imageAvailable != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(device, frame.imageAvailable, nullptr);
            }
            if (frame.commandPool != VK_NULL_HANDLE)
            {
                vkDestroyCommandPool(device, frame.commandPool, nullptr);
            }
            frame = {};
        }
    }

    void Renderer::createSwapchainSemaphores()
    {
        const VkDevice device = m_device->handle();
        m_renderFinished.resize(m_swapchain->imageCount(), VK_NULL_HANDLE);
        for (VkSemaphore& semaphore : m_renderFinished)
        {
            VkSemaphoreCreateInfo semaphoreInfo{};
            semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
            SW_VK_CHECK(vkCreateSemaphore(device, &semaphoreInfo, nullptr, &semaphore));
        }
    }

    void Renderer::destroySwapchainSemaphores()
    {
        const VkDevice device = m_device ? m_device->handle() : VK_NULL_HANDLE;
        if (device == VK_NULL_HANDLE)
        {
            return;
        }
        for (VkSemaphore semaphore : m_renderFinished)
        {
            if (semaphore != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(device, semaphore, nullptr);
            }
        }
        m_renderFinished.clear();
    }
} // namespace sw
