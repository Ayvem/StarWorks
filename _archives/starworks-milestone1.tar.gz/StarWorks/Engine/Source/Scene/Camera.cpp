#include "Scene/Camera.hpp"

namespace sw
{
    Camera::Camera()
    {
        rebuildProjection();
    }

    void Camera::setPerspective(f32 verticalFovRadians, f32 nearPlane, f32 farPlane)
    {
        m_verticalFov = verticalFovRadians;
        m_nearPlane = nearPlane;
        m_farPlane = farPlane;
        rebuildProjection();
    }

    void Camera::setAspectRatio(f32 aspect)
    {
        if (aspect > 0.0f && aspect != m_aspectRatio)
        {
            m_aspectRatio = aspect;
            rebuildProjection();
        }
    }

    void Camera::setPosition(const Vec3& position)
    {
        m_position = position;
    }

    void Camera::setOrientation(const Quat& orientation)
    {
        m_orientation = glm::normalize(orientation);
    }

    Vec3 Camera::forward() const
    {
        return m_orientation * math::kWorldForward;
    }

    Vec3 Camera::right() const
    {
        return m_orientation * math::kWorldRight;
    }

    Vec3 Camera::up() const
    {
        return m_orientation * math::kWorldUp;
    }

    Mat4 Camera::viewMatrix() const
    {
        // View = inverse of the camera's world transform (rotation * translation).
        const Mat4 rotation = glm::mat4_cast(glm::conjugate(m_orientation));
        const Mat4 translation = glm::translate(Mat4{1.0f}, -m_position);
        return rotation * translation;
    }

    const Mat4& Camera::projectionMatrix() const
    {
        return m_projection;
    }

    Mat4 Camera::viewProjectionMatrix() const
    {
        return m_projection * viewMatrix();
    }

    void Camera::rebuildProjection()
    {
        m_projection = glm::perspective(m_verticalFov, m_aspectRatio, m_nearPlane, m_farPlane);
        // GLM builds OpenGL-style projections (+Y up in NDC); Vulkan's NDC has
        // +Y pointing down, so flip the Y axis here, once, at the source.
        m_projection[1][1] *= -1.0f;
    }
} // namespace sw
