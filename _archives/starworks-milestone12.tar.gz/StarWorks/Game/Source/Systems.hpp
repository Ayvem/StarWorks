#pragma once

// ============================================================================
// Systems.hpp — game-side ECS systems (Physics-lane companions to the
// engine's physics systems).
//
// Simulation-cost policy (Milestone 6): per-tick work only touches entities
// that are REALLY simulated. Snapshot and Spin therefore require
// DynamicBodyComponent in their queries — thousands of on-rails debris cost
// nothing here. Celestial bodies (a handful) have their own spin system.
// ============================================================================

#include "Components.hpp"

namespace game
{
    /// Physics lane, first: snapshots dynamic transforms so the renderer
    /// can interpolate between the previous and current tick.
    class SnapshotSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "SnapshotSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .read<TransformComponent>()
                .read<sw::phys::DynamicBodyComponent>()
                .write<PreviousTransformComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Self-rotation of really-simulated (dynamic) objects.
    class SpinSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "SpinSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .read<SpinComponent>()
                .read<sw::phys::DynamicBodyComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Rotation of celestial bodies (planet day cycle). Also maintains
    /// their Previous snapshot for interpolation. A handful of entities.
    class CelestialSpinSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "CelestialSpinSystem";
        }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<SpinComponent>()
                .read<sw::phys::GravitySourceComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Keeps atmosphere/cloud shells centered on their body, spinning at
    /// their own rate (clouds drift over the ground). Runs after the
    /// celestial motion so the center is this tick's.
    class CloudLayerSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "CloudLayerSystem";
        }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<CloudLayerComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Physics lane: applies pilot thrust and attitude control to ships.
    /// Runs after gravity so the pilot's acceleration adds on top of the
    /// gravitational one within the same tick.
    class ThrustSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "ThrustSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<sw::phys::DynamicBodyComponent>()
                .write<ShipComponent>()
                .read<ShipControlsComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Physics lane: grounded capsule locomotion (EVA). Runs after the
    /// surface system so isGrounded reflects the current tick.
    class CapsuleMovementSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "CapsuleMovementSystem";
        }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<sw::phys::DynamicBodyComponent>()
                .write<CapsuleComponent>()
                .read<ShipControlsComponent>()
                .read<sw::phys::GravitySourceComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// World lane (1 Hz): periodic simulation statistics to the log.
    class StatsSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "StatsSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .read<sw::factory::InventoryComponent>()
                .read<sw::factory::MinerComponent>()
                .read<sw::factory::RefineryComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;

    private:
        sw::u64 m_ticks = 0;
    };
} // namespace game
