// ============================================================================
// PhysicsTests.cpp — Kepler orbits, Newtonian integrator and the
// simulation bubble (rails <-> dynamic conversions).
// ============================================================================

#include "TestFramework.hpp"

#include <ECS/CommandBuffer.hpp>
#include <ECS/World.hpp>
#include <Physics/Kepler.hpp>
#include <Physics/PhysicsSystems.hpp>
#include <Scene/TransformComponents.hpp>
#include <Simulation/Simulation.hpp>

#include <cmath>
#include <limits>

namespace
{
    constexpr sw::f64 kMuTerra = 3.986004418e14;
    constexpr sw::f64 kLeoRadius = 6.771e6; // 400 km altitude

    [[nodiscard]] sw::f64 relativeError(const sw::WorldVec3& a, const sw::WorldVec3& b,
                                        sw::f64 scale)
    {
        return glm::length(a - b) / scale;
    }
} // namespace

using namespace sw;
using namespace sw::phys;

SW_TEST(KeplerCircularOrbitGeometry)
{
    const KeplerOrbit orbit =
        kepler::fromElements(kMuTerra, kLeoRadius, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

    // Radius stays constant; a quarter period advances the anomaly by 90°.
    const f64 period = kepler::period(orbit);
    SW_CHECK(std::abs(period - 5546.0) < 10.0); // real LEO period ~92.4 min

    WorldVec3 p0{};
    WorldVec3 pQuarter{};
    WorldVec3 v0{};
    kepler::evaluate(orbit, 0.0, p0, &v0);
    kepler::evaluate(orbit, period * 0.25, pQuarter);

    SW_CHECK(std::abs(glm::length(p0) - kLeoRadius) / kLeoRadius < 1.0e-12);
    SW_CHECK(std::abs(glm::length(pQuarter) - kLeoRadius) / kLeoRadius < 1.0e-9);
    // Perpendicular position vectors after a quarter of a circular orbit.
    SW_CHECK(std::abs(glm::dot(glm::normalize(p0), glm::normalize(pQuarter))) < 1.0e-6);
    // Circular speed = sqrt(mu/r) ~ 7.67 km/s in LEO.
    SW_CHECK(std::abs(glm::length(v0) - kepler::circularOrbitSpeed(kMuTerra, kLeoRadius)) <
             1.0e-6);
    // Full period returns to the start.
    WorldVec3 pFull{};
    kepler::evaluate(orbit, period, pFull);
    SW_CHECK(relativeError(pFull, p0, kLeoRadius) < 1.0e-9);
}

SW_TEST(KeplerStateVectorRoundTrip)
{
    // An inclined, eccentric orbit built from elements...
    const KeplerOrbit original =
        kepler::fromElements(kMuTerra, 8.0e6, 0.3, 0.4, 1.1, 2.2, 0.7, /*epoch=*/100.0);

    // ...sampled mid-flight into state vectors...
    const f64 sampleTime = 1234.5;
    WorldVec3 position{};
    WorldVec3 velocity{};
    kepler::evaluate(original, sampleTime, position, &velocity);

    // ...must reconstruct an orbit with identical future motion.
    KeplerOrbit rebuilt{};
    SW_CHECK(kepler::fromStateVectors(kMuTerra, position, velocity, sampleTime, rebuilt));
    SW_CHECK(std::abs(rebuilt.semiMajorAxis - original.semiMajorAxis) /
                 original.semiMajorAxis <
             1.0e-9);
    SW_CHECK(std::abs(rebuilt.eccentricity - original.eccentricity) < 1.0e-9);

    for (const f64 probeTime : {sampleTime, sampleTime + 500.0, sampleTime + 4321.0})
    {
        WorldVec3 expected{};
        WorldVec3 actual{};
        kepler::evaluate(original, probeTime, expected);
        kepler::evaluate(rebuilt, probeTime, actual);
        SW_CHECK(relativeError(actual, expected, original.semiMajorAxis) < 1.0e-8);
    }
}

SW_TEST(KeplerRejectsUnboundTrajectoriesByDefault)
{
    KeplerOrbit orbit{};
    const WorldVec3 position{kLeoRadius, 0.0, 0.0};
    // Twice escape velocity: clearly hyperbolic.
    const f64 escape = std::sqrt(2.0 * kMuTerra / kLeoRadius);
    SW_CHECK(!kepler::fromStateVectors(kMuTerra, position, {0.0, 0.0, 2.0 * escape}, 0.0,
                                       orbit));
}

SW_TEST(KeplerHyperbolicOrbit)
{
    // A hyperbolic flyby: 1.3x escape speed, tangential, opted in.
    const WorldVec3 position{kLeoRadius, 0.0, 0.0};
    const f64 escape = std::sqrt(2.0 * kMuTerra / kLeoRadius);
    const WorldVec3 velocity{0.0, 0.0, 1.3 * escape};

    KeplerOrbit orbit{};
    SW_CHECK(kepler::fromStateVectors(kMuTerra, position, velocity, /*epoch=*/50.0, orbit,
                                      /*allowHyperbolic=*/true));
    SW_CHECK(orbit.isHyperbolic());
    SW_CHECK(orbit.semiMajorAxis < 0.0);
    SW_CHECK(kepler::apoapsis(orbit) == std::numeric_limits<f64>::infinity());
    SW_CHECK(kepler::periapsis(orbit) > 0.0 && kepler::periapsis(orbit) <= kLeoRadius);

    // The evaluation must reproduce the epoch state exactly...
    WorldVec3 p0{};
    WorldVec3 v0{};
    kepler::evaluate(orbit, 50.0, p0, &v0);
    SW_CHECK(relativeError(p0, position, kLeoRadius) < 1.0e-9);
    SW_CHECK(glm::length(v0 - velocity) / glm::length(velocity) < 1.0e-9);

    // ...and conserve specific orbital energy far along the escape leg
    // (also backwards in time, on the inbound branch).
    const f64 energy0 = 0.5 * glm::dot(velocity, velocity) - kMuTerra / kLeoRadius;
    for (const f64 t : {-20000.0, 1000.0, 5000.0, 200000.0})
    {
        WorldVec3 p{};
        WorldVec3 v{};
        kepler::evaluate(orbit, 50.0 + t, p, &v);
        const f64 energy = 0.5 * glm::dot(v, v) - kMuTerra / glm::length(p);
        SW_CHECK(std::abs(energy - energy0) / std::abs(energy0) < 1.0e-9);
        SW_CHECK(glm::length(p) >= kepler::periapsis(orbit) * 0.999999);
    }

    // Asymptotic speed: v_inf = sqrt(mu / |a|).
    WorldVec3 pFar{};
    WorldVec3 vFar{};
    kepler::evaluate(orbit, 50.0 + 5.0e6, pFar, &vFar);
    const f64 vInf = std::sqrt(kMuTerra / std::abs(orbit.semiMajorAxis));
    SW_CHECK(std::abs(glm::length(vFar) - vInf) / vInf < 1.0e-3);
}

SW_TEST(GravityIntegratorHoldsACircularOrbit)
{
    ecs::World world;

    // Terra at the origin.
    {
        const ecs::Entity terra = world.createEntity();
        world.addComponent(terra, TransformComponent{});
        world.addComponent(terra, GravitySourceComponent{kMuTerra});
    }

    // Dynamic body with exact circular velocity.
    const ecs::Entity body = world.createEntity();
    {
        TransformComponent transform{};
        transform.position = {0.0, 0.0, kLeoRadius};
        world.addComponent(body, transform);
        const f64 speed = kepler::circularOrbitSpeed(kMuTerra, kLeoRadius);
        world.addComponent(body, DynamicBodyComponent{{speed, 0.0, 0.0}, 1000.0});
    }

    GravityIntegrationSystem gravity;
    constexpr f32 kDt = 0.02f; // Physics lane step
    constexpr int kTicks = 5000; // 100 simulated seconds
    for (int i = 0; i < kTicks; ++i)
    {
        gravity.update(world, kDt);
    }

    // Semi-implicit Euler on a circular orbit: radius drift must stay tiny.
    const f64 radius = glm::length(world.getComponent<TransformComponent>(body).position);
    SW_CHECK(std::abs(radius - kLeoRadius) / kLeoRadius < 5.0e-4);

    // Specific orbital energy must match the circular value closely.
    const auto& dynamicBody = world.getComponent<DynamicBodyComponent>(body);
    const f64 energy =
        0.5 * glm::dot(dynamicBody.velocity, dynamicBody.velocity) - kMuTerra / radius;
    const f64 expectedEnergy = -kMuTerra / (2.0 * kLeoRadius);
    SW_CHECK(std::abs(energy - expectedEnergy) / std::abs(expectedEnergy) < 1.0e-3);
}

SW_TEST(AtmosphereDragAndSolidGround)
{
    ecs::World world;

    // Small test body: radius 1 km, weak gravity, thick atmosphere.
    {
        const ecs::Entity body = world.createEntity();
        world.addComponent(body, TransformComponent{});
        world.addComponent(body, GravitySourceComponent{1.0e6, 1000.0}); // ~1 m/s^2
        world.addComponent(body, AtmosphereComponent{1.225, 500.0, 5000.0});
    }

    // Falling object released 200 m above the surface.
    const ecs::Entity probe = world.createEntity();
    {
        TransformComponent transform{};
        transform.position = {0.0, 1200.0, 0.0};
        world.addComponent(probe, transform);
        DynamicBodyComponent body{};
        body.ballisticFactor = 0.01;
        world.addComponent(probe, body);
    }

    GravityIntegrationSystem gravity;
    SurfaceInteractionSystem::Config config{};
    SurfaceInteractionSystem surface(config);

    constexpr f32 kDt = 0.02f;
    f64 maxFallSpeed = 0.0;
    bool landed = false;
    for (int tick = 0; tick < 5000 && !landed; ++tick) // up to 100 s
    {
        gravity.update(world, kDt);
        surface.update(world, kDt);
        const auto& body = world.getComponent<DynamicBodyComponent>(probe);
        maxFallSpeed = std::max(maxFallSpeed, glm::length(body.velocity));
        landed = body.isGrounded != 0;
    }

    SW_CHECK(landed);
    // Drag must keep the fall well below the vacuum impact speed (~20 m/s
    // for 200 m at 1 m/s^2): terminal velocity here is a few m/s.
    SW_CHECK(maxFallSpeed < 15.0);

    // Resting on the surface: radius equals the body radius, speed ~ 0.
    const auto& transform = world.getComponent<TransformComponent>(probe);
    SW_CHECK(std::abs(glm::length(transform.position) - 1000.0) < 1.0e-6);
    for (int tick = 0; tick < 250; ++tick) // 5 more seconds at rest
    {
        gravity.update(world, kDt);
        surface.update(world, kDt);
    }
    SW_CHECK(glm::length(world.getComponent<DynamicBodyComponent>(probe).velocity) < 0.05);
    SW_CHECK(world.getComponent<DynamicBodyComponent>(probe).isGrounded != 0);
}

SW_TEST(GroundCoRotatesWithTheSpinningBody)
{
    ecs::World world;

    // A spinning Terra-like body, translating through space as well.
    const WorldVec3 bodyVelocity{100.0, 0.0, 0.0};
    const WorldVec3 spin{0.0, 7.2921e-5, 0.0}; // Earth sidereal rate, +Y
    constexpr f64 kRadius = 6.371e6;
    {
        const ecs::Entity terra = world.createEntity();
        world.addComponent(terra, TransformComponent{});
        GravitySourceComponent source{kMuTerra, kRadius};
        source.worldVelocity = bodyVelocity;
        source.angularVelocity = spin;
        world.addComponent(terra, source);
    }

    // An object dropped AT REST (world frame) on the equator (+X).
    const ecs::Entity probe = world.createEntity();
    {
        TransformComponent transform{};
        transform.position = {kRadius, 0.0, 0.0};
        world.addComponent(probe, transform);
        world.addComponent(probe, DynamicBodyComponent{{0.0, 0.0, 0.0}, 1000.0});
    }

    SurfaceInteractionSystem::Config config{};
    SurfaceInteractionSystem surface(config);
    constexpr f32 kDt = 0.02f;
    for (int tick = 0; tick < 500; ++tick) // 10 s of ground friction
    {
        surface.update(world, kDt);
    }

    // Friction must drag it INTO the rotating surface frame: final velocity
    // equals body translation + omega x r (the local surface velocity,
    // ~465 m/s eastward for Earth), NOT zero.
    const WorldVec3 expected =
        bodyVelocity + glm::cross(spin, WorldVec3{kRadius, 0.0, 0.0});
    const auto& body = world.getComponent<DynamicBodyComponent>(probe);
    SW_CHECK(glm::length(body.velocity - expected) < 0.05);
    SW_CHECK(body.isGrounded != 0);
    SW_CHECK(glm::length(expected - bodyVelocity) > 400.0); // spin really counted
}

SW_TEST(BubbleConvertsRailsToDynamicAndBack)
{
    ecs::World world;
    ecs::EntityCommandBuffer commands;
    sim::Simulation simulation({{"Logistics", 10.0f, 4}});

    // Terra (at the world origin; default SOI is effectively infinite).
    const ecs::Entity terra = world.createEntity();
    world.addComponent(terra, TransformComponent{});
    world.addComponent(terra, GravitySourceComponent{kMuTerra});

    // On-rails object at +Z LEO, Terra-relative orbit, distinctive payload.
    const KeplerOrbit orbit = kepler::fromElements(
        kMuTerra, kLeoRadius, 0.0, 0.0, 0.0, 0.0, /*M0=*/4.71238898038468986, 0.0);
    const ecs::Entity object = world.createEntity();
    {
        TransformComponent transform{};
        kepler::evaluate(orbit, 0.0, transform.position);
        world.addComponent(object, transform);
        world.addComponent(object, PreviousTransformComponent{});
        OnRailsComponent rails{};
        rails.orbit = orbit;
        rails.primary = terra;
        rails.dynamicMass = 7777.0; // must survive the round trips below
        world.addComponent(object, rails);
    }

    SimulationBubbleSystem::Config config{};
    config.enterRadius = 1.0e4;
    config.exitRadius = 1.5e4;

    sim::SimulationLane& lane = *simulation.findLane("Logistics");
    auto rails = std::make_unique<RailsSystem>(lane);
    auto bubble = std::make_unique<SimulationBubbleSystem>(commands, lane, config);
    auto* bubblePtr = bubble.get();
    auto& scheduler = lane.scheduler();
    scheduler.addSystem(std::move(rails));
    scheduler.addSystem(std::move(bubble));

    // ---- focus near the object: it must become dynamic --------------------
    const WorldVec3 objectPosition =
        world.getComponent<TransformComponent>(object).position;
    bubblePtr->setFocus(objectPosition + WorldVec3{500.0, 0.0, 0.0});

    simulation.advance(world, 0.1f, nullptr); // one Logistics tick
    commands.playback(world);

    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));
    SW_CHECK(!world.hasComponent<OnRailsComponent>(object));
    // Continuity: the hand-off position equals the ANALYTIC position at the
    // conversion time (the object legitimately moved ~767 m during the
    // 0.1 s Logistics tick), and the velocity is the circular speed.
    const auto& converted = world.getComponent<DynamicBodyComponent>(object);
    SW_CHECK(std::abs(glm::length(converted.velocity) -
                      kepler::circularOrbitSpeed(kMuTerra, kLeoRadius)) < 1.0);
    SW_CHECK_EQ(converted.mass, 7777.0); // payload restored, not defaulted
    WorldVec3 expectedAtConversion{};
    kepler::evaluate(orbit, simulation.findLane("Logistics")->presentSeconds(), expectedAtConversion);
    SW_CHECK(relativeError(world.getComponent<TransformComponent>(object).position,
                           expectedAtConversion, kLeoRadius) < 1.0e-9);

    // ---- focus far away: it must go back on rails ---------------------------
    bubblePtr->setFocus(objectPosition + WorldVec3{1.0e6, 0.0, 0.0});
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);

    SW_CHECK(!world.hasComponent<DynamicBodyComponent>(object));
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));

    // The rebuilt rails orbit must continue the motion seamlessly: its
    // evaluation now must match the object's current transform. The primary
    // and the dynamic payload must round-trip too.
    const auto& backOnRails = world.getComponent<OnRailsComponent>(object);
    SW_CHECK(backOnRails.primary == terra);
    SW_CHECK_EQ(backOnRails.dynamicMass, 7777.0);
    WorldVec3 railsPosition{};
    kepler::evaluate(backOnRails.orbit, simulation.findLane("Logistics")->presentSeconds(), railsPosition);
    SW_CHECK(relativeError(railsPosition,
                           world.getComponent<TransformComponent>(object).position,
                           kLeoRadius) < 1.0e-6);

    // ---- force-rails (time warp): dynamic INSIDE the bubble still railifies
    bubblePtr->setFocus(world.getComponent<TransformComponent>(object).position);
    simulation.advance(world, 0.1f, nullptr); // converts back to dynamic
    commands.playback(world);
    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));

    bubblePtr->setForceRails(true);
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));
    SW_CHECK(!world.hasComponent<DynamicBodyComponent>(object));

    // While forced, nothing may come off the rails even at distance zero.
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));

    // Releasing force-rails lets the bubble re-acquire it — with the same
    // dynamic payload it had before the warp (a 7777 kg ship must not come
    // back as a 1000 kg default).
    bubblePtr->setForceRails(false);
    bubblePtr->setFocus(world.getComponent<TransformComponent>(object).position);
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));
    SW_CHECK_EQ(world.getComponent<DynamicBodyComponent>(object).mass, 7777.0);
}
