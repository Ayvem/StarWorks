#pragma once

// ============================================================================
// Physics/PhysicsComponents.hpp
// The two mutually exclusive motion regimes of the engine:
//
//  - DynamicBodyComponent : TRULY simulated. Newtonian gravity integrated
//    every Physics tick (50 Hz). Reserved for objects near the player —
//    the BubbleSystem enforces this.
//  - OnRailsComponent     : analytic Kepler orbit. No integration ever; the
//    RailsSystem refreshes the transform at low frequency from the closed-
//    form solution. This is the default state of every distant object.
//
//  - GravitySourceComponent marks celestial bodies that generate gravity.
// ============================================================================

#include "ECS/Entity.hpp"
#include "Physics/Kepler.hpp"

namespace sw::phys
{
    struct DynamicBodyComponent
    {
        WorldVec3 velocity{0.0}; // m/s, world frame
        f64 mass = 1000.0;       // kg (used by thrust; gravity is mass-free)
        /// Effective drag coefficient x area / mass (m^2/kg): atmosphere
        /// deceleration = 0.5 * rho * v^2 * ballistic. ~0.002 for a ship.
        f64 ballisticFactor = 0.002;
        /// Set by SurfaceInteractionSystem while resting on a body surface.
        u32 isGrounded = 0;
    };

    /// v2 (hierarchical systems): the orbit is PRIMARY-RELATIVE and the
    /// component remembers which body it orbits. The RailsSystem adds the
    /// primary's current world position — so a station riding rails around
    /// Terra follows Terra around the Sun for free.
    struct OnRailsComponent
    {
        KeplerOrbit orbit{};   // primary-relative elements
        ecs::Entity primary{}; // gravity source orbited (null = world origin)
        /// DynamicBody payload preserved across regime conversions: when the
        /// bubble railifies a ship (time warp!) and later releases it, the
        /// ship must come back with ITS mass, not a default.
        f64 dynamicMass = 1000.0;
        f64 dynamicBallisticFactor = 0.002;
    };

    struct GravitySourceComponent
    {
        f64 mu = 0.0;         // GM, m^3/s^2
        f64 bodyRadius = 0.0; // meters — solid surface + altitude rules
        /// Sphere-of-influence radius: inside it, THIS body is the primary
        /// for rails conversions and trajectory patching. The default is
        /// effectively infinite (a lone body owns all of space); real
        /// systems set r_SOI = a * (mu/mu_parent)^(2/5).
        f64 soiRadius = 1.0e300;
        /// Current world-frame velocity of the body, stamped each Physics
        /// tick by whatever moves it (CelestialMotionSystem). Everything
        /// body-relative — atmosphere drag, ground friction, orbit
        /// conversions — measures velocities against this, so physics stays
        /// correct while the planet itself races around its star.
        WorldVec3 worldVelocity{0.0};
    };

    /// Rigidly attaches an entity to a celestial body's SURFACE: the local
    /// position is expressed in the body's rotating frame, so anchored
    /// structures (mines, factories, launch pads) co-rotate with the planet
    /// or asteroid they are built on. This — not absolute coordinates — is
    /// what makes surface bases save/load-proof: the body may have rotated
    /// arbitrarily far while the game was closed, the base stays exactly
    /// where it was built.
    struct SurfaceAnchorComponent
    {
        ecs::Entity body{};          // the gravity source this is built on
        WorldVec3 localPosition{0.0}; // body-fixed frame, meters
    };

    /// Optional exponential atmosphere around a gravity source.
    struct AtmosphereComponent
    {
        f64 surfaceDensity = 1.225; // kg/m^3 at altitude 0 (Earth-like)
        f64 scaleHeight = 8500.0;   // meters (density /e per scale height)
        f64 topAltitude = 1.4e5;    // no drag above this altitude
    };

    static_assert(std::is_trivially_copyable_v<DynamicBodyComponent>);
    static_assert(std::is_trivially_copyable_v<OnRailsComponent>);
    static_assert(std::is_trivially_copyable_v<GravitySourceComponent>);
    static_assert(std::is_trivially_copyable_v<AtmosphereComponent>);
    static_assert(std::is_trivially_copyable_v<SurfaceAnchorComponent>);
} // namespace sw::phys
