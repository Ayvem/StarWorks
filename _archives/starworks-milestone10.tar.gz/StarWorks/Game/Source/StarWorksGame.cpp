#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <format>

namespace game
{
    namespace
    {
        // ---- real-world dimensions and gravity (meters, m^3/s^2) --------------
        // The hierarchy: Sol -> Terra (-> Luna) / Mars. All values real.
        constexpr sw::f64 kMuSol = 1.32712440018e20;
        constexpr sw::f64 kSolRadius = 6.9634e8;
        constexpr sw::f64 kTerraRadius = 6.371e6;    // Earth
        constexpr sw::f64 kMuTerra = 3.986004418e14; // Earth GM
        constexpr sw::f64 kTerraSma = 1.496e11;      // 1 AU
        constexpr sw::f64 kLunaRadius = 1.7374e6;    // Moon
        constexpr sw::f64 kMuLuna = 4.9048695e12;    // Moon GM
        constexpr sw::f64 kLunaSma = 3.844e8;        // Earth-Moon distance
        constexpr sw::f64 kMarsRadius = 3.3895e6;
        constexpr sw::f64 kMuMars = 4.2828e13;
        constexpr sw::f64 kMarsSma = 2.2794e11;
        // Sphere-of-influence radii: r = a * (mu / mu_parent)^(2/5).
        constexpr sw::f64 kTerraSoi = 9.24e8;
        constexpr sw::f64 kLunaSoi = 6.61e7;
        constexpr sw::f64 kMarsSoi = 5.77e8;

        constexpr sw::f64 kStationAltitude = 4.0e5; // 400 km (LEO)
        constexpr sw::f64 kStationOrbitRadius = kTerraRadius + kStationAltitude;
        constexpr sw::f64 kStationPhase = 4.71238898038468986; // 3*pi/2
        /// Terra sidereal angular velocity (rad/s) around +Y — used for the
        /// SuRFace-relative speed readout.
        constexpr sw::WorldVec3 kTerraAngularVelocity{0.0, 7.2921e-5, 0.0};

        constexpr sw::u32 kStationModuleCount = 8;

        constexpr sw::f64 kBubbleEnterRadius = 1.0e4; // 10 km
        constexpr sw::f64 kBubbleExitRadius = 1.5e4;  // 15 km (hysteresis)

        // Star map: constant on-screen marker size and zoom limits (up to
        // the full Sol system — Mars orbit is 2.28e11 m).
        constexpr sw::f32 kMarkerScreenFraction = 0.016f;
        constexpr sw::f64 kMapMinHeight = 2.0e7;
        constexpr sw::f64 kMapMaxHeight = 8.0e11;
        constexpr sw::u32 kTrajectorySamples = 72;
        constexpr sw::u32 kPredictionDisplaySamples = 160; // dots per patch
        /// Patch colors: current conic, then each successive patch (KSP
        /// style — the eye follows the hand-offs by color).
        constexpr sw::Vec4 kPatchColors[] = {
            {0.35f, 1.0f, 0.55f, 2.0f},  // green: current orbit
            {1.0f, 0.85f, 0.25f, 2.0f},  // yellow: next patch
            {0.95f, 0.45f, 1.0f, 2.0f},  // magenta
            {0.35f, 0.8f, 1.0f, 2.0f},   // cyan
            {1.0f, 0.55f, 0.25f, 2.0f},  // orange
        };
        /// How often the flight plan is recomputed (wall seconds).
        constexpr sw::f64 kPredictionRefreshSeconds = 0.25;

        // ---- time warp -----------------------------------------------------------
        constexpr sw::f32 kWarpLadder[] = {1.0f,    2.0f,     5.0f,     10.0f,   50.0f,
                                           100.0f, 1000.0f, 10000.0f, 100000.0f};
        constexpr sw::u32 kWarpSteps = static_cast<sw::u32>(std::size(kWarpLadder));

        [[nodiscard]] sw::f32 maxWarpForAltitude(sw::f64 altitudeMeters)
        {
            if (altitudeMeters < 1.2e5) { return 1.0f; }
            if (altitudeMeters < 3.0e5) { return 10.0f; }
            if (altitudeMeters < 1.0e6) { return 100.0f; }
            if (altitudeMeters < 5.0e6) { return 1000.0f; }
            if (altitudeMeters < 2.0e7) { return 10000.0f; }
            return 100000.0f;
        }

        /// Sphere LOD resolutions, most to least detailed (rings, segments).
        constexpr sw::u32 kLodRings[CelestialLodComponent::kLodLevels] = {64, 32, 16, 8, 6};
        constexpr sw::u32 kLodSegments[CelestialLodComponent::kLodLevels] = {96, 48, 24, 12, 9};
        constexpr sw::f32 kLodScreenFractions[CelestialLodComponent::kLodLevels - 1] = {
            0.5f, 0.15f, 0.04f, 0.008f};

        constexpr sw::f32 kCubeBoundsRadius = 0.8660254f;
        constexpr const char* kGlyphCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,-+/%:";

        [[nodiscard]] sw::MeshData buildShipMesh()
        {
            using PF = sw::PrimitiveFactory;
            sw::MeshData ship = PF::makeBox({3.0f, 1.6f, 8.0f}, {0.72f, 0.74f, 0.78f, 1.0f});
            PF::append(ship, PF::makeBox({1.6f, 1.0f, 2.2f}, {0.25f, 0.55f, 0.75f, 1.0f}),
                       {0.0f, 2.2f, -4.5f});
            PF::append(ship, PF::makeBox({2.2f, 1.2f, 1.6f}, {0.30f, 0.30f, 0.33f, 1.0f}),
                       {0.0f, 0.0f, 9.0f});
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {4.0f, 0.0f, 2.0f});
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {-4.0f, 0.0f, 2.0f});
            return ship;
        }

        [[nodiscard]] sw::MeshData buildMarkerMesh()
        {
            // Markers are drawn EMISSIVE (tint alpha 2.0) — normals unused.
            return sw::PrimitiveFactory::makeOctahedron(1.0f, {1.0f, 1.0f, 1.0f, 1.0f});
        }

        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        // Far planes sized for the full system: the Sun must render from
        // Mars (3.8e11 m away when opposed). Reverse-Z keeps the precision.
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.5f, 1.0e13f);
        m_mapCamera.setPerspective(sw::math::toRadians(60.0f), 1.0e5f, 2.0e12f);
        m_glyphMeshIndex.fill(0xFFFFFFFFu);

        buildScene();
        buildGlyphMeshes();
        buildSaveSchema();
        m_celestialIndex.rebuild(m_world);

        const sw::WorldVec3 stationCenter =
            m_world.getComponent<TransformComponent>(m_terraEntity).position +
            sw::WorldVec3{0.0, 0.0, kStationOrbitRadius};
        m_cameraController.setPose(stationCenter + sw::WorldVec3{0.0, 250.0, 2000.0}, 0.0f,
                                   -0.08f);

        // ---- simulation lanes ---------------------------------------------------
        m_physicsLane = m_simulation.findLane("Physics");
        auto& physics = m_physicsLane->scheduler();
        // Celestials move FIRST: everything else this tick (gravity, rails,
        // anchors) reads their up-to-date positions/velocities.
        physics.addSystem(
            std::make_unique<sw::space::CelestialMotionSystem>(m_simulation));
        physics.addSystem(std::make_unique<SnapshotSystem>());
        // Rails ride at Physics rate too: their primaries move ~30 km/s, so
        // a 10 Hz refresh would visibly step (the closed-form solve is cheap).
        physics.addSystem(std::make_unique<sw::phys::RailsSystem>(m_simulation));
        physics.addSystem(std::make_unique<sw::phys::GravityIntegrationSystem>());
        physics.addSystem(std::make_unique<ThrustSystem>());
        sw::phys::SurfaceInteractionSystem::Config surfaceConfig{};
        physics.addSystem(
            std::make_unique<sw::phys::SurfaceInteractionSystem>(surfaceConfig));
        physics.addSystem(std::make_unique<CapsuleMovementSystem>());
        physics.addSystem(std::make_unique<SpinSystem>());
        physics.addSystem(std::make_unique<CelestialSpinSystem>());
        // After the celestial spin: surface bases co-rotate with their body.
        physics.addSystem(std::make_unique<sw::phys::SurfaceAnchorSystem>());

        auto& automation = m_simulation.findLane("Automation")->scheduler();
        automation.addSystem(std::make_unique<sw::factory::MinerSystem>());
        automation.addSystem(std::make_unique<sw::factory::RefinerySystem>());

        auto& logistics = m_simulation.findLane("Logistics")->scheduler();
        logistics.addSystem(std::make_unique<sw::factory::TransferSystem>());
        sw::phys::SimulationBubbleSystem::Config bubbleConfig{};
        bubbleConfig.enterRadius = kBubbleEnterRadius;
        bubbleConfig.exitRadius = kBubbleExitRadius;
        auto bubble = std::make_unique<sw::phys::SimulationBubbleSystem>(
            m_commands, m_simulation, bubbleConfig);
        m_bubbleSystem = bubble.get();
        logistics.addSystem(std::move(bubble));

        m_simulation.findLane("World")->scheduler().addSystem(
            std::make_unique<StatsSystem>());

        SW_LOG_INFO("Game", "Milestone 10 scene ready: {} entities", m_world.aliveCount());
        SW_LOG_INFO("Game",
                    "Controls: Tab pilot/free | G EVA capsule | M map (wheel zoom) | V "
                    "speed ORB/SRF | Shift/Ctrl throttle | ,/. warp | W/S A/D arrows Q/E "
                    "X | Space pause | Esc quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    CelestialLodComponent StarWorksGame::makeSphereLodSet(const sw::Vec4& color)
    {
        CelestialLodComponent lod{};
        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels; ++level)
        {
            lod.meshIndex[level] = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, kLodRings[level],
                                                   kLodSegments[level], color)));
        }
        return lod;
    }

    void StarWorksGame::buildGlyphMeshes()
    {
        for (const char* c = kGlyphCharset; *c != '\0'; ++c)
        {
            const sw::MeshData glyph = sw::ui::buildGlyphMesh(*c);
            if (!glyph.empty())
            {
                m_glyphMeshIndex[static_cast<sw::usize>(*c)] =
                    registerMesh(renderer().createMesh(glyph));
            }
        }
    }

    void StarWorksGame::buildScene()
    {
        // ---- meshes -------------------------------------------------------------
        // Sol's colors exceed 1.0 slightly: paired with the emissive tint it
        // reads as a glowing star, not a lit rock.
        const CelestialLodComponent solLod =
            makeSphereLodSet({1.0f, 0.92f, 0.72f, 1.0f});
        const CelestialLodComponent terraLod =
            makeSphereLodSet({0.21f, 0.33f, 0.48f, 1.0f});
        const CelestialLodComponent lunaLod =
            makeSphereLodSet({0.42f, 0.41f, 0.43f, 1.0f});
        const CelestialLodComponent marsLod =
            makeSphereLodSet({0.62f, 0.32f, 0.18f, 1.0f});

        sw::u32 asteroidMeshId = 0;
        sw::f32 asteroidBoundsRadius = 2.5f;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f})));
            asteroidBoundsRadius = 1.0f;
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        const sw::u32 shipMeshId = registerMesh(renderer().createMesh(buildShipMesh()));
        m_capsuleMeshIndex = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCapsule(0.5f, 0.5f, 12, 16,
                                              {0.9f, 0.6f, 0.2f, 1.0f})));
        m_markerMeshIndex = registerMesh(renderer().createMesh(buildMarkerMesh()));

        // Placeholder — the real direction (Sol -> camera area) is set
        // every frame in onUpdate.
        renderer().setSunDirection(glm::normalize(sw::Vec3{0.0f, -0.3f, -1.0f}));

        auto snapshotOf = [](const TransformComponent& transform) {
            return PreviousTransformComponent{transform.position, transform.rotation};
        };

        // ================= THE HIERARCHY: Sol -> Terra/Mars -> Luna ==============
        // Parent-relative Kepler elements, real values. Initial world
        // positions are the analytic evaluation at t=0 — identical to what
        // the CelestialMotionSystem will compute on the first tick.

        // ---- Sol: the static root ------------------------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{}; // world origin
            transform.uniformScale = static_cast<sw::f32>(kSolRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, solLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.9e-6f});
            m_world.addComponent(e, sw::phys::GravitySourceComponent{kMuSol, kSolRadius});
            m_world.addComponent(e, sw::space::makeCelestialBody("SOL"));
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.85f, 0.3f, 1.0f}});
            m_solEntity = e;
        }

        // ---- Terra: SOLID SURFACE + ATMOSPHERE, on rails around Sol --------------
        const sw::phys::KeplerOrbit terraOrbit = sw::phys::kepler::fromElements(
            kMuSol, kTerraSma, 0.0167, 0.0, 0.0, 0.0, /*M0=*/0.0, /*epoch=*/0.0);
        sw::WorldVec3 terraPos0{};
        sw::phys::kepler::evaluate(terraOrbit, 0.0, terraPos0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = terraPos0;
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, terraLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.2921e-5f});
            sw::phys::GravitySourceComponent gravity{kMuTerra, kTerraRadius};
            gravity.soiRadius = kTerraSoi;
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, sw::phys::AtmosphereComponent{1.225, 8500.0, 1.4e5});
            m_world.addComponent(e, sw::space::makeCelestialBody("TERRA", m_solEntity,
                                                                 &terraOrbit));
            m_world.addComponent(e, MapMarkerComponent{{0.35f, 0.65f, 1.0f, 1.0f}});
            m_terraEntity = e;
        }
        const sw::ecs::Entity terraEntity = m_terraEntity;

        // ---- Luna: around TERRA (5.14 deg inclination, real) ---------------------
        const sw::phys::KeplerOrbit lunaOrbit = sw::phys::kepler::fromElements(
            kMuTerra, kLunaSma, 0.0549, 0.0897, 0.0, 0.0, /*M0=*/0.6, /*epoch=*/0.0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::WorldVec3 lunaRel{};
            sw::phys::kepler::evaluate(lunaOrbit, 0.0, lunaRel);
            transform.position = terraPos0 + lunaRel;
            transform.uniformScale = static_cast<sw::f32>(kLunaRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, lunaLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.66e-6f});
            sw::phys::GravitySourceComponent gravity{kMuLuna, kLunaRadius};
            gravity.soiRadius = kLunaSoi;
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, sw::space::makeCelestialBody("LUNA", terraEntity,
                                                                 &lunaOrbit));
            m_world.addComponent(e, MapMarkerComponent{{0.75f, 0.75f, 0.78f, 1.0f}});
        }

        // ---- Mars: second planet, red and far -------------------------------------
        const sw::phys::KeplerOrbit marsOrbit = sw::phys::kepler::fromElements(
            kMuSol, kMarsSma, 0.0934, 0.0323, 0.0, 0.0, /*M0=*/2.0, /*epoch=*/0.0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(marsOrbit, 0.0, transform.position);
            transform.uniformScale = static_cast<sw::f32>(kMarsRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, marsLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.088e-5f});
            sw::phys::GravitySourceComponent gravity{kMuMars, kMarsRadius};
            gravity.soiRadius = kMarsSoi;
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, sw::space::makeCelestialBody("MARS", m_solEntity,
                                                                 &marsOrbit));
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.45f, 0.25f, 1.0f}});
        }

        // ============ EVERYTHING ELSE LIVES IN TERRA'S SOI ========================
        // Spawns are TERRA-relative: dynamic bodies add Terra's world
        // position and orbital velocity; rails objects simply reference
        // Terra as their primary (relative elements unchanged).
        sw::WorldVec3 terraVel0{};
        {
            sw::WorldVec3 unused{};
            sw::phys::kepler::evaluate(terraOrbit, 0.0, unused, &terraVel0);
        }
        const sw::WorldVec3 stationCenter =
            terraPos0 + sw::WorldVec3{0.0, 0.0, kStationOrbitRadius};

        // ---- GROUND OUTPOST: a mine built ON the planet surface -----------------
        // Anchored in Terra's rotating frame: it rides the planet's rotation
        // and survives save/load at its exact construction site — the model
        // every future surface factory will follow.
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.uniformScale = 40.0f; // 40 m mining rig
            m_world.addComponent(e, transform);
            m_world.addComponent(e, PreviousTransformComponent{});
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.35f, 0.3f, 1.0f}});
            m_world.addComponent(
                e, sw::phys::SurfaceAnchorComponent{
                       terraEntity, {0.0, 0.0, kTerraRadius + 18.0}}); // equator, +Z

            sw::factory::InventoryComponent pit{};
            pit.volumeCapacityM3 = 30.0;
            m_world.addComponent(e, pit);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 1.0, 0.0});
        }

        // ---- asteroid: dynamic body + mining site ---------------------------------
        sw::ecs::Entity asteroidEntity{};
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{650.0, 120.0, -300.0};
            transform.uniformScale = 120.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{asteroidBoundsRadius});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.05f});
            m_world.addComponent(e, MapMarkerComponent{{0.85f, 0.65f, 0.35f, 1.0f}});

            const sw::f64 radius = glm::length(transform.position - terraPos0);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(e, sw::phys::DynamicBodyComponent{
                                        terraVel0 + sw::WorldVec3{speed, 0.0, 0.0}, 5.0e8});

            sw::factory::InventoryComponent hopper{};
            hopper.volumeCapacityM3 = 40.0;
            m_world.addComponent(e, hopper);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 2.0, 0.0});
            asteroidEntity = e;
        }

        // ---- the player ship ---------------------------------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{-250.0, 60.0, 400.0};
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{13.0f});
            m_world.addComponent(e, MeshComponent{shipMeshId});
            m_world.addComponent(e, MapMarkerComponent{{0.3f, 1.0f, 0.5f, 1.0f}});
            m_world.addComponent(e, ShipComponent{});
            m_world.addComponent(e, ShipControlsComponent{});

            const sw::f64 radius = glm::length(transform.position - terraPos0);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(e, sw::phys::DynamicBodyComponent{
                                        terraVel0 + sw::WorldVec3{speed, 0.0, 0.0}, 5.0e4});
            m_shipEntity = e;
        }

        // ---- station modules (rails around TERRA) + refinery / depot ---------------
        sw::ecs::Entity refineryEntity{};
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f64 offset =
                (static_cast<sw::f64>(i) / kStationModuleCount - 0.5) * 1.0e-4;
            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, kStationOrbitRadius + (static_cast<sw::f64>(i) - 3.5) * 12.0,
                0.0, 0.0, 0.0, 0.0, kStationPhase + offset, 0.0);

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(orbit, 0.0, transform.position);
            transform.position += terraPos0;
            transform.uniformScale = 30.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            sw::phys::OnRailsComponent rails{};
            rails.orbit = orbit;
            rails.primary = terraEntity;
            rails.dynamicMass = 2.0e5; // a 200 t module, if ever de-railed
            m_world.addComponent(e, rails);
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f},
                                                  0.1f + hash01(i) * 0.1f});
            if (i == 0)
            {
                m_world.addComponent(e, MapMarkerComponent{{1.0f, 1.0f, 1.0f, 1.0f}});
                sw::factory::InventoryComponent tanks{};
                tanks.volumeCapacityM3 = 15.0;
                m_world.addComponent(e, tanks);
                m_world.addComponent(e, sw::factory::RefineryComponent{
                                            sw::res::Resource::IronOre,
                                            sw::res::Resource::Iron, 1.0, 0.9, 0.0});
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            asteroidEntity, sw::res::Resource::IronOre,
                                            1.5});
                refineryEntity = e;
            }
            else if (i == 1)
            {
                sw::factory::InventoryComponent silo{};
                silo.volumeCapacityM3 = 60.0;
                m_world.addComponent(e, silo);
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            refineryEntity, sw::res::Resource::Iron, 1.0});
            }
        }
    }

    void StarWorksGame::buildSaveSchema()
    {
        // Stable names + versions. Bump a version whenever the struct layout
        // changes; the loader refuses mismatches instead of guessing.
        m_saveSchema.registerComponent<sw::TransformComponent>("sw.Transform", 1);
        m_saveSchema.registerComponent<sw::PreviousTransformComponent>(
            "sw.PreviousTransform", 1);
        m_saveSchema.registerComponent<sw::phys::DynamicBodyComponent>("phys.DynamicBody",
                                                                       1);
        // v2: primary-relative orbit + primary handle + dynamic payload.
        m_saveSchema.registerComponent<sw::phys::OnRailsComponent>("phys.OnRails", 2);
        // v2: SOI radius + world velocity.
        m_saveSchema.registerComponent<sw::phys::GravitySourceComponent>(
            "phys.GravitySource", 2);
        m_saveSchema.registerComponent<sw::space::CelestialBodyComponent>(
            "space.CelestialBody", 1);
        m_saveSchema.registerComponent<sw::phys::AtmosphereComponent>("phys.Atmosphere", 1);
        m_saveSchema.registerComponent<sw::phys::SurfaceAnchorComponent>(
            "phys.SurfaceAnchor", 1);
        m_saveSchema.registerComponent<sw::factory::InventoryComponent>("factory.Inventory",
                                                                        1);
        m_saveSchema.registerComponent<sw::factory::MinerComponent>("factory.Miner", 1);
        m_saveSchema.registerComponent<sw::factory::RefineryComponent>("factory.Refinery",
                                                                       1);
        m_saveSchema.registerComponent<sw::factory::ItemLinkComponent>("factory.ItemLink",
                                                                       1);
        m_saveSchema.registerComponent<BoundsComponent>("game.Bounds", 1);
        m_saveSchema.registerComponent<SpinComponent>("game.Spin", 1);
        m_saveSchema.registerComponent<MeshComponent>("game.Mesh", 1);
        m_saveSchema.registerComponent<CelestialLodComponent>("game.CelestialLod", 1);
        m_saveSchema.registerComponent<ShipComponent>("game.Ship", 1);
        m_saveSchema.registerComponent<ShipControlsComponent>("game.ShipControls", 1);
        m_saveSchema.registerComponent<CapsuleComponent>("game.Capsule", 1);
        m_saveSchema.registerComponent<MapMarkerComponent>("game.MapMarker", 1);
    }

    void StarWorksGame::saveGame()
    {
        sw::ser::BinaryWriter writer;
        writer.write<sw::u32>(0x53575347); // "SWSG"
        writer.write<sw::u32>(2);          // game save version (2: Milestone 10)

        sw::save::saveWorld(m_world, m_saveSchema, writer);
        sw::save::saveSimulation(m_simulation, writer);

        // Player/session state.
        writer.write(m_shipEntity);
        writer.write(m_capsuleEntity);
        writer.write(static_cast<sw::u8>(m_evaMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_shipMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_speedSurfaceRelative ? 1 : 0));
        writer.write(m_warpIndex);
        writer.write(m_mapHeightMeters);
        writer.write(m_camera.position());
        writer.write(m_camera.orientation());

        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        sw::FileSystem::writeBinaryFile(path, writer.bytes());
        SW_LOG_INFO("Game", "Saved to '{}' ({} KB, {} entities, t={:.1f}s)", path.string(),
                    writer.size() / 1024, m_world.aliveCount(),
                    m_simulation.simulatedSeconds());
    }

    void StarWorksGame::loadGame()
    {
        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        const std::vector<sw::u8> bytes = sw::FileSystem::readBinaryFile(path);
        sw::ser::BinaryReader reader(bytes);

        if (reader.read<sw::u32>() != 0x53575347)
        {
            SW_THROW("'{}' is not a StarWorks save", path.string());
        }
        if (const sw::u32 version = reader.read<sw::u32>(); version != 2)
        {
            SW_THROW("Unsupported save version {}", version);
        }

        sw::save::loadWorld(m_world, m_saveSchema, reader);
        sw::save::loadSimulation(m_simulation, reader);
        m_celestialIndex.rebuild(m_world);
        m_lastPredictionSeconds = -1.0e9; // stale flight plan: recompute

        m_shipEntity = reader.read<sw::ecs::Entity>();
        m_capsuleEntity = reader.read<sw::ecs::Entity>();
        m_evaMode = reader.read<sw::u8>() != 0;
        m_shipMode = reader.read<sw::u8>() != 0;
        m_speedSurfaceRelative = reader.read<sw::u8>() != 0;
        m_warpIndex = reader.read<sw::u32>();
        m_mapHeightMeters = reader.read<sw::f64>();
        m_camera.setPosition(reader.read<sw::WorldVec3>());
        m_camera.setOrientation(reader.read<sw::Quat>());

        if (!m_shipMode)
        {
            const sw::Vec3 forward = m_camera.forward();
            m_cameraController.setPose(
                m_camera.position(), std::atan2(-forward.x, -forward.z),
                std::asin(std::clamp(forward.y, -1.0f, 1.0f)));
        }

        SW_LOG_INFO("Game", "Loaded '{}': {} entities, t={:.1f}s, warp x{:g}",
                    path.string(), m_world.aliveCount(), m_simulation.simulatedSeconds(),
                    kWarpLadder[m_warpIndex]);
    }

    sw::ecs::Entity StarWorksGame::controlledEntity() const
    {
        return (m_evaMode && !m_capsuleEntity.isNull()) ? m_capsuleEntity : m_shipEntity;
    }

    sw::WorldVec3 StarWorksGame::controlledVelocity() const
    {
        const sw::ecs::Entity entity = controlledEntity();
        auto& world = const_cast<sw::ecs::World&>(m_world);
        if (const auto* body =
                world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity))
        {
            return body->velocity;
        }
        if (const auto* rails = world.tryGetComponent<sw::phys::OnRailsComponent>(entity))
        {
            sw::WorldVec3 position{};
            sw::WorldVec3 velocity{};
            sw::phys::kepler::evaluate(rails->orbit, m_simulation.simulatedSeconds(),
                                       position, &velocity);
            // The orbit is primary-relative: add the primary's own motion.
            if (const auto* primary = world.tryGetComponent<sw::phys::GravitySourceComponent>(
                    rails->primary))
            {
                velocity += primary->worldVelocity;
            }
            return velocity;
        }
        return {0.0, 0.0, 0.0};
    }

    sw::i32 StarWorksGame::controlledPrimaryIndex() const
    {
        if (m_celestialIndex.size() == 0)
        {
            return -1;
        }
        const auto& transform = const_cast<sw::ecs::World&>(m_world)
                                    .getComponent<TransformComponent>(controlledEntity());
        return m_celestialIndex.soiPrimaryAt(transform.position,
                                             m_simulation.simulatedSeconds());
    }

    void StarWorksGame::refreshPrediction()
    {
        // The flight plan is a pure function of current state — recomputing
        // a few times per second is plenty (and each run costs ~ms).
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastPredictionSeconds < kPredictionRefreshSeconds)
        {
            return;
        }
        m_lastPredictionSeconds = now;

        const sw::ecs::Entity entity = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(entity);
        sw::space::PredictionSettings settings{};
        sw::space::predictTrajectory(m_celestialIndex, transform.position,
                                     controlledVelocity(),
                                     m_simulation.simulatedSeconds(), settings,
                                     m_prediction);
    }

    void StarWorksGame::toggleEva()
    {
        if (!m_evaMode && m_capsuleEntity.isNull())
        {
            // First EVA: spawn the capsule beside the ship, co-moving.
            const auto& shipTransform =
                m_world.getComponent<TransformComponent>(m_shipEntity);
            const sw::WorldVec3 shipVelocity = controlledVelocity();

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = shipTransform.position +
                                 sw::WorldVec3(shipTransform.rotation *
                                               sw::Vec3{12.0f, 0.0f, 0.0f});
            m_world.addComponent(
                e, PreviousTransformComponent{transform.position, transform.rotation});
            m_world.addComponent(e, transform);
            m_world.addComponent(e, BoundsComponent{1.2f});
            m_world.addComponent(e, MeshComponent{m_capsuleMeshIndex});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.8f, 0.2f, 1.0f}});
            m_world.addComponent(e, CapsuleComponent{});
            m_world.addComponent(e, ShipControlsComponent{});
            sw::phys::DynamicBodyComponent body{};
            body.velocity = shipVelocity;
            body.mass = 120.0;
            body.ballisticFactor = 0.01; // draggier than the ship
            m_world.addComponent(e, body);
            m_capsuleEntity = e;
        }
        m_evaMode = !m_evaMode;
        SW_LOG_INFO("Game", "{}", m_evaMode ? "EVA: controlling capsule"
                                            : "Back aboard: controlling ship");
    }

    void StarWorksGame::updateWarp()
    {
        if (input().wasKeyPressed(sw::KeyCode::Period) && m_warpIndex + 1 < kWarpSteps)
        {
            ++m_warpIndex;
        }
        if (input().wasKeyPressed(sw::KeyCode::Comma) && m_warpIndex > 0)
        {
            --m_warpIndex;
        }

        const sw::WorldVec3 focusPosition =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;
        sw::f64 minAltitude = 1.0e18;
        m_world.forEach<TransformComponent, sw::phys::GravitySourceComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                sw::phys::GravitySourceComponent& source) {
                const sw::f64 altitude =
                    glm::length(focusPosition - transform.position) - source.bodyRadius;
                minAltitude = std::min(minAltitude, altitude);
            });

        const sw::f32 maxAllowed = maxWarpForAltitude(minAltitude);
        while (m_warpIndex > 0 && kWarpLadder[m_warpIndex] > maxAllowed)
        {
            --m_warpIndex;
            SW_LOG_INFO("Game", "Warp limited to x{:g} (altitude {:.0f} km)",
                        kWarpLadder[m_warpIndex], minAltitude / 1000.0);
        }

        m_simulation.setTimeScale(kWarpLadder[m_warpIndex]);
        m_bubbleSystem->setForceRails(m_warpIndex > 0);
    }

    void StarWorksGame::updateShipControls()
    {
        // Idle both control blocks, then feed the controlled one.
        auto& shipControls = m_world.getComponent<ShipControlsComponent>(m_shipEntity);
        shipControls = {};
        ShipControlsComponent* capsuleControls = nullptr;
        if (!m_capsuleEntity.isNull())
        {
            capsuleControls =
                m_world.tryGetComponent<ShipControlsComponent>(m_capsuleEntity);
            if (capsuleControls != nullptr)
            {
                *capsuleControls = {};
            }
        }

        if (!m_shipMode || m_mapView || m_warpIndex > 0)
        {
            return; // engines idle when not piloting (or while warping)
        }

        ShipControlsComponent& controls =
            (m_evaMode && capsuleControls != nullptr) ? *capsuleControls : shipControls;

        if (input().isKeyDown(sw::KeyCode::W)) { controls.thrustAxis += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::S)) { controls.thrustAxis -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Up)) { controls.rotationInput.x -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Down)) { controls.rotationInput.x += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::A)) { controls.rotationInput.y += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::D)) { controls.rotationInput.y -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Q)) { controls.rotationInput.z += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::E)) { controls.rotationInput.z -= 1.0f; }
        controls.killRotation = input().isKeyDown(sw::KeyCode::X) ? 1u : 0u;
        // Throttle limiter (ship only; the capsule ignores it).
        if (input().isKeyDown(sw::KeyCode::LeftShift)) { controls.throttleDelta += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::LeftControl))
        {
            controls.throttleDelta -= 1.0f;
        }
    }

    void StarWorksGame::updateChaseCamera()
    {
        const sw::ecs::Entity target = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(target);
        const auto& previous = m_world.getComponent<PreviousTransformComponent>(target);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::WorldVec3 position =
            glm::mix(previous.position, transform.position, static_cast<sw::f64>(alpha));
        const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);

        const sw::Vec3 chaseOffset =
            m_evaMode ? sw::Vec3{0.0f, 2.0f, 9.0f} : sw::Vec3{0.0f, 12.0f, 42.0f};
        const sw::WorldVec3 cameraPosition =
            position + sw::WorldVec3(rotation * chaseOffset);
        m_camera.setPosition(cameraPosition);

        const sw::Vec3 forward = glm::normalize(sw::Vec3(position - cameraPosition));
        const sw::Vec3 targetUp = rotation * sw::Vec3{0.0f, 1.0f, 0.0f};
        const sw::Vec3 right = glm::normalize(glm::cross(forward, targetUp));
        const sw::Vec3 up = glm::cross(right, forward);
        m_camera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        // --- mode toggles -------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::M))
        {
            m_mapView = !m_mapView;
            SW_LOG_INFO("Game", "Star map {}", m_mapView ? "opened" : "closed");
        }
        if (input().wasKeyPressed(sw::KeyCode::G) && !m_mapView)
        {
            toggleEva();
        }
        if (input().wasKeyPressed(sw::KeyCode::V))
        {
            m_speedSurfaceRelative = !m_speedSurfaceRelative;
        }
        if (input().wasKeyPressed(sw::KeyCode::Tab))
        {
            m_shipMode = !m_shipMode;
            if (!m_shipMode)
            {
                const sw::Vec3 forward = m_camera.forward();
                const sw::f32 yaw = std::atan2(-forward.x, -forward.z);
                const sw::f32 pitch = std::asin(std::clamp(forward.y, -1.0f, 1.0f));
                m_cameraController.setPose(m_camera.position(), yaw, pitch);
            }
            SW_LOG_INFO("Game", "{}", m_shipMode ? "Chase camera" : "Free camera");
        }
        if (input().wasKeyPressed(sw::KeyCode::Space))
        {
            m_simulation.setPaused(!m_simulation.isPaused());
            SW_LOG_INFO("Game", "Simulation {}", m_simulation.isPaused() ? "paused" : "resumed");
        }

        // --- save / load ----------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::F5))
        {
            try
            {
                saveGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Save failed: {}", e.message());
            }
        }
        if (input().wasKeyPressed(sw::KeyCode::F9))
        {
            try
            {
                loadGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Load failed: {}", e.message());
            }
        }

        updateWarp();

        // --- per-mode camera & controls ------------------------------------------
        if (m_mapView)
        {
            const sw::f32 scroll = input().scrollDeltaY();
            if (scroll != 0.0f)
            {
                m_mapHeightMeters = std::clamp(
                    m_mapHeightMeters * std::pow(1.3, static_cast<sw::f64>(-scroll)),
                    kMapMinHeight, kMapMaxHeight);
            }
            // KSP-style framing: the map centers on the SOI primary of the
            // controlled craft — Terra view at LEO, Sol view once you leave
            // Terra's sphere of influence.
            sw::WorldVec3 mapCenter{0.0};
            if (const sw::i32 primaryIndex = controlledPrimaryIndex(); primaryIndex >= 0)
            {
                mapCenter = m_celestialIndex.positionAt(primaryIndex,
                                                        m_simulation.simulatedSeconds());
            }
            m_mapCamera.setPosition(mapCenter + sw::WorldVec3{0.0, m_mapHeightMeters, 0.0});
            m_mapCamera.setOrientation(
                glm::quat_cast(sw::Mat3{{1, 0, 0}, {0, 0, -1}, {0, 1, 0}}));
            m_mapCamera.setAspectRatio(renderer().aspectRatio());
        }
        else if (!m_shipMode)
        {
            m_cameraController.update(input(), window(), deltaSeconds);
        }
        m_camera.setAspectRatio(renderer().aspectRatio());

        updateShipControls();

        m_bubbleSystem->setFocus(
            m_world.getComponent<TransformComponent>(controlledEntity()).position);

        m_simulation.advance(m_world, deltaSeconds, &threadPool());
        m_commands.playback(m_world);

        // Fresh hierarchy snapshot for the map, HUD and flight plan.
        m_celestialIndex.rebuild(m_world);
        refreshPrediction();

        // The light really comes from Sol now.
        if (const auto* sol = m_world.tryGetComponent<TransformComponent>(m_solEntity))
        {
            const sw::WorldVec3 toScene = m_camera.position() - sol->position;
            const sw::f64 length = glm::length(toScene);
            if (length > 1.0)
            {
                renderer().setSunDirection(sw::Vec3(toScene / length));
            }
        }

        if (m_shipMode && !m_mapView)
        {
            updateChaseCamera();
        }

        // --- periodic statistics ------------------------------------------------
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastStatsLogSeconds > 5.0)
        {
            m_lastStatsLogSeconds = now;
            const sw::RenderStats& stats = renderer().stats();
            SW_LOG_INFO("Game",
                        "render: {} submitted, {} culled, {} instances in {} draw calls | "
                        "sim: {} dynamic / {} rails, warp x{:g} ({:.0f} FPS, prepare "
                        "{:.1f} ms)",
                        stats.itemsSubmitted, stats.itemsCulled, stats.instancesDrawn,
                        stats.drawCalls, m_world.count<sw::phys::DynamicBodyComponent>(),
                        m_world.count<sw::phys::OnRailsComponent>(),
                        kWarpLadder[m_warpIndex], clock().smoothedFps(),
                        stats.cpuPrepareMs);
        }
    }

    sw::u32 StarWorksGame::selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const
    {
        const sw::f64 clampedDistance = std::max(distance, worldRadius * 1.0001);
        const sw::f64 angularDiameter = 2.0 * std::atan(worldRadius / clampedDistance);
        const sw::f32 fraction =
            static_cast<sw::f32>(angularDiameter) / m_camera.verticalFov();

        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels - 1; ++level)
        {
            if (fraction >= kLodScreenFractions[level])
            {
                return level;
            }
        }
        return CelestialLodComponent::kLodLevels - 1;
    }

    void StarWorksGame::hudText(std::string_view text, sw::f32 x, sw::f32 y,
                                sw::f32 heightNdc, const sw::Vec4& color)
    {
        const sw::f32 aspect = renderer().aspectRatio();
        const sw::f32 scaleX = (5.0f / 7.0f) * heightNdc / aspect;
        const sw::f32 advance = sw::ui::kGlyphAdvance * heightNdc / aspect;

        sw::f32 penX = x;
        for (const char character : text)
        {
            const auto index = static_cast<sw::usize>(
                static_cast<unsigned char>(std::toupper(character)));
            const sw::u32 meshIndex =
                (index < m_glyphMeshIndex.size()) ? m_glyphMeshIndex[index] : 0xFFFFFFFFu;
            if (meshIndex != 0xFFFFFFFFu)
            {
                sw::DrawItem item{};
                item.mesh = &m_meshes[meshIndex];
                item.transform = glm::translate(sw::Mat4{1.0f}, {penX, y, 0.0f}) *
                                 glm::scale(sw::Mat4{1.0f}, {scaleX, heightNdc, 1.0f});
                item.screenSpace = true;
                item.tint = color;
                m_drawItems.push_back(item);
            }
            penX += advance;
        }
    }

    void StarWorksGame::collectHud()
    {
        constexpr sw::f32 kLine = 0.052f;
        constexpr sw::f32 kX = -0.98f;
        sw::f32 y = -0.97f;
        const sw::Vec4 main{0.65f, 0.95f, 0.75f, 0.95f};
        const sw::Vec4 dim{0.55f, 0.75f, 0.85f, 0.9f};

        // ---- mode ----------------------------------------------------------------
        const char* mode = m_mapView ? "MAP" : (m_evaMode ? "EVA" : "NAV");
        hudText(std::format("{} {}", mode, m_shipMode || m_mapView ? "" : "CAM LIBRE"), kX,
                y, kLine, main);
        y += kLine * 1.3f;

        // ---- speed & altitude, relative to the current SOI PRIMARY ---------------
        const sw::WorldVec3 velocity = controlledVelocity();
        const sw::WorldVec3 position =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;

        const sw::f64 time = m_simulation.simulatedSeconds();
        const sw::i32 primaryIndex = controlledPrimaryIndex();
        const char* primaryName = "-";
        sw::WorldVec3 primaryPosition{0.0};
        sw::WorldVec3 primaryVelocity{0.0};
        sw::f64 primaryRadius = 0.0;
        bool primaryIsTerra = false;
        if (primaryIndex >= 0)
        {
            const auto& primary = m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
            primaryName = primary.name;
            primaryRadius = primary.bodyRadius;
            primaryIsTerra = primary.entity == m_terraEntity;
            m_celestialIndex.stateAt(primaryIndex, time, primaryPosition,
                                     &primaryVelocity);
        }

        sw::f64 speed = 0.0;
        if (m_speedSurfaceRelative)
        {
            // Surface velocity: the primary's own motion + its rotation at
            // this position (only Terra spins fast enough to matter).
            sw::WorldVec3 surfaceVelocity = primaryVelocity;
            if (primaryIsTerra)
            {
                surfaceVelocity +=
                    glm::cross(kTerraAngularVelocity, position - primaryPosition);
            }
            speed = glm::length(velocity - surfaceVelocity);
        }
        else
        {
            speed = glm::length(velocity - primaryVelocity); // orbital speed
        }
        hudText(std::format("SPD {} {:.1f} M/S", m_speedSurfaceRelative ? "SRF" : "ORB",
                            speed),
                kX, y, kLine, main);
        y += kLine * 1.3f;

        // ---- altitude above the primary -------------------------------------------
        const sw::f64 altitude =
            glm::length(position - primaryPosition) - primaryRadius;
        hudText(std::format("ALT {} {:.1f} KM", primaryName, altitude / 1000.0), kX, y,
                kLine, main);
        y += kLine * 1.3f;

        // ---- throttle + warp -----------------------------------------------------------
        const auto& ship = m_world.getComponent<ShipComponent>(m_shipEntity);
        hudText(std::format("THR {:.0f}%  WARP X{:g}", ship.throttle * 100.0f,
                            kWarpLadder[m_warpIndex]),
                kX, y, kLine, dim);
        y += kLine * 1.3f;

        // ---- flight-plan events (KSP style): the first upcoming transition --------
        for (const sw::space::TrajectorySegment& segment : m_prediction)
        {
            const char* label = nullptr;
            sw::Vec4 color = dim;
            switch (segment.endReason)
            {
            case sw::space::SegmentEnd::Encounter:
                label = "ENC";
                color = {0.4f, 1.0f, 0.9f, 0.95f};
                break;
            case sw::space::SegmentEnd::Impact:
                label = "IMPACT";
                color = {1.0f, 0.35f, 0.3f, 0.95f};
                break;
            case sw::space::SegmentEnd::SoiExit:
                label = "EXIT TO";
                color = {1.0f, 0.85f, 0.4f, 0.95f};
                break;
            default:
                break;
            }
            if (label == nullptr || segment.eventBodyIndex < 0)
            {
                continue;
            }
            const auto& eventBody =
                m_celestialIndex.body(static_cast<sw::usize>(segment.eventBodyIndex));
            const sw::f64 eta = segment.endTime - time;
            hudText(std::format("{} {} T-{:.0f} S", label, eventBody.name,
                                std::max(eta, 0.0)),
                    kX, y, kLine, color);
            y += kLine * 1.3f;
        }
    }

    void StarWorksGame::collectMapTrajectories(const sw::Camera& activeCamera)
    {
        const sw::WorldVec3 cameraPosition = activeCamera.position();
        const sw::f32 markerFactor =
            kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);
        const sw::f64 time = m_simulation.simulatedSeconds();

        // One dot of the dotted trajectory (emissive: tint alpha 2.0).
        auto plotDot = [&](const sw::WorldVec3& point, const sw::Vec4& color,
                           sw::f32 sizeMultiplier) {
            const sw::Vec3 relative = sw::Vec3(point - cameraPosition);
            const sw::f32 scale =
                glm::length(relative) * markerFactor * 0.22f * sizeMultiplier;
            sw::DrawItem item{};
            item.mesh = &m_meshes[m_markerMeshIndex];
            item.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                             glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
            item.boundsCenter = relative;
            item.boundsRadius = scale;
            item.tint = {color.r, color.g, color.b, 2.0f};
            m_drawItems.push_back(item);
        };

        // Samples a conic around a primary's CURRENT world position over
        // [t0, t1] — KSP map convention: patches are drawn in the frame of
        // where their primary is NOW.
        auto plotConic = [&](const sw::phys::KeplerOrbit& orbit,
                             const sw::WorldVec3& primaryPosition, const sw::Vec4& color,
                             sw::f64 t0, sw::f64 t1, sw::u32 samples) {
            for (sw::u32 sample = 0; sample < samples; ++sample)
            {
                const sw::f64 ts =
                    t0 + (t1 - t0) * static_cast<sw::f64>(sample) / samples;
                sw::WorldVec3 relativePoint{};
                sw::phys::kepler::evaluate(orbit, ts, relativePoint);
                plotDot(primaryPosition + relativePoint, color, 1.0f);
            }
        };

        // Full closed orbit (elliptic only).
        auto plotFullOrbit = [&](const sw::phys::KeplerOrbit& orbit,
                                 const sw::WorldVec3& primaryPosition,
                                 const sw::Vec4& color) {
            if (!orbit.isHyperbolic())
            {
                plotConic(orbit, primaryPosition, color, time,
                          time + sw::phys::kepler::period(orbit), kTrajectorySamples);
            }
        };

        // ---- celestial orbits: each body around its parent's current position --
        for (sw::usize i = 0; i < m_celestialIndex.size(); ++i)
        {
            const auto& body = m_celestialIndex.body(i);
            if (body.hasOrbit == 0 || body.parentIndex < 0)
            {
                continue;
            }
            sw::Vec4 color{0.5f, 0.5f, 0.55f, 1.0f};
            if (const auto* marker = m_world.tryGetComponent<MapMarkerComponent>(
                    body.entity))
            {
                color = marker->color * 0.6f;
            }
            plotFullOrbit(body.orbit,
                          m_celestialIndex.positionAt(body.parentIndex, time), color);
        }

        // ---- generic rails objects (station modules...) --------------------------
        m_world.forEach<sw::phys::OnRailsComponent, MapMarkerComponent>(
            [&](sw::ecs::Entity entity, sw::phys::OnRailsComponent& rails,
                MapMarkerComponent& marker) {
                if (entity == controlledEntity())
                {
                    return; // the controlled craft gets the full flight plan
                }
                sw::WorldVec3 primaryPosition{0.0};
                if (const auto* primaryTransform =
                        m_world.tryGetComponent<TransformComponent>(rails.primary))
                {
                    primaryPosition = primaryTransform->position;
                }
                plotFullOrbit(rails.orbit, primaryPosition, marker.color * 0.6f);
            });

        // ---- other dynamic objects: single conic around their SOI primary --------
        m_world.forEach<TransformComponent, sw::phys::DynamicBodyComponent,
                        MapMarkerComponent>(
            [&](sw::ecs::Entity entity, TransformComponent& transform,
                sw::phys::DynamicBodyComponent& body, MapMarkerComponent& marker) {
                if (entity == controlledEntity() || m_celestialIndex.size() == 0)
                {
                    return;
                }
                const sw::i32 primaryIndex =
                    m_celestialIndex.soiPrimaryAt(transform.position, time);
                if (primaryIndex < 0)
                {
                    return;
                }
                const auto& primary =
                    m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
                sw::WorldVec3 primaryPosition{};
                sw::WorldVec3 primaryVelocity{};
                m_celestialIndex.stateAt(primaryIndex, time, primaryPosition,
                                         &primaryVelocity);
                sw::phys::KeplerOrbit orbit{};
                if (sw::phys::kepler::fromStateVectors(
                        primary.mu, transform.position - primaryPosition,
                        body.velocity - primaryVelocity, time, orbit))
                {
                    plotFullOrbit(orbit, primaryPosition, marker.color * 0.6f);
                }
            });

        // ---- THE FLIGHT PLAN: patched-conics prediction of the controlled craft --
        for (sw::usize segmentIndex = 0; segmentIndex < m_prediction.size();
             ++segmentIndex)
        {
            const sw::space::TrajectorySegment& segment = m_prediction[segmentIndex];
            if (segment.primaryIndex < 0 ||
                segment.endReason == sw::space::SegmentEnd::Lost)
            {
                continue;
            }
            const sw::Vec4 color =
                kPatchColors[std::min(segmentIndex, std::size(kPatchColors) - 1)];
            const sw::WorldVec3 primaryPosition =
                m_celestialIndex.positionAt(segment.primaryIndex, time);

            // A closed, event-free orbit draws one full revolution; every
            // other patch draws exactly its [start, end] arc.
            sw::f64 t1 = segment.endTime;
            if (segment.endReason == sw::space::SegmentEnd::Horizon &&
                !segment.orbit.isHyperbolic())
            {
                t1 = std::min(segment.endTime,
                              segment.startTime + sw::phys::kepler::period(segment.orbit));
            }
            plotConic(segment.orbit, primaryPosition, color, segment.startTime, t1,
                      kPredictionDisplaySamples);

            // Event marker at the patch hand-off point.
            sw::Vec4 eventColor{};
            bool hasEvent = true;
            switch (segment.endReason)
            {
            case sw::space::SegmentEnd::Encounter:
                eventColor = {0.4f, 1.0f, 0.9f, 1.0f};
                break;
            case sw::space::SegmentEnd::Impact:
                eventColor = {1.0f, 0.25f, 0.2f, 1.0f};
                break;
            case sw::space::SegmentEnd::SoiExit:
                eventColor = {1.0f, 0.85f, 0.4f, 1.0f};
                break;
            default:
                hasEvent = false;
                break;
            }
            if (hasEvent)
            {
                sw::WorldVec3 eventRelative{};
                sw::phys::kepler::evaluate(segment.orbit, segment.endTime, eventRelative);
                plotDot(primaryPosition + eventRelative, eventColor, 3.0f);
            }
        }
    }

    void StarWorksGame::collectDrawItems(const sw::Camera& activeCamera, bool mapView)
    {
        m_drawItems.clear();
        m_drawItems.reserve(m_world.aliveCount() + 512);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::f64 alpha64 = static_cast<sw::f64>(alpha);
        const sw::WorldVec3 cameraPosition = activeCamera.position();

        auto makeTransform = [&](const TransformComponent& transform,
                                 const PreviousTransformComponent& previous,
                                 sw::Vec3& outRelative) {
            const sw::WorldVec3 position =
                glm::mix(previous.position, transform.position, alpha64);
            const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);
            outRelative = sw::Vec3(position - cameraPosition);
            return glm::translate(sw::Mat4{1.0f}, outRelative) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{transform.uniformScale});
        };

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        MeshComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                MeshComponent& mesh) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                m_drawItems.push_back({&m_meshes[mesh.meshIndex], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        CelestialLodComponent>(
            [&](sw::ecs::Entity entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                CelestialLodComponent& lod) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                const sw::f64 worldRadius = static_cast<sw::f64>(transform.uniformScale);
                const sw::f64 distance =
                    glm::length(transform.position - cameraPosition);
                const sw::u32 level = selectLodLevel(distance, worldRadius);
                sw::DrawItem item{&m_meshes[lod.meshIndex[level]], model, relative,
                                  bounds.localRadius * transform.uniformScale};
                if (entity == m_solEntity)
                {
                    // The star is self-lit (emissive tint convention).
                    item.tint = {1.0f, 0.96f, 0.82f, 2.0f};
                }
                m_drawItems.push_back(item);
            });

        if (mapView)
        {
            const sw::f32 markerFactor =
                kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);

            m_world.forEach<TransformComponent, BoundsComponent, MapMarkerComponent>(
                [&](sw::ecs::Entity, TransformComponent& transform, BoundsComponent& bounds,
                    MapMarkerComponent& marker) {
                    const sw::WorldVec3 toCamera = cameraPosition - transform.position;
                    const sw::f64 distance = glm::length(toCamera);
                    if (distance < 1.0)
                    {
                        return;
                    }
                    const sw::f64 surfaceOffset =
                        static_cast<sw::f64>(bounds.localRadius * transform.uniformScale) *
                        1.05;
                    const sw::WorldVec3 beaconPosition =
                        transform.position + (toCamera / distance) * surfaceOffset;

                    const sw::f32 scale =
                        static_cast<sw::f32>(glm::length(beaconPosition - cameraPosition)) *
                        markerFactor;
                    const sw::Vec3 relative = sw::Vec3(beaconPosition - cameraPosition);
                    const sw::Mat4 model = glm::translate(sw::Mat4{1.0f}, relative) *
                                           glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                    m_drawItems.push_back(
                        {&m_meshes[m_markerMeshIndex], model, relative, scale,
                         {marker.color.r, marker.color.g, marker.color.b, 2.0f}});
                });

            collectMapTrajectories(activeCamera);
        }

        collectHud();
    }

    void StarWorksGame::onRender()
    {
        const sw::Camera& activeCamera = m_mapView ? m_mapCamera : m_camera;
        collectDrawItems(activeCamera, m_mapView);
        renderer().renderFrame(activeCamera, m_drawItems);
    }
} // namespace game
