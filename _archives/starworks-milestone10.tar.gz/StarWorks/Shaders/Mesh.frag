#version 450

// ============================================================================
// Mesh.frag — Lambert diffuse + ambient, in linear space (sRGB swapchain
// performs the final gamma encoding). Placeholder until the PBR pipeline.
// ============================================================================

layout(set = 0, binding = 0) uniform CameraUniforms
{
    mat4 viewProjection;
    vec4 cameraPosition;
    vec4 sunDirection;
} uCamera;

layout(location = 0) in vec3 vWorldNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUv;
layout(location = 3) in vec3 vWorldPosition;

layout(location = 0) out vec4 outColor;

const vec3 kSunColor = vec3(1.0, 0.96, 0.9);
const vec3 kAmbient = vec3(0.03, 0.035, 0.05); // faint cold space ambient

void main()
{
    // EMISSIVE convention: a tint alpha > 1.5 marks self-lit geometry (the
    // star itself, map beacons, trajectory dots) — rendered at full color,
    // independent of the sun. Cheap flag until a real material system.
    if (vColor.a > 1.5)
    {
        outColor = vec4(vColor.rgb, 1.0);
        return;
    }

    const vec3 normal = normalize(vWorldNormal);
    const float lambert = max(dot(normal, -uCamera.sunDirection.xyz), 0.0);

    const vec3 lit = vColor.rgb * (kAmbient + kSunColor * lambert);
    outColor = vec4(lit, vColor.a);
}
