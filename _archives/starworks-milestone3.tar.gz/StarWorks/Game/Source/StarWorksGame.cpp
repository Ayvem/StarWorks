#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <cmath>

namespace game
{
    namespace
    {
        constexpr sw::u32 kStationModuleCount = 8;
        constexpr sw::f32 kStationRingRadius = 6.0f;
        constexpr sw::u32 kDebrisCount = 140;

        /// Deterministic pseudo-random in [0, 1) — scene layout must be
        /// reproducible run to run (and later, from a save file).
        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.1f, 10000.0f);
        m_cameraController.setPose({0.0f, 4.0f, 18.0f}, 0.0f, -0.12f);

        buildScene();

        m_scheduler.addSystem(std::make_unique<OrbitSystem>());
        m_scheduler.addSystem(std::make_unique<SpinSystem>());
        SW_LOG_INFO("Game", "ECS scene ready: {} entities, {} systems in {} stage(s)",
                    m_world.aliveCount(), m_scheduler.systemCount(),
                    m_scheduler.stageCount());

        SW_LOG_INFO("Game", "Controls: RMB + mouse = look, WASD = move, Q/E = down/up, "
                            "Shift = boost, wheel = speed, Esc = quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    void StarWorksGame::buildScene()
    {
        // ---- mesh table -------------------------------------------------------
        sw::u32 asteroidMeshId = 0;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(2.0f, 24, 32,
                                                   {0.45f, 0.41f, 0.38f, 1.0f})));
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        const sw::u32 debrisMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(0.35f, {0.55f, 0.50f, 0.45f, 1.0f})));
        const sw::u32 gridMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeGridPlane(60.0f, 48, {0.05f, 0.07f, 0.10f, 1.0f})));

        renderer().setSunDirection({-0.45f, -0.8f, -0.4f});

        // ---- entities -----------------------------------------------------------
        // Reference grid (static).
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {0.0f, -6.0f, 0.0f};
            m_world.addComponent(e, transform);
            m_world.addComponent(e, MeshComponent{gridMeshId});
        }

        // Central asteroid: slow tumble.
        {
            const sw::ecs::Entity e = m_world.createEntity();
            m_world.addComponent(e, TransformComponent{});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.15f});
        }

        // Station modules: orbit ring + self rotation.
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::ecs::Entity e = m_world.createEntity();
            m_world.addComponent(e, TransformComponent{});
            m_world.addComponent(e, MeshComponent{moduleMeshId});

            OrbitComponent orbit{};
            orbit.radius = kStationRingRadius;
            orbit.radiansPerSecond = 0.3f;
            orbit.phase = sw::math::kTwoPi * static_cast<sw::f32>(i) /
                          static_cast<sw::f32>(kStationModuleCount);
            orbit.verticalWobble = 0.6f;
            m_world.addComponent(e, orbit);
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f}, 0.8f});
        }

        // Debris field: deterministic random orbits, varied radii/speeds.
        for (sw::u32 i = 0; i < kDebrisCount; ++i)
        {
            const sw::ecs::Entity e = m_world.createEntity();
            m_world.addComponent(e, TransformComponent{});
            m_world.addComponent(e, MeshComponent{debrisMeshId});

            OrbitComponent orbit{};
            orbit.radius = 9.0f + hash01(i * 3 + 0) * 14.0f;
            orbit.radiansPerSecond = 0.05f + hash01(i * 3 + 1) * 0.25f;
            orbit.phase = hash01(i * 3 + 2) * sw::math::kTwoPi;
            orbit.verticalWobble = -2.5f + hash01(i * 7 + 5) * 5.0f;
            m_world.addComponent(e, orbit);

            const sw::Vec3 axis = glm::normalize(sw::Vec3{hash01(i * 5 + 1) - 0.5f,
                                                          hash01(i * 5 + 2) - 0.5f,
                                                          hash01(i * 5 + 3) - 0.5f});
            m_world.addComponent(e, SpinComponent{axis, 0.5f + hash01(i * 5 + 4) * 2.0f});
        }
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        m_cameraController.update(input(), window(), deltaSeconds);
        m_camera.setAspectRatio(renderer().aspectRatio());

        // All simulation logic now flows through the scheduler.
        m_scheduler.run(m_world, deltaSeconds, &threadPool());
    }

    void StarWorksGame::collectRenderObjects()
    {
        m_renderObjects.clear();
        m_renderObjects.reserve(m_world.aliveCount());
        m_world.forEach<TransformComponent, MeshComponent>(
            [this](sw::ecs::Entity, TransformComponent& transform, MeshComponent& mesh) {
                m_renderObjects.push_back(
                    {&m_meshes[mesh.meshIndex], transform.matrix()});
            });
    }

    void StarWorksGame::onRender()
    {
        collectRenderObjects();
        renderer().renderFrame(m_camera, m_renderObjects);
    }
} // namespace game
