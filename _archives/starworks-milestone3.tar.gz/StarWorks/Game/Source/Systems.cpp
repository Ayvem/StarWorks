#include "Systems.hpp"

#include <cmath>

namespace game
{
    void OrbitSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, OrbitComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           OrbitComponent& orbit) {
                orbit.phase += orbit.radiansPerSecond * deltaSeconds;
                if (orbit.phase > sw::math::kTwoPi)
                {
                    orbit.phase -= sw::math::kTwoPi;
                }

                transform.position =
                    orbit.center + sw::Vec3{orbit.radius * std::cos(orbit.phase),
                                            orbit.verticalWobble * std::sin(orbit.phase * 2.0f),
                                            orbit.radius * std::sin(orbit.phase)};
            });
    }

    void SpinSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, SpinComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           const SpinComponent& spin) {
                const sw::Quat step =
                    glm::angleAxis(spin.radiansPerSecond * deltaSeconds, spin.axis);
                transform.rotation = glm::normalize(step * transform.rotation);
            });
    }
} // namespace game
