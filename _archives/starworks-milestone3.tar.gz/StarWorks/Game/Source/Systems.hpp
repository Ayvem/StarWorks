#pragma once

// ============================================================================
// Systems.hpp — game-side ECS systems.
//
// Access declarations drive the scheduler's staging:
//   OrbitSystem  writes Transform (position), reads Orbit (phase is written
//                too, so Orbit is declared written).
//   SpinSystem   writes Transform (rotation), reads Spin.
// Both write TransformComponent, so they land in consecutive stages and
// never race — verified by the scheduler unit tests.
// ============================================================================

#include "Components.hpp"

namespace game
{
    class OrbitSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "OrbitSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<OrbitComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    class SpinSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "SpinSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .read<SpinComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };
} // namespace game
