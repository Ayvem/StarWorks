#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer, now fully ECS-driven (Milestone 3): every scene object is
// an entity; OrbitSystem/SpinSystem run through the parallel scheduler; the
// render list is collected from a <Transform, Mesh> query each frame.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        void buildScene();
        void collectRenderObjects();

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Mesh table: MeshComponent::meshIndex points in here (asset-ID
        // precursor; becomes the Assets registry in a later milestone).
        std::vector<sw::Mesh> m_meshes;

        sw::ecs::World m_world;
        sw::ecs::SystemScheduler m_scheduler;

        std::vector<sw::RenderObject> m_renderObjects;
    };
} // namespace game
