#include "StarWorksGame.hpp"

namespace game
{
    namespace
    {
        constexpr sw::u32 kStationModuleCount = 8;
        constexpr sw::f32 kStationRingRadius = 6.0f;
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.1f, 10000.0f);
        m_cameraController.setPose({0.0f, 2.5f, 12.0f}, 0.0f, -0.15f);

        buildScene();

        SW_LOG_INFO("Game", "Controls: RMB + mouse = look, WASD = move, Q/E = down/up, "
                            "Shift = boost, wheel = speed, Esc = quit");
    }

    void StarWorksGame::buildScene()
    {
        // ---- asteroid: real glTF asset, procedural sphere as fallback --------
        try
        {
            m_asteroidMesh = renderer().createMesh(
                sw::GltfLoader::loadMesh(sw::FileSystem::resolve("Assets/Models/asteroid.glb")));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            m_asteroidMesh = renderer().createMesh(sw::PrimitiveFactory::makeUvSphere(
                2.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f}));
        }

        // ---- station modules + reference grid ----------------------------------
        m_cubeMesh = renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f}));
        m_gridMesh = renderer().createMesh(
            sw::PrimitiveFactory::makeGridPlane(40.0f, 40, {0.05f, 0.07f, 0.10f, 1.0f}));

        renderer().setSunDirection({-0.45f, -0.8f, -0.4f});

        // Static object list; transforms are refreshed every frame in onUpdate.
        m_renderObjects.resize(2 + kStationModuleCount);
        m_renderObjects[0] = {&m_gridMesh,
                              glm::translate(sw::Mat4{1.0f}, {0.0f, -4.0f, 0.0f})};
        m_renderObjects[1] = {&m_asteroidMesh, sw::Mat4{1.0f}};
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            m_renderObjects[2 + i] = {&m_cubeMesh, sw::Mat4{1.0f}};
        }
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        m_cameraController.update(input(), window(), deltaSeconds);
        m_camera.setAspectRatio(renderer().aspectRatio());

        m_sceneTime += deltaSeconds;

        // Asteroid: slow tumble.
        m_renderObjects[1].transform =
            glm::rotate(sw::Mat4{1.0f}, m_sceneTime * 0.15f, {0.0f, 1.0f, 0.0f}) *
            glm::rotate(sw::Mat4{1.0f}, m_sceneTime * 0.07f, {1.0f, 0.0f, 0.3f});

        // Station modules: ring orbit around the asteroid, each self-rotating.
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f32 angle = m_sceneTime * 0.3f +
                                  sw::math::kTwoPi * static_cast<sw::f32>(i) /
                                      static_cast<sw::f32>(kStationModuleCount);
            const sw::Vec3 position{kStationRingRadius * std::cos(angle),
                                    0.6f * std::sin(angle * 2.0f),
                                    kStationRingRadius * std::sin(angle)};
            m_renderObjects[2 + i].transform =
                glm::translate(sw::Mat4{1.0f}, position) *
                glm::rotate(sw::Mat4{1.0f}, m_sceneTime * 0.8f + angle, {0.3f, 1.0f, 0.2f});
        }
    }

    void StarWorksGame::onRender()
    {
        renderer().renderFrame(m_camera, m_renderObjects);
    }
} // namespace game
