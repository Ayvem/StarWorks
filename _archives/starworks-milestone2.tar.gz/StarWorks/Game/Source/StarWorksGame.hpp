#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 2 scene: an asteroid (glTF asset), a ring of
// station modules (cubes) orbiting it, and a reference grid — everything lit
// by a single directional sun and explored with the free camera.
// ============================================================================

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        void buildScene();

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // GPU meshes (owned here; the renderer only references them).
        sw::Mesh m_asteroidMesh;
        sw::Mesh m_cubeMesh;
        sw::Mesh m_gridMesh;

        std::vector<sw::RenderObject> m_renderObjects;
        sw::f32 m_sceneTime = 0.0f;
    };
} // namespace game
