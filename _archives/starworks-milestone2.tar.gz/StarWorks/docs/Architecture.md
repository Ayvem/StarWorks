# StarWorks — Engine Architecture

This document is the living reference for the engine's structure and the reasoning behind it. It is updated at every milestone.

## Vision

A single-purpose engine for an industrial space simulation: hundreds of thousands of rendered objects, a multi-rate simulation that never depends on rendering, seamless space-to-planet transitions, and save files with no memory-pointer dependencies. The engine is not a general-purpose product; every design decision is allowed to exploit that.

## Ground rules

Modularity with minimal dependencies; no God objects; strong cohesion inside a module, weak coupling between modules. Game code talks to the engine only through `Engine.hpp` and the `Application` hooks — never to GLFW or Vulkan directly. GLM is quarantined behind `Math/Math.hpp` so a future in-house math library (notably f64 large-world coordinates) is a one-module change.

## Module map

| Module | State | Responsibility |
|---|---|---|
| `Core` | active | types, log, assert, errors, clock, filesystem, Application/main loop |
| `Platform` | active | GLFW window, surface creation, raw event callbacks |
| `Input` | active | keyboard/mouse snapshots (down / just-pressed / just-released) |
| `Math` | active | math façade over GLM; engine-wide conventions |
| `Scene` | active | camera, free camera controller (scene graph later) |
| `Renderer` | active | Vulkan 1.3 front-end: instance, device, swapchain, pipelines, frame loop |
| `RenderGraph` | planned | pass scheduling, automatic barriers, transient resources |
| `Assets` | active | MeshData/Vertex, procedural primitives, glTF import (cgltf); streaming later |
| `ECS` | planned | archetype ECS, contiguous storage, parallel systems |
| `Physics` | planned | gravitation, rigid bodies, orbits, docking, modular assembly |
| `Simulation` | planned | fixed-rate lanes: Physics 50 Hz, Logistics 10, Automation 5, Economy 2, World 1 |
| `Factory` / `Resources` / `Space` / `Planet` | planned | industry, resource types, star system model, procedural planets |
| `Gameplay` / `UI` / `Audio` / `Network` | planned | game rules, HUD, sound, (much) later multiplayer |
| `Serialization` / `Save` | planned | versioned, handle-based (pointer-free) persistence |
| `Tools` / `Editor` | planned | offline cookers, in-engine inspection |

Dependency direction (only downward):
`Game → {Scene, Renderer, Input, Core} → {Platform, Math, Core}`. `Platform` knows nothing about `Renderer`; `Input` knows nothing about GLFW; `Scene` knows nothing about Vulkan.

## Key decisions & rationale

**Vulkan 1.3 + dynamic rendering + synchronization2, no legacy render passes.** The future RenderGraph will compute image layouts and barriers itself; VkRenderPass objects would fight it. Dynamic rendering removes framebuffer/renderpass lifetime management entirely. Minimum driver requirement is explicit and enforced at device selection.

**Frame model.** 2 frames in flight; per-frame transient command pool (whole-pool reset each frame — cheapest reuse pattern); image-available semaphore + in-flight fence per frame; render-finished semaphores indexed *per swapchain image* (required for correct present semantics when image count > frames in flight).

**Error policy.** Initialization and asset failures throw `sw::Exception` (caught once in `main`). Per-frame code never throws for recoverable states — `VK_ERROR_OUT_OF_DATE_KHR`/`VK_SUBOPTIMAL_KHR` are handled as values. Programmer errors use `SW_ASSERT`.

**Logging.** Static facility with level check before message formatting, category tags, ANSI colors (enabled on Windows via VT processing), optional file sink. Validation-layer output is routed through the same log.

**Coordinates & conventions.** Right-handed, +Y up, -Z forward; radians everywhere; depth [0,1] (`GLM_FORCE_DEPTH_ZERO_TO_ONE`); projection Y-flip done once in `Camera`; geometry authored CCW with `VK_FRONT_FACE_COUNTER_CLOCKWISE` and back-face culling (verified by rendering test). sRGB swapchain: shaders write linear color.

**GPU memory via VMA behind an engine-owned façade.** `VulkanMemory` is the single entry point (device buffers, host-visible mapped buffers, attachment images, staging uploads); RAII wrappers (`VulkanBuffer`/`VulkanImage`) make leaks structurally impossible. VMA/cgltf implementations live in dedicated warning-silenced TUs; engine code keeps the full warning set.

**Reverse-Z depth.** Projection maps near→1, far→0 (`glm::perspective` with swapped planes), depth clear is 0.0, comparisons are `GREATER_OR_EQUAL`. This is the only depth scheme that keeps f32 precision at planetary/orbital distances; adopted before any content existed so nothing ever depends on standard-Z.

**CPU/GPU device choice is a config bit, not an architecture.** `--cpu` (RendererConfig::preferCpuDevice) inverts the device-type scoring so a software implementation (llvmpipe/SwiftShader) wins; every rendering feature runs identically on both. CI runs the engine on CPU; players run the same binary on hardware.

**Explicit source lists in CMake** (no GLOB): adding a file is a deliberate, reviewable act.

**`--frames N` headless soak mode** from day one, so every milestone can be smoke-tested in CI without a human.

## Development log

### Milestone 1 — Bootstrap (done)
Window + main loop + logging + error handling + clock + input + free camera + Vulkan 1.3 init (instance/validation, device selection & scoring, swapchain + live resize/minimize handling, graphics pipeline with push constants) + first triangle via build-time-compiled GLSL.

### Milestone 2 — GPU memory & geometry (done)
VMA-backed memory layer (`VulkanMemory` + RAII buffer/image wrappers, staging uploads), depth buffer with reverse-Z, vertex input pipeline (position/normal/color/uv), per-frame camera UBO through descriptor sets, model matrix via push constants, Lambert+ambient shading, procedural primitives (cube, UV sphere, grid), glTF import via cgltf (node transforms applied), `Tools/generate_asteroid.py` producing the deterministic test asset, `--cpu` device preference. Verified: 240-frame soak on llvmpipe, screenshot-checked scene (occlusion, lighting, glTF geometry).

### Milestone 3 — ECS core (next)
Archetype-based storage with contiguous component arrays, entity handles (generation-checked indices — save-friendly, no pointers), queries, system scheduler ready for parallel execution. Then Milestone 4: fixed-rate Simulation lanes on top of it.
