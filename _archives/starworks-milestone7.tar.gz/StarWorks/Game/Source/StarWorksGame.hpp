#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 7: pilotable ship + star map.
//
//  - Tab switches between free camera and SHIP CONTROL: W/S main engine,
//    A/D yaw, arrows pitch, Q/E roll, X kills rotation. Thrust is F = ma
//    on the ship's dynamic body, applied in the Physics lane on top of
//    gravity — orbits react exactly as Newton says they should.
//  - M opens the STAR MAP: a top-down system view at REAL scale (Terra,
//    Luna at 384,400 km, the station cluster). Since real-scale objects
//    are sub-pixel from that far, marked entities get octahedron beacons
//    whose scale grows with distance so their on-screen size is constant.
//    Mouse wheel zooms the map.
//  - Physics architecture unchanged from M6: on-rails Kepler orbits for
//    everything distant, true f64 Newtonian integration inside the bubble.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        [[nodiscard]] CelestialLodComponent makeSphereLodSet(const sw::Vec4& color);
        void buildScene();
        void updateShipControls();
        void updateChaseCamera();
        void collectDrawItems(const sw::Camera& activeCamera, bool mapView);
        [[nodiscard]] sw::u32 selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const;

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Star map view (M): top-down system camera + zoom height.
        sw::Camera m_mapCamera;
        sw::f64 m_mapHeightMeters = 5.5e8;
        bool m_mapView = false;

        // Ship piloting (Tab). Starts in the pilot seat: the chase camera
        // co-moves with the orbiting scene (a static camera would watch
        // everything recede at 7.7 km/s of orbital velocity).
        sw::ecs::Entity m_shipEntity{};
        bool m_shipMode = true;
        sw::u32 m_markerMeshIndex = 0;

        // Mesh table: components reference meshes by index (asset-ID
        // precursor; becomes the Assets registry in a later milestone).
        std::vector<sw::Mesh> m_meshes;

        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation
        sw::ecs::EntityCommandBuffer m_commands;
        /// Owned by the Logistics lane scheduler; kept to update the focus.
        sw::phys::SimulationBubbleSystem* m_bubbleSystem = nullptr;

        std::vector<sw::DrawItem> m_drawItems;
        sw::f64 m_lastStatsLogSeconds = 0.0;
    };
} // namespace game
