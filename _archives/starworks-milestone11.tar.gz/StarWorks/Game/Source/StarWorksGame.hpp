#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 10: the hierarchical star system.
//
//  - Sol -> Terra (-> Luna) / Mars, every orbit real-scale and analytic.
//    Celestials move on parent-relative Kepler rails (CelestialMotionSystem);
//    the station, ship and asteroid live in Terra's SOI and follow it
//    around the Sun.
//  - KSP-style PATCHED-CONICS flight plan: the map draws the controlled
//    craft's trajectory as colored patches around each successive primary,
//    with encounter / SOI-exit / impact markers, and the HUD calls out the
//    next event ("ENC LUNA T-…"). Powered by space::predictTrajectory.
//  - The map (M) recenters on the current SOI primary and zooms from LEO
//    out to the whole Sol system.
//  - HUD speed/altitude are measured relative to the current SOI primary.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <array>
#include <string_view>
#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        [[nodiscard]] CelestialLodComponent makeSphereLodSet(const sw::Vec4& color);
        void buildScene();
        void buildGlyphMeshes();
        void updateWarp();
        void updateShipControls();
        void toggleEva();
        void updateChaseCamera(sw::f32 deltaSeconds);
        void collectDrawItems(const sw::Camera& activeCamera, bool mapView);
        void collectMapTrajectories(const sw::Camera& activeCamera);
        void collectHud();
        void collectNavball();
        void collectParticles(const sw::Camera& activeCamera);
        void refreshPrediction();
        /// Atmospheric heating 0..1 for a dynamic craft (0 in vacuum).
        [[nodiscard]] sw::f32 heatingFactorFor(sw::ecs::Entity entity) const;
        /// Reentry glow tint + plasma particle spawning/aging (visual only,
        /// render-frame rate).
        void updateReentryEffects(sw::f32 deltaSeconds);
        void buildNavballMeshes();
        /// World position of the controlled craft's SOI primary (index into
        /// m_celestialIndex; -1 when the index is empty).
        [[nodiscard]] sw::i32 controlledPrimaryIndex() const;
        void hudText(std::string_view text, sw::f32 x, sw::f32 y, sw::f32 heightNdc,
                     const sw::Vec4& color);
        [[nodiscard]] sw::u32 selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const;
        [[nodiscard]] sw::ecs::Entity controlledEntity() const;
        [[nodiscard]] sw::WorldVec3 controlledVelocity() const;

        void buildSaveSchema();
        void saveGame();
        void loadGame();

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Star map view (M): top-down system camera + zoom height.
        sw::Camera m_mapCamera;
        /// Default zoom frames the LEO traffic; wheel out to see Luna.
        sw::f64 m_mapHeightMeters = 6.0e7;
        bool m_mapView = false;

        // Control target: ship, or EVA capsule (G). Tab = pilot/free camera.
        sw::ecs::Entity m_shipEntity{};
        sw::ecs::Entity m_capsuleEntity{}; // null until first EVA
        bool m_shipMode = true;
        bool m_evaMode = false;

        // HUD state.
        bool m_speedSurfaceRelative = false; // V toggles ORB / SRF
        std::array<sw::u32, 128> m_glyphMeshIndex{};
        sw::u32 m_capsuleMeshIndex = 0;
        sw::u32 m_markerMeshIndex = 0;

        // Artificial horizon (bottom-center instrument).
        sw::u32 m_navRingMeshIndex = 0;
        sw::u32 m_navLineMeshIndex = 0;
        sw::u32 m_navDiamondMeshIndex = 0;

        // Reentry heating: glow factor per craft + plasma trail particles.
        struct ReentryParticle
        {
            sw::WorldVec3 position{0.0};
            sw::WorldVec3 velocity{0.0};
            sw::f32 life = 0.0f;    // seconds remaining
            sw::f32 maxLife = 1.0f;
            sw::f32 size = 1.0f;    // meters
        };
        std::vector<ReentryParticle> m_particles;
        sw::f32 m_shipHeat = 0.0f;
        sw::f32 m_capsuleHeat = 0.0f;
        sw::f32 m_particleSpawnDebt = 0.0f;
        sw::u32 m_particleSeed = 0x9E3779B9u;

        // Chase camera: 0 = locked to the craft, 1 = locked to the ground
        // (blended when low + suborbital, KSP "surface mode" style).
        sw::f32 m_groundCamBlend = 0.0f;

        // Time warp (','/'.').
        sw::u32 m_warpIndex = 0;

        // Celestial hierarchy snapshot + patched-conics flight plan.
        sw::space::CelestialIndex m_celestialIndex;
        std::vector<sw::space::TrajectorySegment> m_prediction;
        sw::f64 m_lastPredictionSeconds = -1.0e9;
        sw::ecs::Entity m_solEntity{};
        sw::ecs::Entity m_terraEntity{};

        std::vector<sw::Mesh> m_meshes;
        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation
        sw::ecs::EntityCommandBuffer m_commands;
        sw::phys::SimulationBubbleSystem* m_bubbleSystem = nullptr;

        std::vector<sw::DrawItem> m_drawItems;
        sw::f64 m_lastStatsLogSeconds = 0.0;

        // Save/load (F5/F9): component schema with stable names.
        sw::save::Schema m_saveSchema;
    };
} // namespace game
