# StarWorks

An industrial space simulation game — mine, automate, build ships and stations, and grow a civilization that spans a star system. Powered by a bespoke C++20 / Vulkan engine written exclusively for this game.

## Current state — Milestone 18: The hangar

Press `B` and you leave the world entirely: the HANGAR is its own view — a quiet floor grid, your rocket standing nose-up in front of you, right-drag to walk around it, wheel to zoom. The design you edit there is a BLUEPRINT (plain data, not the live ship): click parts in the palette, watch the green/red ghost, PLACE or UNDO freely. NEW starts a fresh design from a command core; BUILD stands it on Terra's launch pad, co-rotating with the planet, ready to fly. LOAD cycles through every part-built vessel in the world and pulls it into the editor — modify your orbiter's design and BUILD rewrites it in place, same orbit, same identity. And since there can now be several ships, `P` in flight switches which one you're piloting.

## Previously — Milestone 17: Build it, stage it, dock it

Every connection is a real JOINT ENTITY with its own strength and break force — the structural skeleton future crashes will tear along. Press `Z` in flight and the decoupler fires: the lower stage drifts away as its own vessel and your fuel gauge drops to what's actually still bolted to you. Bring two docking ports of different vessels within a few meters and they merge into one.

## Previously — Milestone 16: Everything is made of parts now

The part system has landed — the foundation the rest of the game will be built on. Nine part types (fuel tank, engine, wing, battery, solar panel, docking port, decoupler, cargo bay, structural) live in a catalog where every part exposes its mass, cost, volume, resource capacities, connexions/attach points, strength and aerodynamics. Every part instance is its own entity attached to a vessel — which is what will make staging, docking and damage natural later. Your ship IS one now: an 11-part rocket (37.8 t wet) whose mass, thrust, drag and cost are aggregated from its parts every tick. The engine burns real fuel out of the real tanks — watch FUEL fall on the HUD and the rocket get lighter (the rocket equation isn't coded anywhere: it emerges) — and the solar wing recharges the battery.

## Previously — Milestone 15: Real ground under your landing gear

Planets have TERRAIN now: an analytic procedural heightfield (mountains to 9 km on Terra, 16 km on Mars) that physics and rendering sample from the same function — so where you see a mountain, you can land on it, walk on it, and build on it, at its real elevation, even after the planet has rotated it around. Near the ground a detail patch renders the landscape with true slope lighting, its extent scaling with your altitude (the LOD). One mouse CLICK on the new [SAS] [PGD] [RTG] buttons points your ship prograde or retrograde and holds it there — the first pieces of clickable UI. The map view rotates with right-drag. And two old annoyances are dead: particles no longer float beside the ship (they were anchored to the wrong time frame), and the polar "double cap" glitch is gone.

## Previously — Milestone 13: Plan your burns

The map now plans like KSP: press `N` for a **maneuver node**, dial in prograde/normal/radial dv (`I`/`K`, `U`/`O`, `Y`/`H`) and slide its time (`J`/`L`) — the post-burn trajectory draws in white-violet through every SOI it crosses, a violet marker sits on the navball where the burn vector points, and the HUD counts the remaining dv down while you burn. **Physics warp**: up to ×5, everything stays truly simulated — engines fire, drag brakes, reentries happen five times faster. The HUD gained real orbit data (apoapsis, periapsis, period, time to each). The chase camera is yours now: right-drag orbits the craft, wheel zooms, `C` snaps back. Engines shoot a blue-white exhaust jet, reentry plasma became proper streaks stretched along the airflow, and the Sun finally looks like one — a blinding core wrapped in a warm halo, properly eclipsed by planets.

## Previously — Milestone 12: A universe you can SEE

The sky is full of stars — 1700 of them, procedurally placed once and forever fixed, parallax-free: they are your compass. Terra is no longer a blue ball: procedural continents with lowlands, highlands and snow-capped ranges rise out of deep and coastal oceans, polar ice caps the poles, and two translucent shells wrap it all — a blue atmospheric veil and a layer of blobby white clouds that drifts slowly over the ground (a new blended render pass handles translucency, visible from orbit AND from underneath: the sky is blue down there). Luna got basalt maria, Mars got rust and CO2 caps. And the reentry plasma now streams exactly opposite your motion through the air, not your motion through the solar system.

## Previously — Milestone 11: Reentry fire, walkable worlds & the navball

Light now behaves: every fragment is lit from Sol's true position and planets cast real shadows — fly behind Terra and the station goes dark. Dive into an atmosphere too fast and your ship glows red, then turns into a fireball shedding a wake of plasma particles (the whole descent was flight-tested: deorbit burn, warp descent with automatic downshift, reentry fireball, crash at 91 m/s… and the wreck sits perfectly still afterward, co-rotating with the planet at exactly ω×r). Every body's surface is solid and WALKABLE: ground friction and EVA movement work in each planet's rotating frame, on Terra, Luna or Mars. When your trajectory stops being an orbit and you get low (relative to the body's size), the chase camera levels itself on the horizon — KSP surface mode. And a proper **artificial horizon** sits bottom-center: roll/pitch horizon line, prograde and retrograde markers projected on the ball. Under the hood, this milestone also fixed a deep simulation bug: analytic celestial positions were evaluated up to one physics step ahead of integrated bodies (600 m at Terra's orbital speed) — everything now shares the lane's per-tick "present".

## Previously — Milestone 10: The star system & the KSP-style flight plan

The universe is now a real hierarchy: **Sol → Terra (→ Luna) / Mars**, every orbit at true scale (Terra rides 1 AU from the Sun at 30 km/s — and the station, the ship, the asteroid and the ground outpost all ride with it, because rails, anchors, atmosphere and ground friction are measured in their planet's moving frame). Each body's sphere of influence decides what you orbit: near Luna you orbit Luna, not the heavier Sun.

And the map earned its KSP stripes: a **patched-conics flight plan** predicts your trajectory across spheres of influence — elliptic AND hyperbolic arcs, up to 5 patches, each drawn in its own color around its primary with markers where things happen. Burn toward the Moon and the plan shows the Luna encounter before you commit; aim too low and the HUD warns **`IMPACT TERRA T-403 S`** while the map plants a red marker on your crash site. Events (encounter / SOI exit / impact) are found by scanning the conic and refined by bisection to the millisecond. The sun now actually shines from Sol: Terra shows a live day/night terminator.

## Previously — Milestone 9: Save/Load & surface anchoring

`F5` saves, `F9` loads — the whole universe: every entity and component (columns are memcpy'd thanks to the trivially-copyable rule), simulation clocks (on-rails orbits resume to the exact position), factory state mid-production (bitwise deterministic afterwards, unit-tested), warp, camera and EVA state. Saves identify components by stable names with strict version/size checks. And the first SURFACE BASE exists: a mining outpost anchored to Terra's equator in the planet's rotating frame — it rides the rotation and reloads exactly where it was built, the model every future planet/asteroid factory will follow.

## Previously — Milestone 8.5: Flight information & accessibility

A flight HUD (procedural bitmap font, no assets) shows your control mode, speed — `V` toggles orbital vs surface-relative — altitude, throttle and warp factor. The star map now draws every tracked orbit as a dotted Kepler ellipse at real scale. Terra gained an exponential atmosphere (real drag) and a solid surface with friction: descend gently and you land, arrive hard and it's logged as the crash it is. `G` steps out into an EVA capsule that walks on the ground and falls ballistically off it. `Shift`/`Ctrl` ramp the main-engine throttle limiter.

## Previously — Milestone 8: Factory foundations & time warp

The industrial loop is alive: a drill on the asteroid mines iron ore, a station refinery converts it to iron at 90% yield, a depot stores the output — all volume-bounded with real material densities, matter-conserving, running in the Automation/Logistics simulation lanes. Time warp (`,` slower / `.` faster) climbs ×1, ×2, ×5, ×10, ×50, ×100, ×1000, ×10⁴, ×10⁵: during warp everything rides analytic Kepler rails (no integration, exact at any speed), factories keep producing at exactly warped rates thanks to bulk catch-up ticks, and the warp factor is capped by your altitude above the nearest body (auto-downshift included).

## Previously — Milestone 7: Pilotable ship & star map

You now fly. The game boots in the pilot seat of a 50-ton vessel in 400 km orbit: `W/S` main engine (400 kN, F=ma on the dynamic body, on top of real gravity), `A/D` yaw, arrows pitch, `Q/E` roll, `X` kills rotation, chase camera follows the interpolated ship pose; `Tab` switches to the free camera. `M` opens the star map: a top-down system view at REAL scale — Luna sits at its true 384,400 km — with color-coded beacons of constant on-screen size marking Terra, Luna, the station, the asteroid and your ship (mouse wheel zooms from 20,000 km to 1.6M km). The debris belt is gone (it was pure load); the instanced mass-rendering path remains for real content.

Milestone 6 foundations: two-regime physics — distant objects on analytic Kepler rails (never integrated), objects near the player truly simulated under f64 Newtonian gravity at 50 Hz, continuous conversions at the bubble boundary, real GM values.

Milestone 5 foundations: real astronomical scale (f64 world positions, f32 camera-relative rendering), angular-size LOD for celestial bodies, CPU frustum culling + one instanced draw per mesh, RenderStats with CPU timings.

Milestone 3–4 foundations: archetype ECS (SoA storage, generation-checked handles, parallel stage scheduler), multi-rate fixed-step simulation lanes (Physics 50 Hz … World 1 Hz) with pause/time-scale and render interpolation, deferred structural command buffer, CTest suite (20 tests).

Milestone 2 foundations: VMA-backed GPU memory with RAII wrappers and staging uploads, reverse-Z depth buffer, per-frame camera UBO via descriptor sets, procedural primitives (cube/sphere/grid), cgltf-based glTF importer. `--cpu` selects a software Vulkan device (llvmpipe) with zero code differences — the whole engine runs CPU-only today and will use the GPU the moment one is preferred.

Milestone 1 foundations: logging, assertions/error handling, frame clock, GLFW window layer, input snapshots, camera + controller, Vulkan 1.3 (dynamic rendering, synchronization2), swapchain with live resize, build-time GLSL → SPIR-V compilation.

## Requirements

- CMake ≥ 3.24
- A C++20 compiler (Visual Studio 2022 on Windows, GCC 13+/Clang 16+ on Linux)
- The [Vulkan SDK](https://vulkan.lunarg.com/) (headers, loader, glslangValidator, validation layers)
- A GPU + driver supporting Vulkan 1.3

GLFW 3.4 and GLM 1.0.1 are fetched and built automatically by CMake.

## Building (Windows / Visual Studio 2022)

```powershell
cmake --preset windows-msvc
cmake --build --preset windows-debug
build\windows\bin\Debug\StarWorks.exe
```

Or open `build/windows/StarWorks.sln` in Visual Studio and run the `StarWorks` startup project (F5).

## Building (Linux)

```bash
cmake --preset linux-debug
cmake --build --preset linux-debug -j
./build/linux-debug/bin/StarWorks
```

## Running the tests

```powershell
ctest --test-dir build/windows -C Debug --output-on-failure   # Windows
ctest --test-dir build/linux-debug --output-on-failure        # Linux
```

## Controls

**Ship (default mode):** `W`/`S` main engine forward/retro, `A`/`D` yaw, `↑`/`↓` pitch, `Q`/`E` roll, `X` kill rotation, `Shift`/`Ctrl` throttle up/down. `Tab` switches between pilot and free camera. `G` goes EVA (capsule: `W`/`S` walk, `A`/`D` turn — grounded walking on any body, ballistic otherwise). `V` toggles the HUD speed between orbital and surface-relative. The artificial horizon (bottom center) shows attitude vs the local horizon plus prograde/retrograde markers; the chase camera auto-levels on the horizon when you are low and suborbital.

**Free camera:** hold the right mouse button to look around, `WASD` to move, `Q`/`E` down/up, `Shift` to boost, mouse wheel to change speed.

**Star map:** `M` toggles the system view (real scale, beacon markers, patched-conics flight plan with encounter/impact/SOI-exit markers); mouse wheel zooms from LEO out to the whole Sol system. The map centers on your current SOI primary.

**Maneuver nodes (in map view):** `N` create/delete, `J`/`L` node time −/+, `I`/`K` prograde +/−, `U`/`O` normal −/+, `Y`/`H` radial +/− (`Shift` ×10, `Ctrl` ×0.1). Fly the burn by pointing at the violet navball marker and burning until DV reaches zero.

**Chase camera:** hold the right mouse button to orbit around the craft, mouse wheel to zoom, `C` to reset behind it.

**Hangar:** `B` opens/closes (sim paused; separate view). Right-drag orbits the camera, wheel zooms. Click a part in the palette, arrows cycle attach node / part type, `Enter` or PLACE places, UNDO removes the last part. NEW starts a fresh design (built on the launch pad), LOAD cycles the world's vessels into the editor for modification, BUILD makes it real. `P` in flight switches the piloted vessel. `Z` fires the decoupler (staging).

**Time warp:** ×2 and ×5 are PHYSICS warp — everything stays simulated and the engines still work. Above ×5 the world rides analytic rails and engines cut out.

**Time warp:** `.` faster / `,` slower (×1 → ×100,000, altitude-limited; engines only work at ×1). `Space` pauses. `F5` saves, `F9` loads. `Esc` quits.

## Useful flags

`--frames N` exits after N frames (soak testing); `--log-file path.log` mirrors the log to a file; `--cpu` prefers a software (CPU) Vulkan device over hardware GPUs.

## Repository layout

See `docs/Architecture.md` for the module map, engineering conventions, and the development log.
