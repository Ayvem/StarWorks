#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <format>

namespace game
{
    namespace
    {
        // ---- real-world dimensions and gravity (meters, m^3/s^2) --------------
        // The hierarchy: Sol -> Terra (-> Luna) / Mars. All values real.
        constexpr sw::f64 kMuSol = 1.32712440018e20;
        constexpr sw::f64 kSolRadius = 6.9634e8;
        constexpr sw::f64 kTerraRadius = 6.371e6;    // Earth
        constexpr sw::f64 kMuTerra = 3.986004418e14; // Earth GM
        constexpr sw::f64 kTerraSma = 1.496e11;      // 1 AU
        constexpr sw::f64 kLunaRadius = 1.7374e6;    // Moon
        constexpr sw::f64 kMuLuna = 4.9048695e12;    // Moon GM
        constexpr sw::f64 kLunaSma = 3.844e8;        // Earth-Moon distance
        constexpr sw::f64 kMarsRadius = 3.3895e6;
        constexpr sw::f64 kMuMars = 4.2828e13;
        constexpr sw::f64 kMarsSma = 2.2794e11;
        // Sphere-of-influence radii: r = a * (mu / mu_parent)^(2/5).
        constexpr sw::f64 kTerraSoi = 9.24e8;
        constexpr sw::f64 kLunaSoi = 6.61e7;
        constexpr sw::f64 kMarsSoi = 5.77e8;

        constexpr sw::f64 kStationAltitude = 4.0e5; // 400 km (LEO)
        constexpr sw::f64 kStationOrbitRadius = kTerraRadius + kStationAltitude;
        constexpr sw::f64 kStationPhase = 4.71238898038468986; // 3*pi/2
        /// Terra sidereal angular velocity (rad/s) around +Y — used for the
        /// SuRFace-relative speed readout.
        constexpr sw::WorldVec3 kTerraAngularVelocity{0.0, 7.2921e-5, 0.0};

        constexpr sw::u32 kStationModuleCount = 8;

        constexpr sw::f64 kBubbleEnterRadius = 1.0e4; // 10 km
        constexpr sw::f64 kBubbleExitRadius = 1.5e4;  // 15 km (hysteresis)

        // Star map: constant on-screen marker size and zoom limits (up to
        // the full Sol system — Mars orbit is 2.28e11 m).
        constexpr sw::f32 kMarkerScreenFraction = 0.016f;
        constexpr sw::f64 kMapMinHeight = 2.0e7;
        constexpr sw::f64 kMapMaxHeight = 8.0e11;
        constexpr sw::u32 kTrajectorySamples = 72;
        constexpr sw::u32 kPredictionDisplaySamples = 160; // dots per patch
        /// Patch colors: current conic, then each successive patch (KSP
        /// style — the eye follows the hand-offs by color).
        constexpr sw::Vec4 kPatchColors[] = {
            {0.35f, 1.0f, 0.55f, 2.0f},  // green: current orbit
            {1.0f, 0.85f, 0.25f, 2.0f},  // yellow: next patch
            {0.95f, 0.45f, 1.0f, 2.0f},  // magenta
            {0.35f, 0.8f, 1.0f, 2.0f},   // cyan
            {1.0f, 0.55f, 0.25f, 2.0f},  // orange
        };
        /// How often the flight plan is recomputed (wall seconds).
        constexpr sw::f64 kPredictionRefreshSeconds = 0.25;

        // ---- artificial horizon (navball) ------------------------------------
        constexpr sw::f32 kNavballCenterY = 0.62f; // NDC, y grows downward
        constexpr sw::f32 kNavballRadius = 0.26f;  // NDC (vertical)
        constexpr sw::f32 kHalfPi = 1.5707963267948966f;

        // ---- reentry heating ---------------------------------------------------
        /// Heating proxy q = rho * v_rel^3 (W/m^2-ish). Glow ramps over
        /// [1e7, 1e9] on a log scale: faint at ~100 km on a LEO reentry,
        /// blinding below ~55 km.
        constexpr sw::f64 kHeatGlowStart = 1.0e7;
        constexpr sw::f32 kHeatLogRange = 2.0f;
        constexpr sw::usize kMaxParticles = 320;

        [[nodiscard]] sw::MeshData buildNavRingMesh(sw::u32 segments, sw::f32 thickness)
        {
            // Unit-radius ring in the XY plane (z = 0), for the HUD pass.
            sw::MeshData mesh;
            const sw::f32 inner = 1.0f - thickness;
            for (sw::u32 i = 0; i < segments; ++i)
            {
                const sw::f32 a0 =
                    2.0f * 3.14159265f * static_cast<sw::f32>(i) / segments;
                const sw::f32 a1 =
                    2.0f * 3.14159265f * static_cast<sw::f32>(i + 1) / segments;
                const sw::Vec2 d0{std::cos(a0), std::sin(a0)};
                const sw::Vec2 d1{std::cos(a1), std::sin(a1)};

                const sw::u32 base = static_cast<sw::u32>(mesh.vertices.size());
                const sw::Vec4 white{1.0f, 1.0f, 1.0f, 1.0f};
                const sw::Vec3 normal{0.0f, 0.0f, 1.0f};
                mesh.vertices.push_back({{d0.x * inner, d0.y * inner, 0.0f}, normal, white, {}});
                mesh.vertices.push_back({{d0.x, d0.y, 0.0f}, normal, white, {}});
                mesh.vertices.push_back({{d1.x, d1.y, 0.0f}, normal, white, {}});
                mesh.vertices.push_back({{d1.x * inner, d1.y * inner, 0.0f}, normal, white, {}});
                mesh.indices.insert(mesh.indices.end(),
                                    {base, base + 1, base + 2, base, base + 2, base + 3});
            }
            return mesh;
        }

        [[nodiscard]] sw::MeshData buildNavBarMesh()
        {
            // Unit bar: x in [-1,1], y in [-1,1] — sized entirely by the
            // instance transform.
            sw::MeshData mesh;
            const sw::Vec4 white{1.0f, 1.0f, 1.0f, 1.0f};
            const sw::Vec3 normal{0.0f, 0.0f, 1.0f};
            mesh.vertices.push_back({{-1.0f, -1.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{1.0f, -1.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{1.0f, 1.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{-1.0f, 1.0f, 0.0f}, normal, white, {}});
            mesh.indices = {0, 1, 2, 0, 2, 3};
            return mesh;
        }

        [[nodiscard]] sw::MeshData buildNavDiamondMesh()
        {
            sw::MeshData mesh;
            const sw::Vec4 white{1.0f, 1.0f, 1.0f, 1.0f};
            const sw::Vec3 normal{0.0f, 0.0f, 1.0f};
            mesh.vertices.push_back({{0.0f, -1.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{1.0f, 0.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{0.0f, 1.0f, 0.0f}, normal, white, {}});
            mesh.vertices.push_back({{-1.0f, 0.0f, 0.0f}, normal, white, {}});
            mesh.indices = {0, 1, 2, 0, 2, 3};
            return mesh;
        }

        // ---- time warp -----------------------------------------------------------
        constexpr sw::f32 kWarpLadder[] = {1.0f,    2.0f,     5.0f,     10.0f,   50.0f,
                                           100.0f, 1000.0f, 10000.0f, 100000.0f};
        constexpr sw::u32 kWarpSteps = static_cast<sw::u32>(std::size(kWarpLadder));

        /// PHYSICS WARP: the world stays fully simulated (drag, thrust,
        /// collisions) up to this time scale; beyond it everything rides
        /// analytic rails. Integration at 50 Hz stays stable to x5.
        constexpr sw::f32 kMaxPhysicsWarp = 5.0f;

        [[nodiscard]] sw::f32 maxWarpForAltitude(sw::f64 altitudeMeters)
        {
            // Inside the atmosphere, PHYSICS warp is allowed (that is the
            // whole point: reentries at x5 with live drag); rails warp is not.
            if (altitudeMeters < 1.2e5) { return kMaxPhysicsWarp; }
            if (altitudeMeters < 3.0e5) { return 10.0f; }
            if (altitudeMeters < 1.0e6) { return 100.0f; }
            if (altitudeMeters < 5.0e6) { return 1000.0f; }
            if (altitudeMeters < 2.0e7) { return 10000.0f; }
            return 100000.0f;
        }

        /// Sphere LOD resolutions, most to least detailed (rings, segments).
        /// LOD0 is dense enough for readable per-vertex continents.
        constexpr sw::u32 kLodRings[CelestialLodComponent::kLodLevels] = {96, 48, 20, 10, 6};
        constexpr sw::u32 kLodSegments[CelestialLodComponent::kLodLevels] = {144, 72, 30, 15, 9};
        constexpr sw::f32 kLodScreenFractions[CelestialLodComponent::kLodLevels - 1] = {
            0.5f, 0.15f, 0.04f, 0.008f};

        constexpr sw::f32 kCubeBoundsRadius = 0.8660254f;
        constexpr const char* kGlyphCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,-+/%:";

        /// Procedural look of each part type (boxy, color-coded — replaced
        /// by real assets later; the catalog is what matters).
        [[nodiscard]] sw::MeshData buildPartMesh(sw::u32 definitionId)
        {
            using PF = sw::PrimitiveFactory;
            switch (definitionId)
            {
            case sw::parts::kPartFuelTankMedium:
                return PF::makeBox({2.4f, 2.4f, 4.2f}, {0.82f, 0.83f, 0.86f, 1.0f});
            case sw::parts::kPartEngineVector:
            {
                sw::MeshData engine =
                    PF::makeBox({1.7f, 1.7f, 1.5f}, {0.28f, 0.28f, 0.32f, 1.0f});
                PF::append(engine,
                           PF::makeBox({1.1f, 1.1f, 0.9f}, {0.16f, 0.16f, 0.18f, 1.0f}),
                           {0.0f, 0.0f, 1.1f});
                return engine;
            }
            case sw::parts::kPartFinBasic:
                return PF::makeBox({1.5f, 0.1f, 2.1f}, {0.62f, 0.30f, 0.24f, 1.0f});
            case sw::parts::kPartBatteryPack:
                return PF::makeBox({0.55f, 0.55f, 0.75f}, {0.20f, 0.42f, 0.24f, 1.0f});
            case sw::parts::kPartSolarWing:
                return PF::makeBox({2.8f, 0.06f, 1.1f}, {0.12f, 0.2f, 0.55f, 1.0f});
            case sw::parts::kPartDockingRing:
                return PF::makeBox({1.7f, 1.7f, 0.7f}, {0.68f, 0.7f, 0.74f, 1.0f});
            case sw::parts::kPartDecouplerFlat:
                return PF::makeBox({2.5f, 2.5f, 0.45f}, {0.75f, 0.62f, 0.2f, 1.0f});
            case sw::parts::kPartCargoBaySmall:
                return PF::makeBox({2.6f, 2.6f, 2.2f}, {0.7f, 0.45f, 0.22f, 1.0f});
            case sw::parts::kPartCoreStructural:
            default:
            {
                sw::MeshData core =
                    PF::makeBox({2.2f, 2.2f, 2.6f}, {0.72f, 0.74f, 0.78f, 1.0f});
                PF::append(core,
                           PF::makeBox({1.4f, 0.9f, 0.7f}, {0.25f, 0.55f, 0.75f, 1.0f}),
                           {0.0f, 1.2f, -0.6f});
                return core;
            }
            }
        }

        [[nodiscard]] sw::MeshData buildMarkerMesh()
        {
            // Markers are drawn EMISSIVE (tint alpha 2.0) — normals unused.
            return sw::PrimitiveFactory::makeOctahedron(1.0f, {1.0f, 1.0f, 1.0f, 1.0f});
        }

        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }

        // Noise moved into the engine (Math/Noise.hpp): the terrain
        // heightfield, the globe colors and the clouds share ONE function.
        using sw::math::fbm3;

        // Terrain parameter sets — the SAME constants feed the globe colors
        // (coastlines) and the physics heightfield (collision).
        [[nodiscard]] sw::planet::TerrainComponent terraTerrain()
        {
            sw::planet::TerrainComponent t{};
            t.seed = 1337u;
            t.octaves = 5;
            t.frequency = 2.3f;
            t.amplitude = 9000.0f;
            t.seaLevelFraction = 0.50f;
            t.noiseOffset = {7.31f, 1.17f, 4.73f};
            return t;
        }
        [[nodiscard]] sw::planet::TerrainComponent lunaTerrain()
        {
            sw::planet::TerrainComponent t{};
            t.seed = 4242u;
            t.octaves = 4;
            t.frequency = 3.1f;
            t.amplitude = 8000.0f;
            t.seaLevelFraction = 0.0f; // airless: no ocean, terrain everywhere
            t.noiseOffset = {2.9f, 8.1f, 0.4f};
            return t;
        }
        [[nodiscard]] sw::planet::TerrainComponent marsTerrain()
        {
            sw::planet::TerrainComponent t{};
            t.seed = 900u;
            t.octaves = 5;
            t.frequency = 2.8f;
            t.amplitude = 16000.0f;
            t.seaLevelFraction = 0.0f;
            t.noiseOffset = {5.5f, 3.3f, 9.9f};
            return t;
        }

        // ---- planetary surface palettes (per-vertex, deterministic) -----------
        enum class SurfaceStyle
        {
            Terra,
            Luna,
            Mars,
        };

        void colorizeCelestial(sw::MeshData& mesh, SurfaceStyle style)
        {
            for (sw::Vertex& vertex : mesh.vertices)
            {
                const sw::Vec3 dir = glm::normalize(vertex.position);
                switch (style)
                {
                case SurfaceStyle::Terra:
                {
                    // Continents from low-frequency fBm; sea level cuts it.
                    const sw::f32 h = fbm3(dir * 2.3f + sw::Vec3{7.31f, 1.17f, 4.73f},
                                           5, 1337u);
                    const sw::f32 latitude = std::abs(dir.y);
                    // Tight caps (>66 deg) with a soft noisy edge: no more
                    // ice sprawling toward the equator.
                    const sw::f32 iceEdge =
                        0.91f + 0.03f * (fbm3(dir * 6.0f, 3, 555u) - 0.5f);
                    if (latitude > iceEdge)
                    {
                        vertex.color = {0.92f, 0.94f, 0.97f, 1.0f}; // polar ice
                    }
                    else if (h < 0.50f) // ocean: deep -> coastal shelf
                    {
                        const sw::f32 depth = glm::clamp(h / 0.50f, 0.0f, 1.0f);
                        vertex.color =
                            {glm::mix(0.02f, 0.07f, depth),
                             glm::mix(0.09f, 0.26f, depth),
                             glm::mix(0.24f, 0.45f, depth), 1.0f};
                    }
                    else // land: lowlands -> highlands -> mountains
                    {
                        const sw::f32 relief =
                            glm::clamp((h - 0.50f) / 0.30f, 0.0f, 1.0f);
                        const sw::Vec3 lowland{0.16f, 0.34f, 0.13f};
                        const sw::Vec3 highland{0.42f, 0.34f, 0.20f};
                        // Rocky gray-brown, NOT white: peaks must never be
                        // mistaken for polar caps.
                        const sw::Vec3 peaks{0.48f, 0.44f, 0.40f};
                        const sw::Vec3 land =
                            (relief < 0.6f)
                                ? glm::mix(lowland, highland, relief / 0.6f)
                                : glm::mix(highland, peaks, (relief - 0.6f) / 0.4f);
                        vertex.color = {land.r, land.g, land.b, 1.0f};
                    }
                    break;
                }
                case SurfaceStyle::Luna:
                {
                    // Maria (dark basalt plains) over cratered highlands.
                    const sw::f32 m = fbm3(dir * 3.1f + sw::Vec3{2.9f, 8.1f, 0.4f},
                                           4, 4242u);
                    const sw::f32 detail = fbm3(dir * 11.0f, 3, 4343u);
                    const sw::f32 g =
                        (m < 0.47f ? 0.24f : 0.42f) + 0.16f * (detail - 0.5f);
                    vertex.color = {g, g, g * 1.04f, 1.0f};
                    break;
                }
                case SurfaceStyle::Mars:
                {
                    const sw::f32 h = fbm3(dir * 2.8f + sw::Vec3{5.5f, 3.3f, 9.9f},
                                           5, 900u);
                    const sw::f32 latitude = std::abs(dir.y);
                    if (latitude > 0.93f)
                    {
                        vertex.color = {0.90f, 0.88f, 0.86f, 1.0f}; // CO2 caps
                    }
                    else
                    {
                        const sw::Vec3 dark{0.36f, 0.17f, 0.09f};
                        const sw::Vec3 bright{0.66f, 0.36f, 0.18f};
                        const sw::Vec3 rust = glm::mix(dark, bright, h);
                        vertex.color = {rust.r, rust.g, rust.b, 1.0f};
                    }
                    break;
                }
                }
            }
        }

        // ---- static starfield: parallax-free orientation reference ------------
        constexpr sw::f32 kStarDomeRadius = 1.0e12f; // inside the 1e13 far plane
        constexpr sw::u32 kStarCount = 1700;

        [[nodiscard]] sw::MeshData buildStarfieldMesh()
        {
            sw::MeshData mesh;
            mesh.vertices.reserve(kStarCount * 6);
            mesh.indices.reserve(kStarCount * 24);
            sw::u32 seed = 0xC0FFEEu; // FIXED seed: the sky never changes

            for (sw::u32 star = 0; star < kStarCount; ++star)
            {
                // Uniform direction on the sphere.
                const sw::f32 z = 2.0f * hash01(seed++) - 1.0f;
                const sw::f32 phi = 6.2831853f * hash01(seed++);
                const sw::f32 r = std::sqrt(std::max(0.0f, 1.0f - z * z));
                const sw::Vec3 dir{r * std::cos(phi), z, r * std::sin(phi)};

                // Size and color temperature variation.
                const sw::f32 magnitude = hash01(seed++);
                const sw::f32 size = 0.0006f + 0.0016f * magnitude * magnitude;
                const sw::f32 warm = hash01(seed++);
                const sw::f32 brightness = 0.35f + 0.65f * magnitude;
                const sw::Vec4 color{
                    brightness * (0.85f + 0.15f * warm),
                    brightness * (0.85f + 0.10f * warm),
                    brightness * (1.00f - 0.25f * warm), 1.0f};

                // A small octahedron: orientation-independent point of light.
                const sw::u32 base = static_cast<sw::u32>(mesh.vertices.size());
                const sw::Vec3 axes[6] = {{size, 0, 0},  {-size, 0, 0}, {0, size, 0},
                                          {0, -size, 0}, {0, 0, size},  {0, 0, -size}};
                for (const sw::Vec3& axis : axes)
                {
                    mesh.vertices.push_back({dir + axis, dir, color, {}});
                }
                const sw::u32 quads[8][3] = {{0, 2, 4}, {2, 1, 4}, {1, 3, 4}, {3, 0, 4},
                                             {2, 0, 5}, {1, 2, 5}, {3, 1, 5}, {0, 3, 5}};
                for (const auto& tri : quads)
                {
                    mesh.indices.insert(mesh.indices.end(),
                                        {base + tri[0], base + tri[1], base + tri[2]});
                }
            }
            return mesh;
        }

        // ---- sun glow: radial-falloff emissive discs (billboarded) -------------
        /// Vertex alpha rides the emissive encoding: center 2.0 (opaque
        /// self-lit) fading to 1.0 (fully transparent) at the rim.
        [[nodiscard]] sw::MeshData buildGlowDiscMesh(const sw::Vec3& centerColor,
                                                     const sw::Vec3& rimColor,
                                                     sw::f32 centerAlpha)
        {
            sw::MeshData mesh;
            const sw::Vec3 normal{0.0f, 0.0f, 1.0f};
            mesh.vertices.push_back(
                {{0.0f, 0.0f, 0.0f}, normal,
                 {centerColor.r, centerColor.g, centerColor.b, centerAlpha}, {}});
            constexpr sw::u32 kSegments = 40;
            for (sw::u32 i = 0; i <= kSegments; ++i)
            {
                const sw::f32 a = 6.2831853f * static_cast<sw::f32>(i) / kSegments;
                mesh.vertices.push_back(
                    {{std::cos(a), std::sin(a), 0.0f}, normal,
                     {rimColor.r, rimColor.g, rimColor.b, 1.0f}, {}});
            }
            for (sw::u32 i = 1; i <= kSegments; ++i)
            {
                mesh.indices.insert(mesh.indices.end(), {0u, i, i + 1});
            }
            return mesh;
        }

        // ---- atmosphere & cloud shells (transparent pass) ----------------------
        [[nodiscard]] sw::MeshData buildAtmosphereShellMesh()
        {
            sw::MeshData mesh = sw::PrimitiveFactory::makeUvSphere(
                1.0f, 40, 60, {0.36f, 0.56f, 0.92f, 1.0f});
            // Slightly stronger veil near the poles-of-view is impossible
            // without shaders; a uniform low alpha reads well from both
            // orbit (blue limb) and the ground (blue sky dome).
            for (sw::Vertex& vertex : mesh.vertices)
            {
                vertex.color.a = 0.30f;
            }
            return mesh;
        }

        [[nodiscard]] sw::MeshData buildCloudShellMesh()
        {
            sw::MeshData mesh = sw::PrimitiveFactory::makeUvSphere(
                1.0f, 56, 84, {1.0f, 1.0f, 1.0f, 1.0f});
            for (sw::Vertex& vertex : mesh.vertices)
            {
                const sw::Vec3 dir = glm::normalize(vertex.position);
                const sw::f32 cover =
                    fbm3(dir * 3.6f + sw::Vec3{1.7f, 9.2f, 3.8f}, 5, 77777u);
                // Sparse blobby fields: transparent gaps between systems.
                sw::f32 alpha =
                    glm::clamp((cover - 0.52f) / 0.16f, 0.0f, 1.0f) * 0.85f;
                // Fade out at the poles: the UV-sphere fan pinches all
                // vertices to a point there and the interpolated coverage
                // reads as a glitchy star — clear sky above the caps.
                const sw::f32 polar = std::abs(dir.y);
                if (polar > 0.90f)
                {
                    alpha *= glm::clamp((0.975f - polar) / 0.075f, 0.0f, 1.0f);
                }
                vertex.color = {1.0f, 1.0f, 1.0f, alpha};
            }
            return mesh;
        }
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        // Far planes sized for the full system: the Sun must render from
        // Mars (3.8e11 m away when opposed). Reverse-Z keeps the precision.
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.5f, 1.0e13f);
        m_mapCamera.setPerspective(sw::math::toRadians(60.0f), 1.0e5f, 2.0e12f);
        m_glyphMeshIndex.fill(0xFFFFFFFFu);

        buildScene();
        buildGlyphMeshes();
        buildNavballMeshes();
        m_hangarFloorMeshIndex = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeGridPlane(40.0f, 20, {0.2f, 0.3f, 0.38f, 1.0f})));
        m_hangarCamera.setPerspective(sw::math::toRadians(55.0f), 0.2f, 500.0f);
        buildSaveSchema();
        m_celestialIndex.rebuild(m_world);

        const sw::WorldVec3 stationCenter =
            m_world.getComponent<TransformComponent>(m_terraEntity).position +
            sw::WorldVec3{0.0, 0.0, kStationOrbitRadius};
        m_cameraController.setPose(stationCenter + sw::WorldVec3{0.0, 250.0, 2000.0}, 0.0f,
                                   -0.08f);

        // ---- simulation lanes ---------------------------------------------------
        m_physicsLane = m_simulation.findLane("Physics");
        auto& physics = m_physicsLane->scheduler();
        // Celestials move FIRST: everything else this tick (gravity, rails,
        // anchors) reads their up-to-date positions/velocities.
        physics.addSystem(
            std::make_unique<sw::space::CelestialMotionSystem>(*m_physicsLane));
        physics.addSystem(std::make_unique<SnapshotSystem>());
        // Parts -> vessel aggregates (mass falls as fuel burns).
        physics.addSystem(std::make_unique<sw::parts::VesselAssemblySystem>());
        // Rails ride at Physics rate too: their primaries move ~30 km/s, so
        // a 10 Hz refresh would visibly step (the closed-form solve is cheap).
        physics.addSystem(std::make_unique<sw::phys::RailsSystem>(*m_physicsLane));
        physics.addSystem(std::make_unique<sw::phys::GravityIntegrationSystem>());
        physics.addSystem(std::make_unique<SasSystem>()); // before Thrust: it commands
        physics.addSystem(std::make_unique<ThrustSystem>());
        sw::phys::SurfaceInteractionSystem::Config surfaceConfig{};
        physics.addSystem(
            std::make_unique<sw::phys::SurfaceInteractionSystem>(surfaceConfig));
        physics.addSystem(std::make_unique<CapsuleMovementSystem>());
        physics.addSystem(std::make_unique<SpinSystem>());
        physics.addSystem(std::make_unique<CelestialSpinSystem>());
        // Atmosphere/cloud shells follow their planet (own drift spin).
        physics.addSystem(std::make_unique<CloudLayerSystem>());
        // After the celestial spin: surface bases co-rotate with their body.
        physics.addSystem(std::make_unique<sw::phys::SurfaceAnchorSystem>());
        // Parts ride their vessel (lockstep interpolation), last.
        physics.addSystem(std::make_unique<sw::parts::PartAttachmentSystem>());

        auto& automation = m_simulation.findLane("Automation")->scheduler();
        automation.addSystem(std::make_unique<SolarChargeSystem>());
        automation.addSystem(std::make_unique<sw::factory::MinerSystem>());
        automation.addSystem(std::make_unique<sw::factory::RefinerySystem>());

        auto& logistics = m_simulation.findLane("Logistics")->scheduler();
        logistics.addSystem(std::make_unique<sw::factory::TransferSystem>());
        sw::phys::SimulationBubbleSystem::Config bubbleConfig{};
        bubbleConfig.enterRadius = kBubbleEnterRadius;
        bubbleConfig.exitRadius = kBubbleExitRadius;
        auto bubble = std::make_unique<sw::phys::SimulationBubbleSystem>(
            m_commands, *m_physicsLane, bubbleConfig);
        m_bubbleSystem = bubble.get();
        logistics.addSystem(std::move(bubble));

        m_simulation.findLane("World")->scheduler().addSystem(
            std::make_unique<StatsSystem>());

        SW_LOG_INFO("Game", "Milestone 10 scene ready: {} entities", m_world.aliveCount());
        SW_LOG_INFO("Game",
                    "Controls: Tab pilot/free | G EVA capsule | M map (wheel zoom) | V "
                    "speed ORB/SRF | Shift/Ctrl throttle | ,/. warp | W/S A/D arrows Q/E "
                    "X | Space pause | Esc quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    CelestialLodComponent StarWorksGame::makeSphereLodSet(const sw::Vec4& color,
                                                          sw::i32 surfaceStyle)
    {
        CelestialLodComponent lod{};
        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels; ++level)
        {
            sw::MeshData sphere = sw::PrimitiveFactory::makeUvSphere(
                1.0f, kLodRings[level], kLodSegments[level], color);
            if (surfaceStyle >= 0)
            {
                colorizeCelestial(sphere, static_cast<SurfaceStyle>(surfaceStyle));
            }
            lod.meshIndex[level] = registerMesh(renderer().createMesh(sphere));
        }
        return lod;
    }

    void StarWorksGame::buildGlyphMeshes()
    {
        for (const char* c = kGlyphCharset; *c != '\0'; ++c)
        {
            const sw::MeshData glyph = sw::ui::buildGlyphMesh(*c);
            if (!glyph.empty())
            {
                m_glyphMeshIndex[static_cast<sw::usize>(*c)] =
                    registerMesh(renderer().createMesh(glyph));
            }
        }
    }

    void StarWorksGame::buildNavballMeshes()
    {
        m_navRingMeshIndex =
            registerMesh(renderer().createMesh(buildNavRingMesh(48, 0.06f)));
        m_navLineMeshIndex = registerMesh(renderer().createMesh(buildNavBarMesh()));
        m_navDiamondMeshIndex =
            registerMesh(renderer().createMesh(buildNavDiamondMesh()));
    }

    void StarWorksGame::buildScene()
    {
        // ---- meshes -------------------------------------------------------------
        // Sol's colors exceed 1.0 slightly: paired with the emissive tint it
        // reads as a glowing star, not a lit rock.
        const CelestialLodComponent solLod =
            makeSphereLodSet({1.0f, 0.92f, 0.72f, 1.0f});
        const CelestialLodComponent terraLod = makeSphereLodSet(
            {0.21f, 0.33f, 0.48f, 1.0f}, static_cast<sw::i32>(SurfaceStyle::Terra));
        const CelestialLodComponent lunaLod = makeSphereLodSet(
            {0.42f, 0.41f, 0.43f, 1.0f}, static_cast<sw::i32>(SurfaceStyle::Luna));
        const CelestialLodComponent marsLod = makeSphereLodSet(
            {0.62f, 0.32f, 0.18f, 1.0f}, static_cast<sw::i32>(SurfaceStyle::Mars));

        // Environment meshes: the fixed star dome, Terra's atmosphere veil
        // and its drifting cloud shell.
        m_starfieldMeshIndex =
            registerMesh(renderer().createMesh(buildStarfieldMesh()));
        m_sunHaloMeshIndex = registerMesh(renderer().createMesh(buildGlowDiscMesh(
            {1.0f, 0.86f, 0.62f}, {1.0f, 0.5f, 0.22f}, 1.55f)));
        m_sunCoreMeshIndex = registerMesh(renderer().createMesh(buildGlowDiscMesh(
            {1.0f, 0.99f, 0.94f}, {1.0f, 0.86f, 0.55f}, 2.0f)));
        const sw::u32 atmosphereMeshId =
            registerMesh(renderer().createMesh(buildAtmosphereShellMesh()));
        const sw::u32 cloudMeshId =
            registerMesh(renderer().createMesh(buildCloudShellMesh()));

        sw::u32 asteroidMeshId = 0;
        sw::f32 asteroidBoundsRadius = 2.5f;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f})));
            asteroidBoundsRadius = 1.0f;
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        // Part meshes, indexed by catalog id (small ids: direct table).
        for (const sw::parts::PartDefinition& definition : sw::parts::catalog())
        {
            m_partMeshIds[definition.id] =
                registerMesh(renderer().createMesh(buildPartMesh(definition.id)));
        }
        const auto& partMeshIds = m_partMeshIds;
        m_capsuleMeshIndex = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCapsule(0.5f, 0.5f, 12, 16,
                                              {0.9f, 0.6f, 0.2f, 1.0f})));
        m_markerMeshIndex = registerMesh(renderer().createMesh(buildMarkerMesh()));

        // Sun position and eclipse occluders are camera-relative and set
        // every frame in onRender.

        auto snapshotOf = [](const TransformComponent& transform) {
            return PreviousTransformComponent{transform.position, transform.rotation};
        };

        // ================= THE HIERARCHY: Sol -> Terra/Mars -> Luna ==============
        // Parent-relative Kepler elements, real values. Initial world
        // positions are the analytic evaluation at t=0 — identical to what
        // the CelestialMotionSystem will compute on the first tick.

        // ---- Sol: the static root ------------------------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{}; // world origin
            transform.uniformScale = static_cast<sw::f32>(kSolRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, solLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.9e-6f});
            sw::phys::GravitySourceComponent gravity{kMuSol, kSolRadius};
            gravity.angularVelocity = {0.0, 2.9e-6, 0.0};
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, sw::space::makeCelestialBody("SOL"));
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.85f, 0.3f, 1.0f}});
            m_solEntity = e;
        }

        // ---- Terra: SOLID SURFACE + ATMOSPHERE, on rails around Sol --------------
        const sw::phys::KeplerOrbit terraOrbit = sw::phys::kepler::fromElements(
            kMuSol, kTerraSma, 0.0167, 0.0, 0.0, 0.0, /*M0=*/0.0, /*epoch=*/0.0);
        sw::WorldVec3 terraPos0{};
        sw::phys::kepler::evaluate(terraOrbit, 0.0, terraPos0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = terraPos0;
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, terraLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.2921e-5f});
            sw::phys::GravitySourceComponent gravity{kMuTerra, kTerraRadius};
            gravity.soiRadius = kTerraSoi;
            gravity.angularVelocity = kTerraAngularVelocity; // matches the Spin
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, sw::phys::AtmosphereComponent{1.225, 8500.0, 1.4e5});
            m_world.addComponent(e, terraTerrain()); // REAL ground: collision + visuals
            m_world.addComponent(e, sw::space::makeCelestialBody("TERRA", m_solEntity,
                                                                 &terraOrbit));
            m_world.addComponent(e, MapMarkerComponent{{0.35f, 0.65f, 1.0f, 1.0f}});
            m_terraEntity = e;
        }
        const sw::ecs::Entity terraEntity = m_terraEntity;

        // ---- Terra's VISIBLE atmosphere + cloud deck (transparent shells) --------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = terraPos0;
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius * 1.012); // ~77 km
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            MeshComponent mesh{atmosphereMeshId};
            mesh.transparent = 1;
            m_world.addComponent(e, mesh);
            m_world.addComponent(e, CloudLayerComponent{terraEntity, {0, 1, 0}, 0.0f});
        }
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = terraPos0;
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius * 1.005); // ~32 km
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            MeshComponent mesh{cloudMeshId};
            mesh.transparent = 1;
            m_world.addComponent(e, mesh);
            // Slightly faster than Terra's spin: clouds DRIFT over the ground.
            m_world.addComponent(e, CloudLayerComponent{terraEntity, {0, 1, 0}, 8.6e-5f});
        }

        // ---- Luna: around TERRA (5.14 deg inclination, real) ---------------------
        const sw::phys::KeplerOrbit lunaOrbit = sw::phys::kepler::fromElements(
            kMuTerra, kLunaSma, 0.0549, 0.0897, 0.0, 0.0, /*M0=*/0.6, /*epoch=*/0.0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::WorldVec3 lunaRel{};
            sw::phys::kepler::evaluate(lunaOrbit, 0.0, lunaRel);
            transform.position = terraPos0 + lunaRel;
            transform.uniformScale = static_cast<sw::f32>(kLunaRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, lunaLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.66e-6f});
            sw::phys::GravitySourceComponent gravity{kMuLuna, kLunaRadius};
            gravity.soiRadius = kLunaSoi;
            gravity.angularVelocity = {0.0, 2.66e-6, 0.0};
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, lunaTerrain());
            m_world.addComponent(e, sw::space::makeCelestialBody("LUNA", terraEntity,
                                                                 &lunaOrbit));
            m_world.addComponent(e, MapMarkerComponent{{0.75f, 0.75f, 0.78f, 1.0f}});
        }

        // ---- Mars: second planet, red and far -------------------------------------
        const sw::phys::KeplerOrbit marsOrbit = sw::phys::kepler::fromElements(
            kMuSol, kMarsSma, 0.0934, 0.0323, 0.0, 0.0, /*M0=*/2.0, /*epoch=*/0.0);
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(marsOrbit, 0.0, transform.position);
            transform.uniformScale = static_cast<sw::f32>(kMarsRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, marsLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.088e-5f});
            sw::phys::GravitySourceComponent gravity{kMuMars, kMarsRadius};
            gravity.soiRadius = kMarsSoi;
            gravity.angularVelocity = {0.0, 7.088e-5, 0.0};
            m_world.addComponent(e, gravity);
            m_world.addComponent(e, marsTerrain());
            m_world.addComponent(e, sw::space::makeCelestialBody("MARS", m_solEntity,
                                                                 &marsOrbit));
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.45f, 0.25f, 1.0f}});
        }

        // ============ EVERYTHING ELSE LIVES IN TERRA'S SOI ========================
        // Spawns are TERRA-relative: dynamic bodies add Terra's world
        // position and orbital velocity; rails objects simply reference
        // Terra as their primary (relative elements unchanged).
        sw::WorldVec3 terraVel0{};
        {
            sw::WorldVec3 unused{};
            sw::phys::kepler::evaluate(terraOrbit, 0.0, unused, &terraVel0);
        }
        const sw::WorldVec3 stationCenter =
            terraPos0 + sw::WorldVec3{0.0, 0.0, kStationOrbitRadius};

        // ---- GROUND OUTPOST: a mine built ON the planet surface -----------------
        // Anchored in Terra's rotating frame: it rides the planet's rotation
        // and survives save/load at its exact construction site — the model
        // every future surface factory will follow.
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.uniformScale = 40.0f; // 40 m mining rig
            m_world.addComponent(e, transform);
            m_world.addComponent(e, PreviousTransformComponent{});
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.35f, 0.3f, 1.0f}});
            // Anchored ON the terrain: sample the shared heightfield at
            // the site's body-frame direction so the rig sits on the ground.
            const sw::f64 siteElevation = sw::planet::terrainElevation(
                terraTerrain(), sw::Vec3{0.0f, 0.0f, 1.0f});
            m_world.addComponent(
                e, sw::phys::SurfaceAnchorComponent{
                       terraEntity,
                       {0.0, 0.0, kTerraRadius + siteElevation + 18.0}}); // equator, +Z

            sw::factory::InventoryComponent pit{};
            pit.volumeCapacityM3 = 30.0;
            m_world.addComponent(e, pit);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 1.0, 0.0});
        }

        // ---- asteroid: dynamic body + mining site ---------------------------------
        sw::ecs::Entity asteroidEntity{};
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{650.0, 120.0, -300.0};
            transform.uniformScale = 120.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{asteroidBoundsRadius});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.05f});
            m_world.addComponent(e, MapMarkerComponent{{0.85f, 0.65f, 0.35f, 1.0f}});

            const sw::f64 radius = glm::length(transform.position - terraPos0);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(e, sw::phys::DynamicBodyComponent{
                                        terraVel0 + sw::WorldVec3{speed, 0.0, 0.0}, 5.0e8});

            sw::factory::InventoryComponent hopper{};
            hopper.volumeCapacityM3 = 40.0;
            m_world.addComponent(e, hopper);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 2.0, 0.0});
            asteroidEntity = e;
        }

        // ---- THE PLAYER ROCKET: a vessel assembled from catalog parts -----------
        // The root entity is the rigid body + controls; every part is its
        // own entity riding the root (entity-per-part is what will make
        // staging, docking and damage cheap later).
        {
            const sw::ecs::Entity root = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{-250.0, 60.0, 400.0};
            m_world.addComponent(root, transform);
            m_world.addComponent(root, snapshotOf(transform));
            m_world.addComponent(root, BoundsComponent{0.1f}); // parts render, not the root
            m_world.addComponent(root, MapMarkerComponent{{0.3f, 1.0f, 0.5f, 1.0f}});
            m_world.addComponent(root, ShipComponent{});
            m_world.addComponent(root, ShipControlsComponent{});
            m_world.addComponent(root, SasComponent{});
            m_world.addComponent(root, sw::parts::VesselComponent{});

            const sw::f64 radius = glm::length(transform.position - terraPos0);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            // Mass/drag are overwritten by the VesselAssemblySystem each tick.
            m_world.addComponent(root, sw::phys::DynamicBodyComponent{
                                           terraVel0 + sw::WorldVec3{speed, 0.0, 0.0},
                                           4.0e4});
            m_shipEntity = root;

            auto spawnPart = [&](sw::u32 definitionId, const sw::Vec3& localPosition,
                                 const sw::Quat& localRotation = {1, 0, 0, 0},
                                 sw::f32 boundsRadius = 3.0f) {
                const sw::ecs::Entity part = m_world.createEntity();
                TransformComponent partTransform{};
                partTransform.position =
                    transform.position + sw::WorldVec3(localPosition);
                partTransform.rotation = localRotation;
                m_world.addComponent(part, partTransform);
                m_world.addComponent(part, snapshotOf(partTransform));
                m_world.addComponent(part, BoundsComponent{boundsRadius});
                m_world.addComponent(part, MeshComponent{partMeshIds[definitionId]});
                sw::parts::PartComponent partComponent{};
                partComponent.definitionId = definitionId;
                partComponent.vessel = root;
                partComponent.localPosition = localPosition;
                partComponent.localRotation = localRotation;
                m_world.addComponent(part, partComponent);
                return part;
            };

            // Stack, nose (-Z) to tail (+Z): every one of the 9 part types,
            // wired together by REAL JOINT ENTITIES (each with its own
            // strength/break force — the structural truth of the vessel).
            auto joint = [&](sw::ecs::Entity a, sw::ecs::Entity b, sw::u8 pointA,
                             sw::u8 pointB, sw::parts::JointType type) {
                const sw::f64 force = std::min(
                    sw::parts::findDefinition(
                        m_world.getComponent<sw::parts::PartComponent>(a).definitionId)
                        ->breakingForceN,
                    sw::parts::findDefinition(
                        m_world.getComponent<sw::parts::PartComponent>(b).definitionId)
                        ->breakingForceN);
                sw::parts::connectParts(m_world, a, b, pointA, pointB, type, force,
                                        force);
            };
            using JT = sw::parts::JointType;
            const auto dock =
                spawnPart(sw::parts::kPartDockingRing, {0.0f, 0.0f, -9.0f}, {1, 0, 0, 0}, 1.4f);
            const auto core =
                spawnPart(sw::parts::kPartCoreStructural, {0.0f, 0.0f, -7.2f}, {1, 0, 0, 0}, 2.2f);
            const auto cargo =
                spawnPart(sw::parts::kPartCargoBaySmall, {0.0f, 0.0f, -4.6f}, {1, 0, 0, 0}, 2.3f);
            const auto decoupler =
                spawnPart(sw::parts::kPartDecouplerFlat, {0.0f, 0.0f, -3.2f}, {1, 0, 0, 0}, 1.9f);
            const sw::ecs::Entity tankA =
                spawnPart(sw::parts::kPartFuelTankMedium, {0.0f, 0.0f, -0.8f},
                          {1, 0, 0, 0}, 2.8f);
            const sw::ecs::Entity tankB =
                spawnPart(sw::parts::kPartFuelTankMedium, {0.0f, 0.0f, 3.6f},
                          {1, 0, 0, 0}, 2.8f);
            const auto engine =
                spawnPart(sw::parts::kPartEngineVector, {0.0f, 0.0f, 6.6f}, {1, 0, 0, 0}, 1.6f);
            const auto finR =
                spawnPart(sw::parts::kPartFinBasic, {1.9f, 0.0f, 5.7f}, {1, 0, 0, 0}, 1.4f);
            const auto finL =
                spawnPart(sw::parts::kPartFinBasic, {-1.9f, 0.0f, 5.7f}, {1, 0, 0, 0}, 1.4f);
            const sw::ecs::Entity battery =
                spawnPart(sw::parts::kPartBatteryPack, {1.65f, 0.0f, -4.6f},
                          {1, 0, 0, 0}, 0.7f);
            const auto solar =
                spawnPart(sw::parts::kPartSolarWing, {-2.85f, 0.0f, -4.6f}, {1, 0, 0, 0}, 1.6f);
            joint(dock, core, 0, 0, JT::Stack);
            joint(core, cargo, 1, 0, JT::Stack);
            joint(cargo, decoupler, 1, 0, JT::Stack);
            joint(decoupler, tankA, 1, 0, JT::Stack);
            joint(tankA, tankB, 1, 0, JT::Stack);
            joint(tankB, engine, 1, 0, JT::Stack);
            joint(cargo, battery, 2, 0, JT::Radial);
            joint(cargo, solar, 3, 0, JT::Radial);
            joint(tankB, finR, 2, 0, JT::Radial);
            joint(tankB, finL, 3, 0, JT::Radial);

            // Fill the tanks and half-charge the battery (capacities from
            // the catalog; resources are ordinary volume-bounded cargo).
            for (const sw::ecs::Entity tank : {tankA, tankB})
            {
                sw::factory::InventoryComponent inventory{};
                inventory.volumeCapacityM3 = 21.0;
                sw::factory::inventoryAdd(inventory, sw::res::Resource::Fuel, 16000.0);
                m_world.addComponent(tank, inventory);
            }
            {
                sw::factory::InventoryComponent inventory{};
                inventory.volumeCapacityM3 = 0.12;
                sw::factory::inventoryAdd(inventory,
                                          sw::res::Resource::ElectricCharge, 400.0);
                m_world.addComponent(battery, inventory);
            }
        }

        // ---- station modules (rails around TERRA) + refinery / depot ---------------
        sw::ecs::Entity refineryEntity{};
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f64 offset =
                (static_cast<sw::f64>(i) / kStationModuleCount - 0.5) * 1.0e-4;
            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, kStationOrbitRadius + (static_cast<sw::f64>(i) - 3.5) * 12.0,
                0.0, 0.0, 0.0, 0.0, kStationPhase + offset, 0.0);

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(orbit, 0.0, transform.position);
            transform.position += terraPos0;
            transform.uniformScale = 30.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            sw::phys::OnRailsComponent rails{};
            rails.orbit = orbit;
            rails.primary = terraEntity;
            rails.dynamicMass = 2.0e5; // a 200 t module, if ever de-railed
            m_world.addComponent(e, rails);
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f},
                                                  0.1f + hash01(i) * 0.1f});
            if (i == 0)
            {
                m_world.addComponent(e, MapMarkerComponent{{1.0f, 1.0f, 1.0f, 1.0f}});
                sw::factory::InventoryComponent tanks{};
                tanks.volumeCapacityM3 = 15.0;
                m_world.addComponent(e, tanks);
                m_world.addComponent(e, sw::factory::RefineryComponent{
                                            sw::res::Resource::IronOre,
                                            sw::res::Resource::Iron, 1.0, 0.9, 0.0});
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            asteroidEntity, sw::res::Resource::IronOre,
                                            1.5});
                refineryEntity = e;
            }
            else if (i == 1)
            {
                sw::factory::InventoryComponent silo{};
                silo.volumeCapacityM3 = 60.0;
                m_world.addComponent(e, silo);
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            refineryEntity, sw::res::Resource::Iron, 1.0});
            }
        }
    }

    void StarWorksGame::buildSaveSchema()
    {
        // Stable names + versions. Bump a version whenever the struct layout
        // changes; the loader refuses mismatches instead of guessing.
        m_saveSchema.registerComponent<sw::TransformComponent>("sw.Transform", 1);
        m_saveSchema.registerComponent<sw::PreviousTransformComponent>(
            "sw.PreviousTransform", 1);
        m_saveSchema.registerComponent<sw::phys::DynamicBodyComponent>("phys.DynamicBody",
                                                                       1);
        // v2: primary-relative orbit + primary handle + dynamic payload.
        m_saveSchema.registerComponent<sw::phys::OnRailsComponent>("phys.OnRails", 2);
        // v3: SOI radius + world velocity + angular velocity (spin).
        m_saveSchema.registerComponent<sw::phys::GravitySourceComponent>(
            "phys.GravitySource", 3);
        m_saveSchema.registerComponent<sw::space::CelestialBodyComponent>(
            "space.CelestialBody", 1);
        m_saveSchema.registerComponent<sw::phys::AtmosphereComponent>("phys.Atmosphere", 1);
        m_saveSchema.registerComponent<sw::phys::SurfaceAnchorComponent>(
            "phys.SurfaceAnchor", 1);
        m_saveSchema.registerComponent<sw::planet::TerrainComponent>("planet.Terrain", 1);
        m_saveSchema.registerComponent<SasComponent>("game.Sas", 1);
        m_saveSchema.registerComponent<sw::parts::PartComponent>("parts.Part", 1);
        m_saveSchema.registerComponent<sw::parts::VesselComponent>("parts.Vessel", 1);
        m_saveSchema.registerComponent<sw::parts::JointComponent>("parts.Joint", 1);
        m_saveSchema.registerComponent<sw::factory::InventoryComponent>("factory.Inventory",
                                                                        1);
        m_saveSchema.registerComponent<sw::factory::MinerComponent>("factory.Miner", 1);
        m_saveSchema.registerComponent<sw::factory::RefineryComponent>("factory.Refinery",
                                                                       1);
        m_saveSchema.registerComponent<sw::factory::ItemLinkComponent>("factory.ItemLink",
                                                                       1);
        m_saveSchema.registerComponent<BoundsComponent>("game.Bounds", 1);
        m_saveSchema.registerComponent<SpinComponent>("game.Spin", 1);
        m_saveSchema.registerComponent<MeshComponent>("game.Mesh", 2); // v2: transparent
        m_saveSchema.registerComponent<CloudLayerComponent>("game.CloudLayer", 1);
        m_saveSchema.registerComponent<CelestialLodComponent>("game.CelestialLod", 1);
        m_saveSchema.registerComponent<ShipComponent>("game.Ship", 1);
        m_saveSchema.registerComponent<ShipControlsComponent>("game.ShipControls", 1);
        m_saveSchema.registerComponent<CapsuleComponent>("game.Capsule", 1);
        m_saveSchema.registerComponent<MapMarkerComponent>("game.MapMarker", 1);
    }

    void StarWorksGame::saveGame()
    {
        sw::ser::BinaryWriter writer;
        writer.write<sw::u32>(0x53575347); // "SWSG"
        writer.write<sw::u32>(7);          // game save version (7: Milestone 17)

        sw::save::saveWorld(m_world, m_saveSchema, writer);
        sw::save::saveSimulation(m_simulation, writer);

        // Player/session state.
        writer.write(m_shipEntity);
        writer.write(m_capsuleEntity);
        writer.write(static_cast<sw::u8>(m_evaMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_shipMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_speedSurfaceRelative ? 1 : 0));
        writer.write(m_warpIndex);
        writer.write(m_mapHeightMeters);
        writer.write(m_camera.position());
        writer.write(m_camera.orientation());
        // Maneuver node (v4).
        writer.write(static_cast<sw::u8>(m_nodeActive ? 1 : 0));
        writer.write(m_nodeTime);
        writer.write(m_nodePrograde);
        writer.write(m_nodeNormal);
        writer.write(m_nodeRadial);

        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        sw::FileSystem::writeBinaryFile(path, writer.bytes());
        SW_LOG_INFO("Game", "Saved to '{}' ({} KB, {} entities, t={:.1f}s)", path.string(),
                    writer.size() / 1024, m_world.aliveCount(),
                    m_simulation.simulatedSeconds());
    }

    void StarWorksGame::loadGame()
    {
        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        const std::vector<sw::u8> bytes = sw::FileSystem::readBinaryFile(path);
        sw::ser::BinaryReader reader(bytes);

        if (reader.read<sw::u32>() != 0x53575347)
        {
            SW_THROW("'{}' is not a StarWorks save", path.string());
        }
        if (const sw::u32 version = reader.read<sw::u32>(); version != 7)
        {
            SW_THROW("Unsupported save version {}", version);
        }

        sw::save::loadWorld(m_world, m_saveSchema, reader);
        sw::save::loadSimulation(m_simulation, reader);
        m_celestialIndex.rebuild(m_world);
        m_lastPredictionSeconds = -1.0e9; // stale flight plan: recompute

        m_shipEntity = reader.read<sw::ecs::Entity>();
        m_capsuleEntity = reader.read<sw::ecs::Entity>();
        m_evaMode = reader.read<sw::u8>() != 0;
        m_shipMode = reader.read<sw::u8>() != 0;
        m_speedSurfaceRelative = reader.read<sw::u8>() != 0;
        m_warpIndex = reader.read<sw::u32>();
        m_mapHeightMeters = reader.read<sw::f64>();
        m_camera.setPosition(reader.read<sw::WorldVec3>());
        m_camera.setOrientation(reader.read<sw::Quat>());
        m_nodeActive = reader.read<sw::u8>() != 0;
        m_nodeTime = reader.read<sw::f64>();
        m_nodePrograde = reader.read<sw::f64>();
        m_nodeNormal = reader.read<sw::f64>();
        m_nodeRadial = reader.read<sw::f64>();
        if (const auto* sas = m_world.tryGetComponent<SasComponent>(m_shipEntity))
        {
            m_sasMode = sas->mode;
        }
        // Force a terrain patch rebuild on the next frame.
        m_lastTerrainRebuildSeconds = -1.0e9;
        m_terrainBody = {};

        if (!m_shipMode)
        {
            const sw::Vec3 forward = m_camera.forward();
            m_cameraController.setPose(
                m_camera.position(), std::atan2(-forward.x, -forward.z),
                std::asin(std::clamp(forward.y, -1.0f, 1.0f)));
        }

        SW_LOG_INFO("Game", "Loaded '{}': {} entities, t={:.1f}s, warp x{:g}",
                    path.string(), m_world.aliveCount(), m_simulation.simulatedSeconds(),
                    kWarpLadder[m_warpIndex]);
    }

    sw::ecs::Entity StarWorksGame::controlledEntity() const
    {
        return (m_evaMode && !m_capsuleEntity.isNull()) ? m_capsuleEntity : m_shipEntity;
    }

    sw::WorldVec3 StarWorksGame::controlledVelocity() const
    {
        const sw::ecs::Entity entity = controlledEntity();
        auto& world = const_cast<sw::ecs::World&>(m_world);
        if (const auto* body =
                world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity))
        {
            return body->velocity;
        }
        if (const auto* rails = world.tryGetComponent<sw::phys::OnRailsComponent>(entity))
        {
            sw::WorldVec3 position{};
            sw::WorldVec3 velocity{};
            sw::phys::kepler::evaluate(rails->orbit, m_physicsLane->presentSeconds(),
                                       position, &velocity);
            // The orbit is primary-relative: add the primary's own motion.
            if (const auto* primary = world.tryGetComponent<sw::phys::GravitySourceComponent>(
                    rails->primary))
            {
                velocity += primary->worldVelocity;
            }
            return velocity;
        }
        return {0.0, 0.0, 0.0};
    }

    sw::f32 StarWorksGame::heatingFactorFor(sw::ecs::Entity entity) const
    {
        auto& world = const_cast<sw::ecs::World&>(m_world);
        const auto* body = world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity);
        const auto* transform = world.tryGetComponent<TransformComponent>(entity);
        if (body == nullptr || transform == nullptr || m_celestialIndex.size() == 0)
        {
            return 0.0f;
        }
        const sw::i32 primaryIndex = m_celestialIndex.soiPrimaryAt(
            transform->position, m_physicsLane->presentSeconds());
        if (primaryIndex < 0)
        {
            return 0.0f;
        }
        const auto& primary =
            m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
        const auto* atmosphere =
            world.tryGetComponent<sw::phys::AtmosphereComponent>(primary.entity);
        const auto* source =
            world.tryGetComponent<sw::phys::GravitySourceComponent>(primary.entity);
        const auto* primaryTransform =
            world.tryGetComponent<TransformComponent>(primary.entity);
        if (atmosphere == nullptr || source == nullptr || primaryTransform == nullptr)
        {
            return 0.0f;
        }

        const sw::WorldVec3 radial = transform->position - primaryTransform->position;
        const sw::f64 altitude = glm::length(radial) - primary.bodyRadius;
        if (altitude > atmosphere->topAltitude)
        {
            return 0.0f;
        }
        const sw::f64 density =
            atmosphere->surfaceDensity *
            std::exp(-std::max(altitude, 0.0) / atmosphere->scaleHeight);
        // Air moves with the planet: translation + spin at this point.
        const sw::WorldVec3 airVelocity =
            source->worldVelocity + glm::cross(source->angularVelocity, radial);
        const sw::f64 speed = glm::length(body->velocity - airVelocity);
        const sw::f64 q = density * speed * speed * speed;
        if (q <= kHeatGlowStart)
        {
            return 0.0f;
        }
        return std::clamp(
            static_cast<sw::f32>(std::log10(q / kHeatGlowStart)) / kHeatLogRange, 0.0f,
            1.0f);
    }

    void StarWorksGame::updateReentryEffects(sw::f32 deltaSeconds)
    {
        m_shipHeat = heatingFactorFor(m_shipEntity);
        m_capsuleHeat =
            m_capsuleEntity.isNull() ? 0.0f : heatingFactorFor(m_capsuleEntity);

        // ---- age & move existing particles (visual, render-frame rate) ------
        for (sw::usize i = 0; i < m_particles.size();)
        {
            ReentryParticle& particle = m_particles[i];
            particle.life -= deltaSeconds;
            if (particle.life <= 0.0f)
            {
                m_particles[i] = m_particles.back();
                m_particles.pop_back();
                continue;
            }
            particle.position += particle.velocity * static_cast<sw::f64>(deltaSeconds);
            ++i;
        }

        // ---- spawn plasma behind hot craft -----------------------------------
        auto spawnFor = [this, deltaSeconds](sw::ecs::Entity entity, sw::f32 heat) {
            if (heat < 0.05f)
            {
                return;
            }
            const auto* transform = m_world.tryGetComponent<TransformComponent>(entity);
            const auto* body =
                m_world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity);
            if (transform == nullptr || body == nullptr)
            {
                return;
            }

            // Spawn from the INTERPOLATED pose — the craft is RENDERED
            // there. Spawning at the raw physics-tick position offset the
            // whole cloud from the ship by up to a tick of motion (~600 m
            // of planetary travel): the "same offset on every particle" bug.
            sw::WorldVec3 spawnOrigin = transform->position;
            if (const auto* previous =
                    m_world.tryGetComponent<PreviousTransformComponent>(entity))
            {
                spawnOrigin =
                    glm::mix(previous->position, transform->position,
                             static_cast<sw::f64>(m_physicsLane->alpha()));
            }

            // The wake trails opposite the motion THROUGH THE AIR. The raw
            // world velocity is dominated by the planet's own 30 km/s
            // orbital motion and would point the trail the wrong way.
            sw::WorldVec3 airVelocity{0.0};
            const sw::i32 primaryIndex = m_celestialIndex.soiPrimaryAt(
                transform->position, m_physicsLane->presentSeconds());
            if (primaryIndex >= 0)
            {
                const auto& primary =
                    m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
                const auto* source =
                    m_world.tryGetComponent<sw::phys::GravitySourceComponent>(
                        primary.entity);
                const auto* primaryTransform =
                    m_world.tryGetComponent<TransformComponent>(primary.entity);
                if (source != nullptr && primaryTransform != nullptr)
                {
                    airVelocity =
                        source->worldVelocity +
                        glm::cross(source->angularVelocity,
                                   transform->position - primaryTransform->position);
                }
            }
            const sw::WorldVec3 relativeVelocity = body->velocity - airVelocity;
            const sw::f64 speed = glm::length(relativeVelocity);
            if (speed < 1.0)
            {
                return;
            }
            const sw::WorldVec3 backward = -relativeVelocity / speed;

            m_particleSpawnDebt += (40.0f + 280.0f * heat) * deltaSeconds;
            auto random01 = [this] { return hash01(m_particleSeed++); };
            while (m_particleSpawnDebt >= 1.0f && m_particles.size() < kMaxParticles)
            {
                m_particleSpawnDebt -= 1.0f;
                ReentryParticle particle{};
                const sw::WorldVec3 jitter{random01() - 0.5f, random01() - 0.5f,
                                           random01() - 0.5f};
                // The plasma is shed along the wake, BEHIND the craft: a
                // glowing tail rather than a cloud around the camera.
                particle.position = spawnOrigin +
                                    backward * (12.0 + 160.0 * random01()) +
                                    jitter * 7.0;
                particle.velocity = body->velocity +
                                    backward * (60.0 + 260.0 * random01()) +
                                    jitter * 30.0;
                particle.maxLife = 0.35f + 0.75f * random01();
                particle.life = particle.maxLife;
                particle.size = (0.20f + 0.45f * random01()) * (0.5f + heat);
                // Long incandescent STREAK along the airflow.
                particle.streakDirection = sw::Vec3(backward);
                particle.stretch = 5.0f + 6.0f * heat;
                particle.kind = 0;
                m_particles.push_back(particle);
            }
        };
        spawnFor(m_shipEntity, m_shipHeat);
        if (!m_capsuleEntity.isNull())
        {
            spawnFor(m_capsuleEntity, m_capsuleHeat);
        }

        // ---- engine exhaust jet ----------------------------------------------
        const auto* ship = m_world.tryGetComponent<ShipComponent>(m_shipEntity);
        const auto* controls =
            m_world.tryGetComponent<ShipControlsComponent>(m_shipEntity);
        const auto* shipBody =
            m_world.tryGetComponent<sw::phys::DynamicBodyComponent>(m_shipEntity);
        const auto* shipTransform =
            m_world.tryGetComponent<TransformComponent>(m_shipEntity);
        if (ship != nullptr && controls != nullptr && shipBody != nullptr &&
            shipTransform != nullptr && controls->thrustAxis != 0.0f &&
            ship->throttle > 0.01f)
        {
            const sw::f32 power = ship->throttle * std::abs(controls->thrustAxis);
            m_particleSpawnDebt += 220.0f * power * deltaSeconds;
            auto random01 = [this] { return hash01(m_particleSeed++); };
            // The plume leaves through the nozzle, OPPOSITE the thrust:
            // forward burn -> jet out the back (+Z body), retro -> the front.
            const sw::f32 jetSign = (controls->thrustAxis > 0.0f) ? 1.0f : -1.0f;
            const sw::Vec3 jetDir =
                shipTransform->rotation * sw::Vec3{0.0f, 0.0f, jetSign};
            sw::WorldVec3 exhaustOrigin = shipTransform->position;
            if (const auto* previous =
                    m_world.tryGetComponent<PreviousTransformComponent>(m_shipEntity))
            {
                exhaustOrigin =
                    glm::mix(previous->position, shipTransform->position,
                             static_cast<sw::f64>(m_physicsLane->alpha()));
            }
            const sw::WorldVec3 nozzle = exhaustOrigin + sw::WorldVec3(jetDir) * 9.5;
            while (m_particleSpawnDebt >= 1.0f && m_particles.size() < kMaxParticles)
            {
                m_particleSpawnDebt -= 1.0f;
                ReentryParticle particle{};
                const sw::WorldVec3 jitter{random01() - 0.5f, random01() - 0.5f,
                                           random01() - 0.5f};
                particle.position = nozzle + jitter * 1.2;
                particle.velocity = shipBody->velocity +
                                    sw::WorldVec3(jetDir) * (70.0 + 90.0 * random01()) +
                                    jitter * 7.0;
                particle.maxLife = 0.22f + 0.30f * random01();
                particle.life = particle.maxLife;
                particle.size = 0.28f + 0.35f * random01();
                particle.streakDirection = jetDir;
                particle.stretch = 3.0f;
                particle.kind = 1;
                m_particles.push_back(particle);
            }
        }
    }

    void StarWorksGame::collectParticles(const sw::Camera& activeCamera)
    {
        const sw::WorldVec3 cameraPosition = activeCamera.position();
        for (const ReentryParticle& particle : m_particles)
        {
            const sw::f32 lifeFraction = particle.life / particle.maxLife; // 1 -> 0
            const sw::f32 heatColor = lifeFraction * lifeFraction;

            sw::Vec4 tint{};
            if (particle.kind == 0) // plasma: white-hot -> deep red
            {
                tint = {1.0f, 0.25f + 0.65f * heatColor, 0.05f + 0.45f * heatColor,
                        2.0f};
            }
            else // exhaust: blue-white flame -> faint amber
            {
                tint = {0.55f + 0.40f * heatColor, 0.60f + 0.35f * heatColor,
                        0.75f + 0.25f * heatColor, 2.0f};
            }
            const sw::f32 size =
                particle.size * (1.0f + 1.6f * (1.0f - lifeFraction));

            // Streak: a basis whose +Z is the elongation axis, scaled long.
            const sw::Vec3 z = particle.streakDirection;
            const sw::Vec3 reference =
                (std::abs(z.y) < 0.99f) ? sw::Vec3{0, 1, 0} : sw::Vec3{1, 0, 0};
            const sw::Vec3 x = glm::normalize(glm::cross(reference, z));
            const sw::Vec3 yAxis = glm::cross(z, x);
            const sw::Vec3 relative = sw::Vec3(particle.position - cameraPosition);
            const sw::Mat4 basis{sw::Vec4(x, 0.0f), sw::Vec4(yAxis, 0.0f),
                                 sw::Vec4(z, 0.0f), sw::Vec4(relative, 1.0f)};

            sw::DrawItem item{};
            item.mesh = &m_meshes[m_markerMeshIndex];
            item.transform =
                basis * glm::scale(sw::Mat4{1.0f},
                                   sw::Vec3{size, size, size * particle.stretch});
            item.boundsCenter = relative;
            item.boundsRadius = size * particle.stretch;
            item.tint = tint;
            m_drawItems.push_back(item);
        }
    }

    void StarWorksGame::updateTerrainPatch()
    {
        const bool wasVisible = m_terrainVisible;
        m_terrainVisible = false;
        const sw::i32 primaryIndex = controlledPrimaryIndex();
        if (primaryIndex < 0)
        {
            return;
        }
        const auto& primary =
            m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
        const auto* terrain =
            m_world.tryGetComponent<sw::planet::TerrainComponent>(primary.entity);
        const auto* bodyTransform =
            m_world.tryGetComponent<TransformComponent>(primary.entity);
        if (terrain == nullptr || bodyTransform == nullptr)
        {
            return;
        }
        const auto& craft = m_world.getComponent<TransformComponent>(controlledEntity());
        const sw::WorldVec3 radial = craft.position - bodyTransform->position;
        const sw::f64 distance = glm::length(radial);
        const sw::f64 seaAltitude = distance - primary.bodyRadius;
        if (distance <= 1.0 || seaAltitude > 3.0e5)
        {
            return; // terrain detail only matters below ~300 km
        }
        m_terrainVisible = true;

        // Patch center: the body-frame direction under the craft. Extent
        // scales with altitude — a wide, coarse patch from high up, a
        // tight, dense one near the ground. That scaling IS the LOD.
        const glm::dquat inverseRotation =
            glm::inverse(glm::dquat(bodyTransform->rotation));
        const sw::Vec3 centerDir =
            sw::Vec3(glm::normalize(inverseRotation * (radial / distance)));
        const sw::f64 extent =
            std::clamp(std::max(seaAltitude, 400.0) * 6.0, 4.0e3, 4.0e5);

        const sw::f64 now = clock().totalSeconds();
        const bool moved =
            static_cast<sw::f64>(glm::distance(centerDir, m_terrainCenterDir)) *
                primary.bodyRadius >
            extent * 0.30;
        const bool rescaled =
            extent > m_terrainExtent * 1.8 || extent < m_terrainExtent * 0.55;
        const bool needRebuild = m_terrainMeshSlot == 0xFFFFFFFFu ||
                                 m_terrainBody != primary.entity || moved || rescaled;
        if (!needRebuild || (wasVisible && now - m_lastTerrainRebuildSeconds < 1.0))
        {
            return; // keep showing the current patch
        }
        m_lastTerrainRebuildSeconds = now;
        m_terrainBody = primary.entity;
        m_terrainCenterDir = centerDir;
        m_terrainExtent = extent;

        // ---- build the grid: tangent plane projected onto the sphere ------
        constexpr sw::u32 kCells = 64;
        constexpr sw::u32 kVerts = kCells + 1;
        const sw::f64 radius = primary.bodyRadius;
        const sw::Vec3 reference =
            (std::abs(centerDir.y) < 0.99f) ? sw::Vec3{0, 1, 0} : sw::Vec3{1, 0, 0};
        const sw::Vec3 east = glm::normalize(glm::cross(reference, centerDir));
        const sw::Vec3 north = glm::cross(centerDir, east);
        m_terrainOriginLocal =
            sw::WorldVec3(centerDir) *
            (radius + sw::planet::terrainElevation(*terrain, centerDir));

        std::vector<sw::WorldVec3> points(kVerts * kVerts);
        std::vector<sw::f32> elevations(kVerts * kVerts);
        for (sw::u32 j = 0; j < kVerts; ++j)
        {
            for (sw::u32 i = 0; i < kVerts; ++i)
            {
                const sw::f64 u =
                    (static_cast<sw::f64>(i) / kCells * 2.0 - 1.0) * extent;
                const sw::f64 v =
                    (static_cast<sw::f64>(j) / kCells * 2.0 - 1.0) * extent;
                const sw::WorldVec3 raw = sw::WorldVec3(centerDir) * radius +
                                          sw::WorldVec3(east) * u +
                                          sw::WorldVec3(north) * v;
                const sw::WorldVec3 dir = glm::normalize(raw);
                const sw::f64 elevation =
                    sw::planet::terrainElevation(*terrain, sw::Vec3(dir));
                points[j * kVerts + i] =
                    dir * (radius + elevation) - m_terrainOriginLocal;
                elevations[j * kVerts + i] = static_cast<sw::f32>(elevation);
            }
        }

        sw::MeshData mesh;
        mesh.vertices.resize(kVerts * kVerts);
        const sw::f32 amplitude = terrain->amplitude;
        const bool hasOcean = terrain->seaLevelFraction > 0.0f;
        for (sw::u32 j = 0; j < kVerts; ++j)
        {
            for (sw::u32 i = 0; i < kVerts; ++i)
            {
                const sw::usize index = j * kVerts + i;
                sw::Vertex& vertex = mesh.vertices[index];
                vertex.position = sw::Vec3(points[index]);

                // Finite-difference normal (real slope shading).
                const sw::u32 iPrev = (i > 0) ? i - 1 : i;
                const sw::u32 iNext = (i < kCells) ? i + 1 : i;
                const sw::u32 jPrev = (j > 0) ? j - 1 : j;
                const sw::u32 jNext = (j < kCells) ? j + 1 : j;
                const sw::Vec3 dx =
                    sw::Vec3(points[j * kVerts + iNext] - points[j * kVerts + iPrev]);
                const sw::Vec3 dy =
                    sw::Vec3(points[jNext * kVerts + i] - points[jPrev * kVerts + i]);
                vertex.normal = glm::normalize(glm::cross(dx, dy));

                // Elevation palette (matches the globe's landscape).
                const sw::f32 elevation = elevations[index];
                const sw::f32 relief = elevation / amplitude;
                if (hasOcean && elevation <= 0.5f)
                {
                    vertex.color = {0.07f, 0.26f, 0.45f, 1.0f}; // coastal water
                }
                else if (hasOcean && elevation < 120.0f)
                {
                    vertex.color = {0.72f, 0.66f, 0.44f, 1.0f}; // beach sand
                }
                else if (relief < 0.35f)
                {
                    vertex.color = {0.18f, 0.36f, 0.14f, 1.0f}; // lowland
                }
                else if (relief < 0.7f)
                {
                    vertex.color = {0.43f, 0.35f, 0.21f, 1.0f}; // highland
                }
                else
                {
                    vertex.color = {0.55f, 0.53f, 0.50f, 1.0f}; // rock
                }
                if (!hasOcean) // airless worlds: neutral regolith ramp
                {
                    const sw::f32 g = 0.28f + 0.30f * relief;
                    vertex.color = {g, g * 0.97f, g * 0.92f, 1.0f};
                }
            }
        }
        mesh.indices.reserve(kCells * kCells * 6);
        for (sw::u32 j = 0; j < kCells; ++j)
        {
            for (sw::u32 i = 0; i < kCells; ++i)
            {
                const sw::u32 a = j * kVerts + i;
                const sw::u32 b = a + 1;
                const sw::u32 c = a + kVerts;
                const sw::u32 d = c + 1;
                // CCW seen from OUTSIDE the planet (+up): front faces out.
                mesh.indices.insert(mesh.indices.end(), {a, b, c, b, d, c});
            }
        }

        // Replace the GPU mesh in place (idle first: 2 frames may still
        // reference the old buffers; a rare, bounded hitch).
        renderer().waitIdle();
        if (m_terrainMeshSlot == 0xFFFFFFFFu)
        {
            m_terrainMeshSlot = registerMesh(renderer().createMesh(mesh));
        }
        else
        {
            m_meshes[m_terrainMeshSlot] = renderer().createMesh(mesh);
        }
    }

    sw::i32 StarWorksGame::controlledPrimaryIndex() const
    {
        if (m_celestialIndex.size() == 0)
        {
            return -1;
        }
        const auto& transform = const_cast<sw::ecs::World&>(m_world)
                                    .getComponent<TransformComponent>(controlledEntity());
        return m_celestialIndex.soiPrimaryAt(transform.position,
                                             m_physicsLane->presentSeconds());
    }

    void StarWorksGame::updateManeuverNodeInput()
    {
        // Map view only: no conflict with flight keys (Shift/Ctrl throttle).
        if (input().wasKeyPressed(sw::KeyCode::N))
        {
            m_nodeActive = !m_nodeActive;
            if (m_nodeActive)
            {
                m_nodeTime = m_physicsLane->presentSeconds() + 120.0;
                m_nodePrograde = 0.0;
                m_nodeNormal = 0.0;
                m_nodeRadial = 0.0;
            }
            m_lastPredictionSeconds = -1.0e9; // recompute now
            SW_LOG_INFO("Game", "Maneuver node {}", m_nodeActive ? "created" : "deleted");
        }
        if (!m_nodeActive)
        {
            return;
        }

        sw::f64 step = 1.0;
        if (input().isKeyDown(sw::KeyCode::LeftShift)) { step *= 10.0; }
        if (input().isKeyDown(sw::KeyCode::LeftControl)) { step *= 0.1; }

        bool edited = false;
        auto adjust = [&](sw::KeyCode plus, sw::KeyCode minus, sw::f64& value,
                          sw::f64 scale) {
            if (input().wasKeyPressed(plus)) { value += step * scale; edited = true; }
            if (input().wasKeyPressed(minus)) { value -= step * scale; edited = true; }
        };
        adjust(sw::KeyCode::L, sw::KeyCode::J, m_nodeTime, 10.0);  // 10 s per tap
        adjust(sw::KeyCode::I, sw::KeyCode::K, m_nodePrograde, 1.0);
        adjust(sw::KeyCode::O, sw::KeyCode::U, m_nodeNormal, 1.0);
        adjust(sw::KeyCode::Y, sw::KeyCode::H, m_nodeRadial, 1.0);
        m_nodeTime = std::max(m_nodeTime, m_physicsLane->presentSeconds() + 5.0);
        if (edited)
        {
            m_lastPredictionSeconds = -1.0e9; // instant visual feedback
        }
    }

    void StarWorksGame::refreshPrediction()
    {
        // The flight plan is a pure function of current state — recomputing
        // a few times per second is plenty (and each run costs ~ms).
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastPredictionSeconds < kPredictionRefreshSeconds)
        {
            return;
        }
        m_lastPredictionSeconds = now;

        const sw::ecs::Entity entity = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(entity);

        // Resting on a surface: no meaningful ballistic trajectory — and
        // the conic of a landed craft "impacts" permanently, which is
        // noise, not information.
        if (const auto* body =
                m_world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity);
            body != nullptr && body->isGrounded != 0)
        {
            m_prediction.clear();
            m_nodePrediction.clear();
            return;
        }

        const sw::f64 startTime = m_physicsLane->presentSeconds();
        sw::space::PredictionSettings settings{};
        if (m_nodeActive)
        {
            // Pre-burn plan stops AT the node; the node plan takes over.
            settings.horizonSeconds = std::max(m_nodeTime - startTime, 1.0);
        }
        sw::space::predictTrajectory(m_celestialIndex, transform.position,
                                     controlledVelocity(), startTime, settings,
                                     m_prediction);

        // ---- the planned burn: dv applied in the orbital frame at the node ----
        m_nodePrediction.clear();
        m_nodePrimaryIndex = -1;
        if (!m_nodeActive)
        {
            return;
        }
        sw::WorldVec3 nodePosition{};
        sw::WorldVec3 nodeVelocity{};
        if (!sw::space::stateOnPrediction(m_celestialIndex, m_prediction, m_nodeTime,
                                          nodePosition, nodeVelocity))
        {
            return;
        }
        const sw::i32 nodePrimary =
            m_celestialIndex.soiPrimaryAt(nodePosition, m_nodeTime);
        if (nodePrimary < 0)
        {
            return;
        }
        sw::WorldVec3 primaryPosition{};
        sw::WorldVec3 primaryVelocity{};
        m_celestialIndex.stateAt(nodePrimary, m_nodeTime, primaryPosition,
                                 &primaryVelocity);
        const sw::WorldVec3 relativePosition = nodePosition - primaryPosition;
        const sw::WorldVec3 relativeVelocity = nodeVelocity - primaryVelocity;
        const sw::f64 relativeSpeed = glm::length(relativeVelocity);
        if (relativeSpeed < 1.0e-6)
        {
            return;
        }

        // KSP orbital frame at the node: prograde along the motion, normal
        // along the orbit's angular momentum, radial completing (outward).
        const sw::WorldVec3 prograde = relativeVelocity / relativeSpeed;
        sw::WorldVec3 normal = glm::cross(relativePosition, relativeVelocity);
        const sw::f64 normalLength = glm::length(normal);
        if (normalLength < 1.0e-9)
        {
            return; // radial trajectory: no orbital frame
        }
        normal /= normalLength;
        const sw::WorldVec3 radialOut = glm::cross(prograde, normal);

        const sw::WorldVec3 dv = prograde * m_nodePrograde + normal * m_nodeNormal +
                                 radialOut * m_nodeRadial;
        m_nodePostBurnVelocity = nodeVelocity + dv;
        m_nodePrimaryIndex = nodePrimary;
        m_nodeRelativePosition = relativePosition;

        sw::space::PredictionSettings nodeSettings{}; // full horizon again
        sw::space::predictTrajectory(m_celestialIndex, nodePosition,
                                     m_nodePostBurnVelocity, m_nodeTime, nodeSettings,
                                     m_nodePrediction);
    }

    void StarWorksGame::toggleEva()
    {
        if (!m_evaMode && m_capsuleEntity.isNull())
        {
            // First EVA: spawn the capsule beside the ship, co-moving.
            const auto& shipTransform =
                m_world.getComponent<TransformComponent>(m_shipEntity);
            const sw::WorldVec3 shipVelocity = controlledVelocity();

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = shipTransform.position +
                                 sw::WorldVec3(shipTransform.rotation *
                                               sw::Vec3{12.0f, 0.0f, 0.0f});
            m_world.addComponent(
                e, PreviousTransformComponent{transform.position, transform.rotation});
            m_world.addComponent(e, transform);
            m_world.addComponent(e, BoundsComponent{1.2f});
            m_world.addComponent(e, MeshComponent{m_capsuleMeshIndex});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.8f, 0.2f, 1.0f}});
            m_world.addComponent(e, CapsuleComponent{});
            m_world.addComponent(e, ShipControlsComponent{});
            sw::phys::DynamicBodyComponent body{};
            body.velocity = shipVelocity;
            body.mass = 120.0;
            body.ballisticFactor = 0.01; // draggier than the ship
            m_world.addComponent(e, body);
            m_capsuleEntity = e;
        }
        m_evaMode = !m_evaMode;
        SW_LOG_INFO("Game", "{}", m_evaMode ? "EVA: controlling capsule"
                                            : "Back aboard: controlling ship");
    }

    void StarWorksGame::updateWarp()
    {
        if (input().wasKeyPressed(sw::KeyCode::Period) && m_warpIndex + 1 < kWarpSteps)
        {
            ++m_warpIndex;
        }
        if (input().wasKeyPressed(sw::KeyCode::Comma) && m_warpIndex > 0)
        {
            --m_warpIndex;
        }

        const sw::WorldVec3 focusPosition =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;
        sw::f64 minAltitude = 1.0e18;
        m_world.forEach<TransformComponent, sw::phys::GravitySourceComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                sw::phys::GravitySourceComponent& source) {
                const sw::f64 altitude =
                    glm::length(focusPosition - transform.position) - source.bodyRadius;
                minAltitude = std::min(minAltitude, altitude);
            });

        const sw::f32 maxAllowed = maxWarpForAltitude(minAltitude);
        while (m_warpIndex > 0 && kWarpLadder[m_warpIndex] > maxAllowed)
        {
            --m_warpIndex;
            SW_LOG_INFO("Game", "Warp limited to x{:g} (altitude {:.0f} km)",
                        kWarpLadder[m_warpIndex], minAltitude / 1000.0);
        }

        m_simulation.setTimeScale(kWarpLadder[m_warpIndex]);
        // Physics warp (<= x5): everything stays truly simulated. Rails
        // warp (> x5): analytic orbits only, exact at any speed.
        m_bubbleSystem->setForceRails(kWarpLadder[m_warpIndex] > kMaxPhysicsWarp);
    }

    void StarWorksGame::updateShipControls()
    {
        // Idle both control blocks, then feed the controlled one.
        auto& shipControls = m_world.getComponent<ShipControlsComponent>(m_shipEntity);
        shipControls = {};
        ShipControlsComponent* capsuleControls = nullptr;
        if (!m_capsuleEntity.isNull())
        {
            capsuleControls =
                m_world.tryGetComponent<ShipControlsComponent>(m_capsuleEntity);
            if (capsuleControls != nullptr)
            {
                *capsuleControls = {};
            }
        }

        if (!m_shipMode || m_mapView || m_editorMode ||
            kWarpLadder[m_warpIndex] > kMaxPhysicsWarp)
        {
            return; // engines only work while the world is truly simulated
        }

        ShipControlsComponent& controls =
            (m_evaMode && capsuleControls != nullptr) ? *capsuleControls : shipControls;

        if (input().isKeyDown(sw::KeyCode::W)) { controls.thrustAxis += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::S)) { controls.thrustAxis -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Up)) { controls.rotationInput.x -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Down)) { controls.rotationInput.x += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::A)) { controls.rotationInput.y += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::D)) { controls.rotationInput.y -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Q)) { controls.rotationInput.z += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::E)) { controls.rotationInput.z -= 1.0f; }
        controls.killRotation = input().isKeyDown(sw::KeyCode::X) ? 1u : 0u;
        // Throttle limiter (ship only; the capsule ignores it).
        if (input().isKeyDown(sw::KeyCode::LeftShift)) { controls.throttleDelta += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::LeftControl))
        {
            controls.throttleDelta -= 1.0f;
        }
    }

    void StarWorksGame::updateChaseCamera(sw::f32 deltaSeconds)
    {
        const sw::ecs::Entity target = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(target);
        const auto& previous = m_world.getComponent<PreviousTransformComponent>(target);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::WorldVec3 position =
            glm::mix(previous.position, transform.position, static_cast<sw::f64>(alpha));
        const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);

        // ---- ground lock: when the trajectory is no longer an orbit ----------
        // (impact predicted, or resting on the surface) AND the craft is low
        // relative to the BODY'S OWN SIZE, the camera stops tumbling with
        // the craft and levels itself on the local horizon instead.
        bool wantGroundLock = false;
        sw::Vec3 radialUp{0.0f, 1.0f, 0.0f};
        const sw::i32 primaryIndex = controlledPrimaryIndex();
        if (primaryIndex >= 0)
        {
            const auto& primary =
                m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
            const sw::WorldVec3 primaryPosition = m_celestialIndex.positionAt(
                primaryIndex, m_physicsLane->presentSeconds());
            const sw::WorldVec3 radial = position - primaryPosition;
            const sw::f64 distance = glm::length(radial);
            if (distance > 1.0)
            {
                radialUp = sw::Vec3(radial / distance);
                const sw::f64 altitude = distance - primary.bodyRadius;
                const bool low = altitude < 0.03 * primary.bodyRadius;

                bool suborbital = false;
                if (!m_prediction.empty())
                {
                    suborbital = m_prediction[0].endReason ==
                                 sw::space::SegmentEnd::Impact;
                }
                const auto* dynamicBody =
                    m_world.tryGetComponent<sw::phys::DynamicBodyComponent>(target);
                const bool grounded =
                    dynamicBody != nullptr && dynamicBody->isGrounded != 0;
                wantGroundLock = low && (suborbital || grounded);
            }
        }
        const sw::f32 blendTarget = wantGroundLock ? 1.0f : 0.0f;
        m_groundCamBlend +=
            (blendTarget - m_groundCamBlend) * std::min(1.0f, deltaSeconds * 2.0f);
        const sw::f32 blend = m_groundCamBlend;

        // Offset frame: the craft's own rotation, blended toward a leveled
        // "ground frame" (craft heading projected on the horizon plane).
        sw::Quat offsetRotation = rotation;
        if (blend > 0.001f)
        {
            const sw::Vec3 forwardShip = rotation * sw::math::kWorldForward;
            sw::Vec3 horizontal =
                forwardShip - radialUp * glm::dot(forwardShip, radialUp);
            const sw::f32 horizontalLength = glm::length(horizontal);
            if (horizontalLength > 1.0e-3f)
            {
                horizontal /= horizontalLength;
                const sw::Vec3 right =
                    glm::normalize(glm::cross(horizontal, radialUp));
                const sw::Quat groundRotation =
                    glm::quat_cast(sw::Mat3{right, radialUp, -horizontal});
                offsetRotation = glm::slerp(rotation, groundRotation, blend);
            }
        }

        // ---- user camera control: right-drag orbits, wheel zooms, C resets ----
        if (input().isMouseButtonDown(sw::MouseButton::Right))
        {
            m_chaseYaw -= input().mouseDeltaX() * 0.0045f;
            m_chasePitch =
                std::clamp(m_chasePitch - input().mouseDeltaY() * 0.0045f, -1.35f, 1.35f);
        }
        if (const sw::f32 scroll = input().scrollDeltaY(); scroll != 0.0f)
        {
            m_chaseZoom = std::clamp(
                m_chaseZoom * std::pow(1.18f, -scroll), 0.35f, 12.0f);
        }
        if (input().wasKeyPressed(sw::KeyCode::C))
        {
            m_chaseYaw = 0.0f;
            m_chasePitch = 0.0f;
            m_chaseZoom = 1.0f;
        }
        const sw::Quat userOrbit =
            glm::angleAxis(m_chaseYaw, sw::Vec3{0.0f, 1.0f, 0.0f}) *
            glm::angleAxis(m_chasePitch, sw::Vec3{1.0f, 0.0f, 0.0f});

        const sw::Vec3 chaseOffset =
            (m_evaMode ? sw::Vec3{0.0f, 2.0f, 9.0f} : sw::Vec3{0.0f, 12.0f, 42.0f}) *
            m_chaseZoom;
        const sw::WorldVec3 cameraPosition =
            position + sw::WorldVec3(offsetRotation * (userOrbit * chaseOffset));
        m_camera.setPosition(cameraPosition);

        const sw::Vec3 forward = glm::normalize(sw::Vec3(position - cameraPosition));
        // Camera up: craft-up in orbit, local vertical near the ground.
        const sw::Vec3 shipUp = rotation * sw::Vec3{0.0f, 1.0f, 0.0f};
        const sw::Vec3 targetUp = glm::normalize(glm::mix(shipUp, radialUp, blend));
        const sw::Vec3 right = glm::normalize(glm::cross(forward, targetUp));
        const sw::Vec3 up = glm::cross(right, forward);
        m_camera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        // --- mode toggles -------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::M))
        {
            m_mapView = !m_mapView;
            SW_LOG_INFO("Game", "Star map {}", m_mapView ? "opened" : "closed");
        }
        if (input().wasKeyPressed(sw::KeyCode::G) && !m_mapView)
        {
            toggleEva();
        }
        if (input().wasKeyPressed(sw::KeyCode::V))
        {
            m_speedSurfaceRelative = !m_speedSurfaceRelative;
        }
        if (input().wasKeyPressed(sw::KeyCode::Tab))
        {
            m_shipMode = !m_shipMode;
            if (!m_shipMode)
            {
                const sw::Vec3 forward = m_camera.forward();
                const sw::f32 yaw = std::atan2(-forward.x, -forward.z);
                const sw::f32 pitch = std::asin(std::clamp(forward.y, -1.0f, 1.0f));
                m_cameraController.setPose(m_camera.position(), yaw, pitch);
            }
            SW_LOG_INFO("Game", "{}", m_shipMode ? "Chase camera" : "Free camera");
        }
        if (input().wasKeyPressed(sw::KeyCode::Space))
        {
            m_simulation.setPaused(!m_simulation.isPaused());
            SW_LOG_INFO("Game", "Simulation {}", m_simulation.isPaused() ? "paused" : "resumed");
        }
        if (m_mapView)
        {
            updateManeuverNodeInput();
        }

        // ---- vessel editor (B) + staging (Z) -----------------------------------
        if (input().wasKeyPressed(sw::KeyCode::B) && !m_mapView && !m_evaMode)
        {
            if (m_editorMode) { exitEditor(); }
            else { enterEditor(); }
        }
        if (m_editorMode)
        {
            updateEditor();
        }
        if (input().wasKeyPressed(sw::KeyCode::Z) && !m_editorMode && !m_mapView)
        {
            // Staging: fire the first decoupler on the ship (nose-most last).
            sw::ecs::Entity decoupler{};
            m_world.forEach<sw::parts::PartComponent>(
                [&](sw::ecs::Entity entity, sw::parts::PartComponent& part) {
                    if (part.vessel != m_shipEntity || !decoupler.isNull())
                    {
                        return;
                    }
                    const auto* definition =
                        sw::parts::findDefinition(part.definitionId);
                    if (definition != nullptr &&
                        definition->type == sw::parts::PartType::Decoupler)
                    {
                        decoupler = entity;
                    }
                });
            if (!decoupler.isNull())
            {
                const sw::ecs::Entity separated =
                    sw::parts::decoupleAt(m_world, decoupler);
                if (!separated.isNull())
                {
                    // splitVessel already gave it Transform/Previous/body.
                    m_world.addComponent(separated, BoundsComponent{0.1f});
                    m_world.addComponent(
                        separated, MapMarkerComponent{{0.6f, 0.6f, 0.6f, 1.0f}});
                    SW_LOG_INFO("Game", "STAGING: decoupler fired, stage separated");
                }
            }
        }

        // ---- docking: ports of different vessels, close and slow ---------------
        if (!m_editorMode && clock().totalSeconds() - m_lastDockCheckSeconds > 0.5)
        {
            m_lastDockCheckSeconds = clock().totalSeconds();
            struct Port { sw::ecs::Entity part; sw::ecs::Entity vessel; sw::WorldVec3 pos; };
            std::vector<Port> ports;
            m_world.forEach<sw::parts::PartComponent, TransformComponent>(
                [&](sw::ecs::Entity entity, sw::parts::PartComponent& part,
                    TransformComponent& transform) {
                    const auto* definition =
                        sw::parts::findDefinition(part.definitionId);
                    if (definition != nullptr &&
                        definition->type == sw::parts::PartType::DockingPort)
                    {
                        ports.push_back({entity, part.vessel, transform.position});
                    }
                });
            for (sw::usize a = 0; a < ports.size(); ++a)
            {
                for (sw::usize b = a + 1; b < ports.size(); ++b)
                {
                    if (ports[a].vessel == ports[b].vessel ||
                        glm::length(ports[a].pos - ports[b].pos) > 4.0)
                    {
                        continue;
                    }
                    // The player's vessel absorbs the other one.
                    const bool shipIsA = ports[a].vessel == m_shipEntity;
                    if (sw::parts::dockVessels(m_world,
                                               shipIsA ? ports[a].part : ports[b].part,
                                               shipIsA ? ports[b].part : ports[a].part))
                    {
                        SW_LOG_INFO("Game", "DOCKING: vessels merged");
                    }
                }
            }
        }

        // ---- SAS: T cycles OFF -> PGD -> RTG; clickable buttons too -----------
        if (input().wasKeyPressed(sw::KeyCode::T))
        {
            m_sasMode = (m_sasMode + 1) % 3;
        }
        if (input().wasKeyPressed(sw::KeyCode::P) && !m_editorMode)
        {
            cyclePilotedVessel(); // fly any built vessel
        }
        handleHudClicks();
        if (auto* sas = m_world.tryGetComponent<SasComponent>(m_shipEntity))
        {
            sas->mode = m_sasMode;
        }

        // --- save / load ----------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::F5))
        {
            try
            {
                saveGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Save failed: {}", e.message());
            }
        }
        if (input().wasKeyPressed(sw::KeyCode::F9))
        {
            try
            {
                loadGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Load failed: {}", e.message());
            }
        }

        updateWarp();

        // --- per-mode camera & controls ------------------------------------------
        if (m_mapView)
        {
            const sw::f32 scroll = input().scrollDeltaY();
            if (scroll != 0.0f)
            {
                m_mapHeightMeters = std::clamp(
                    m_mapHeightMeters * std::pow(1.3, static_cast<sw::f64>(-scroll)),
                    kMapMinHeight, kMapMaxHeight);
            }
            // Right-drag orbits the map camera around the focus (yaw +
            // tilt); default stays near top-down.
            if (input().isMouseButtonDown(sw::MouseButton::Right))
            {
                m_mapYaw -= input().mouseDeltaX() * 0.005f;
                m_mapPitch = std::clamp(m_mapPitch - input().mouseDeltaY() * 0.005f,
                                        0.12f, 1.53f);
            }

            // KSP-style framing: the map centers on the SOI primary of the
            // controlled craft — Terra view at LEO, Sol view once you leave
            // Terra's sphere of influence.
            sw::WorldVec3 mapCenter{0.0};
            if (const sw::i32 primaryIndex = controlledPrimaryIndex(); primaryIndex >= 0)
            {
                mapCenter = m_celestialIndex.positionAt(primaryIndex,
                                                        m_physicsLane->presentSeconds());
            }
            const sw::f64 cosPitch = std::cos(m_mapPitch);
            const sw::WorldVec3 offsetDir{cosPitch * std::sin(m_mapYaw),
                                          std::sin(m_mapPitch),
                                          cosPitch * std::cos(m_mapYaw)};
            const sw::WorldVec3 cameraPos = mapCenter + offsetDir * m_mapHeightMeters;
            m_mapCamera.setPosition(cameraPos);
            const sw::Vec3 forward = glm::normalize(sw::Vec3(mapCenter - cameraPos));
            const sw::Vec3 right =
                glm::normalize(glm::cross(forward, sw::Vec3{0, 1, 0}));
            const sw::Vec3 up = glm::cross(right, forward);
            m_mapCamera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
            m_mapCamera.setAspectRatio(renderer().aspectRatio());
        }
        else if (!m_shipMode)
        {
            m_cameraController.update(input(), window(), deltaSeconds);
        }
        m_camera.setAspectRatio(renderer().aspectRatio());

        updateShipControls();

        m_bubbleSystem->setFocus(
            m_world.getComponent<TransformComponent>(controlledEntity()).position);

        m_simulation.advance(m_world, deltaSeconds, &threadPool());
        m_commands.playback(m_world);

        // Fresh hierarchy snapshot for the map, HUD and flight plan.
        m_celestialIndex.rebuild(m_world);
        refreshPrediction();
        updateTerrainPatch();

        updateReentryEffects(deltaSeconds);

        if (m_shipMode && !m_mapView)
        {
            updateChaseCamera(deltaSeconds);
        }

        // --- periodic statistics ------------------------------------------------
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastStatsLogSeconds > 5.0)
        {
            m_lastStatsLogSeconds = now;
            const sw::RenderStats& stats = renderer().stats();
            SW_LOG_INFO("Game",
                        "render: {} submitted, {} culled, {} instances in {} draw calls | "
                        "sim: {} dynamic / {} rails, warp x{:g} ({:.0f} FPS, prepare "
                        "{:.1f} ms)",
                        stats.itemsSubmitted, stats.itemsCulled, stats.instancesDrawn,
                        stats.drawCalls, m_world.count<sw::phys::DynamicBodyComponent>(),
                        m_world.count<sw::phys::OnRailsComponent>(),
                        kWarpLadder[m_warpIndex], clock().smoothedFps(),
                        stats.cpuPrepareMs);
        }
    }

    sw::u32 StarWorksGame::selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const
    {
        const sw::f64 clampedDistance = std::max(distance, worldRadius * 1.0001);
        const sw::f64 angularDiameter = 2.0 * std::atan(worldRadius / clampedDistance);
        const sw::f32 fraction =
            static_cast<sw::f32>(angularDiameter) / m_camera.verticalFov();

        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels - 1; ++level)
        {
            if (fraction >= kLodScreenFractions[level])
            {
                return level;
            }
        }
        return CelestialLodComponent::kLodLevels - 1;
    }

    void StarWorksGame::hudText(std::string_view text, sw::f32 x, sw::f32 y,
                                sw::f32 heightNdc, const sw::Vec4& color)
    {
        const sw::f32 aspect = renderer().aspectRatio();
        const sw::f32 scaleX = (5.0f / 7.0f) * heightNdc / aspect;
        const sw::f32 advance = sw::ui::kGlyphAdvance * heightNdc / aspect;

        sw::f32 penX = x;
        for (const char character : text)
        {
            const auto index = static_cast<sw::usize>(
                static_cast<unsigned char>(std::toupper(character)));
            const sw::u32 meshIndex =
                (index < m_glyphMeshIndex.size()) ? m_glyphMeshIndex[index] : 0xFFFFFFFFu;
            if (meshIndex != 0xFFFFFFFFu)
            {
                sw::DrawItem item{};
                item.mesh = &m_meshes[meshIndex];
                item.transform = glm::translate(sw::Mat4{1.0f}, {penX, y, 0.0f}) *
                                 glm::scale(sw::Mat4{1.0f}, {scaleX, heightNdc, 1.0f});
                item.screenSpace = true;
                item.tint = color;
                m_drawItems.push_back(item);
            }
            penX += advance;
        }
    }

    void StarWorksGame::collectHud()
    {
        constexpr sw::f32 kLine = 0.052f;
        constexpr sw::f32 kX = -0.98f;
        sw::f32 y = -0.97f;
        const sw::Vec4 main{0.65f, 0.95f, 0.75f, 0.95f};
        const sw::Vec4 dim{0.55f, 0.75f, 0.85f, 0.9f};

        // ---- mode ----------------------------------------------------------------
        const char* mode = m_mapView ? "MAP" : (m_evaMode ? "EVA" : "NAV");
        hudText(std::format("{} {}", mode, m_shipMode || m_mapView ? "" : "CAM LIBRE"), kX,
                y, kLine, main);
        y += kLine * 1.3f;

        // ---- speed & altitude, relative to the current SOI PRIMARY ---------------
        const sw::WorldVec3 velocity = controlledVelocity();
        const sw::WorldVec3 position =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;

        const sw::f64 time = m_physicsLane->presentSeconds();
        const sw::i32 primaryIndex = controlledPrimaryIndex();
        const char* primaryName = "-";
        sw::WorldVec3 primaryPosition{0.0};
        sw::WorldVec3 primaryVelocity{0.0};
        sw::WorldVec3 primaryAngularVelocity{0.0};
        sw::f64 primaryRadius = 0.0;
        if (primaryIndex >= 0)
        {
            const auto& primary = m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
            primaryName = primary.name;
            primaryRadius = primary.bodyRadius;
            m_celestialIndex.stateAt(primaryIndex, time, primaryPosition,
                                     &primaryVelocity);
            if (const auto* source =
                    m_world.tryGetComponent<sw::phys::GravitySourceComponent>(
                        primary.entity))
            {
                primaryAngularVelocity = source->angularVelocity;
            }
        }

        sw::f64 speed = 0.0;
        if (m_speedSurfaceRelative)
        {
            // Surface velocity: the primary's own motion + its spin at this
            // position — works above any body, not just Terra.
            const sw::WorldVec3 surfaceVelocity =
                primaryVelocity +
                glm::cross(primaryAngularVelocity, position - primaryPosition);
            speed = glm::length(velocity - surfaceVelocity);
        }
        else
        {
            speed = glm::length(velocity - primaryVelocity); // orbital speed
        }
        hudText(std::format("SPD {} {:.1f} M/S", m_speedSurfaceRelative ? "SRF" : "ORB",
                            speed),
                kX, y, kLine, main);
        y += kLine * 1.3f;

        // ---- altitude above the primary -------------------------------------------
        const sw::f64 altitude =
            glm::length(position - primaryPosition) - primaryRadius;
        hudText(std::format("ALT {} {:.1f} KM", primaryName, altitude / 1000.0), kX, y,
                kLine, main);
        y += kLine * 1.3f;

        // ---- current orbit around the primary: APO / PER / period ----------------
        auto formatEta = [](sw::f64 seconds) {
            return (seconds >= 3600.0) ? std::format("{:.1f} H", seconds / 3600.0)
                                       : std::format("{:.0f} S", seconds);
        };
        const auto* controlledBody =
            m_world.tryGetComponent<sw::phys::DynamicBodyComponent>(controlledEntity());
        const bool grounded = controlledBody != nullptr && controlledBody->isGrounded != 0;
        sw::phys::KeplerOrbit currentOrbit{};
        if (primaryIndex >= 0 && !grounded &&
            sw::phys::kepler::fromStateVectors(
                m_celestialIndex.body(static_cast<sw::usize>(primaryIndex)).mu,
                position - primaryPosition, velocity - primaryVelocity, time,
                currentOrbit, /*allowHyperbolic=*/true))
        {
            constexpr sw::f64 kTwoPi = 6.283185307179586;
            const sw::f64 periapsisAltitude =
                sw::phys::kepler::periapsis(currentOrbit) - primaryRadius;
            if (!currentOrbit.isHyperbolic())
            {
                const sw::f64 meanAnomaly = currentOrbit.meanAnomalyAtEpoch;
                const sw::f64 timeToPeriapsis =
                    (kTwoPi - meanAnomaly) / currentOrbit.meanMotion;
                const sw::f64 timeToApoapsis =
                    std::fmod(3.0 * 3.14159265358979 - meanAnomaly, kTwoPi) /
                    currentOrbit.meanMotion;
                const sw::f64 apoapsisAltitude =
                    sw::phys::kepler::apoapsis(currentOrbit) - primaryRadius;
                hudText(std::format("APO {:.1f} KM T-{}", apoapsisAltitude / 1000.0,
                                    formatEta(timeToApoapsis)),
                        kX, y, kLine, dim);
                y += kLine * 1.3f;
                hudText(std::format("PER {:.1f} KM T-{}", periapsisAltitude / 1000.0,
                                    formatEta(timeToPeriapsis)),
                        kX, y, kLine, dim);
                y += kLine * 1.3f;
                hudText(std::format("ORB {}", formatEta(sw::phys::kepler::period(
                                        currentOrbit))),
                        kX, y, kLine, dim);
                y += kLine * 1.3f;
            }
            else // escape trajectory: periapsis (if ahead), no apoapsis
            {
                const sw::f64 meanAnomaly = currentOrbit.meanAnomalyAtEpoch;
                if (meanAnomaly < 0.0) // still inbound toward periapsis
                {
                    hudText(std::format("PER {:.1f} KM T-{}  ESC",
                                        periapsisAltitude / 1000.0,
                                        formatEta(-meanAnomaly /
                                                  currentOrbit.meanMotion)),
                            kX, y, kLine, dim);
                }
                else
                {
                    hudText("ESCAPE TRAJECTORY", kX, y, kLine, dim);
                }
                y += kLine * 1.3f;
            }
        }

        // ---- throttle + warp -----------------------------------------------------------
        const auto& ship = m_world.getComponent<ShipComponent>(m_shipEntity);
        hudText(std::format("THR {:.0f}%  WARP X{:g}", ship.throttle * 100.0f,
                            kWarpLadder[m_warpIndex]),
                kX, y, kLine, dim);
        y += kLine * 1.3f;

        // ---- vessel resources (parts carry them as real cargo) -----------------
        sw::f64 fuelUnits = 0.0;
        sw::f64 chargeUnits = 0.0;
        m_world.forEach<sw::parts::PartComponent, sw::factory::InventoryComponent>(
            [&](sw::ecs::Entity, sw::parts::PartComponent& part,
                sw::factory::InventoryComponent& inventory) {
                if (part.vessel != m_shipEntity)
                {
                    return;
                }
                fuelUnits +=
                    sw::factory::inventoryCount(inventory, sw::res::Resource::Fuel);
                chargeUnits += sw::factory::inventoryCount(
                    inventory, sw::res::Resource::ElectricCharge);
            });
        const sw::Vec4 fuelColor = (fuelUnits > 3000.0)
                                       ? dim
                                       : sw::Vec4{1.0f, 0.45f, 0.3f, 0.95f};
        hudText(std::format("FUEL {:.0f} KG  ELEC {:.0f} KJ", fuelUnits, chargeUnits),
                kX, y, kLine, fuelColor);
        y += kLine * 1.3f;

        // ---- flight-plan events (KSP style): the first upcoming transition --------
        for (const sw::space::TrajectorySegment& segment : m_prediction)
        {
            const char* label = nullptr;
            sw::Vec4 color = dim;
            switch (segment.endReason)
            {
            case sw::space::SegmentEnd::Encounter:
                label = "ENC";
                color = {0.4f, 1.0f, 0.9f, 0.95f};
                break;
            case sw::space::SegmentEnd::Impact:
                label = "IMPACT";
                color = {1.0f, 0.35f, 0.3f, 0.95f};
                break;
            case sw::space::SegmentEnd::SoiExit:
                label = "EXIT TO";
                color = {1.0f, 0.85f, 0.4f, 0.95f};
                break;
            default:
                break;
            }
            if (label == nullptr || segment.eventBodyIndex < 0)
            {
                continue;
            }
            const auto& eventBody =
                m_celestialIndex.body(static_cast<sw::usize>(segment.eventBodyIndex));
            const sw::f64 eta = segment.endTime - time;
            hudText(std::format("{} {} T-{:.0f} S", label, eventBody.name,
                                std::max(eta, 0.0)),
                    kX, y, kLine, color);
            y += kLine * 1.3f;
        }

        // ---- maneuver node status --------------------------------------------
        if (m_nodeActive)
        {
            // Far from the node: show the PLANNED dv. Within 30 s (or past
            // it): the LIVE remaining vector — burn until it hits zero.
            const sw::f64 timeToNode = m_nodeTime - time;
            const sw::f64 plannedDv =
                std::sqrt(m_nodePrograde * m_nodePrograde +
                          m_nodeNormal * m_nodeNormal + m_nodeRadial * m_nodeRadial);
            const sw::f64 remainingDv =
                glm::length(m_nodePostBurnVelocity - controlledVelocity());
            const bool burnWindow = timeToNode < 30.0;
            const sw::Vec4 nodeColor{0.8f, 0.55f, 1.0f, 0.95f};
            hudText(std::format("NODE T-{} DV {:.1f} M/S{}",
                                formatEta(std::max(timeToNode, 0.0)),
                                burnWindow ? remainingDv : plannedDv,
                                burnWindow ? " BURN" : ""),
                    kX, y, kLine, nodeColor);
            y += kLine * 1.3f;
            if (m_mapView)
            {
                hudText(std::format("PGD {:+.1f} NRM {:+.1f} RAD {:+.1f}",
                                    m_nodePrograde, m_nodeNormal, m_nodeRadial),
                        kX, y, kLine, nodeColor);
                y += kLine * 1.3f;
            }
        }

        if (!m_mapView && !m_editorMode)
        {
            collectNavball();
            collectSasButtons();
        }
        // (Hangar UI is not collected here: the hangar renders through its
        // own path — collectHangarItems -> collectEditorUi.)
    }

    // ========================= THE HANGAR (B) ==============================
    void StarWorksGame::enterEditor()
    {
        m_editorMode = true;
        m_pausedBeforeEditor = m_simulation.isPaused();
        m_simulation.setPaused(true);
        m_editorPointIndex = 0;
        // Open on the CURRENT ship, loaded as an editable blueprint.
        m_hangarSource = {};
        m_blueprint.clear();
        hangarLoadNextVessel();
        if (m_blueprint.empty())
        {
            hangarNewBlueprint();
        }
        SW_LOG_INFO("Game", "HANGAR: open");
    }

    void StarWorksGame::exitEditor()
    {
        m_editorMode = false;
        m_simulation.setPaused(m_pausedBeforeEditor);
        SW_LOG_INFO("Game", "HANGAR: closed");
    }

    void StarWorksGame::hangarNewBlueprint()
    {
        m_blueprint.clear();
        m_hangarSource = {};
        BlueprintPart core{};
        core.definitionId = sw::parts::kPartCoreStructural;
        m_blueprint.push_back(core); // every design starts from a command core
        m_editorPointIndex = 0;
    }

    void StarWorksGame::hangarLoadNextVessel()
    {
        // Cycle through the world's part-built vessels, loading each into
        // the blueprint for modification.
        std::vector<sw::ecs::Entity> vessels;
        m_world.forEach<sw::parts::VesselComponent>(
            [&](sw::ecs::Entity entity, sw::parts::VesselComponent& vessel) {
                if (vessel.partCount > 0)
                {
                    vessels.push_back(entity);
                }
            });
        if (vessels.empty())
        {
            return;
        }
        sw::usize next = 0;
        for (sw::usize i = 0; i < vessels.size(); ++i)
        {
            if (vessels[i] == m_hangarSource)
            {
                next = (i + 1) % vessels.size();
            }
        }
        m_hangarSource = vessels[next];

        // Parts -> blueprint (indices), joints -> parent links.
        m_blueprint.clear();
        std::vector<sw::ecs::Entity> partEntities;
        m_world.forEach<sw::parts::PartComponent>(
            [&](sw::ecs::Entity entity, sw::parts::PartComponent& part) {
                if (part.vessel != m_hangarSource)
                {
                    return;
                }
                BlueprintPart bp{};
                bp.definitionId = part.definitionId;
                bp.localPosition = part.localPosition;
                m_blueprint.push_back(bp);
                partEntities.push_back(entity);
            });
        m_world.forEach<sw::parts::JointComponent>(
            [&](sw::ecs::Entity, sw::parts::JointComponent& jointComponent) {
                sw::i32 a = -1;
                sw::i32 b = -1;
                for (sw::usize i = 0; i < partEntities.size(); ++i)
                {
                    if (partEntities[i] == jointComponent.partA) { a = static_cast<sw::i32>(i); }
                    if (partEntities[i] == jointComponent.partB) { b = static_cast<sw::i32>(i); }
                }
                if (a >= 0 && b >= 0)
                {
                    m_blueprint[static_cast<sw::usize>(b)].parentIndex = a;
                    m_blueprint[static_cast<sw::usize>(b)].parentPoint =
                        jointComponent.attachPointA;
                    m_blueprint[static_cast<sw::usize>(b)].childPoint =
                        jointComponent.attachPointB;
                }
            });
        m_editorPointIndex = 0;
        SW_LOG_INFO("Game", "HANGAR: loaded vessel ({} parts)", m_blueprint.size());
    }

    std::vector<StarWorksGame::OpenAttachPoint> StarWorksGame::openAttachPoints()
    {
        // Open = attach points of blueprint parts not used by any link.
        std::vector<OpenAttachPoint> open;
        for (sw::usize i = 0; i < m_blueprint.size(); ++i)
        {
            const auto* definition =
                sw::parts::findDefinition(m_blueprint[i].definitionId);
            if (definition == nullptr)
            {
                continue;
            }
            for (sw::u8 p = 0; p < definition->attachPointCount; ++p)
            {
                bool occupied = false;
                for (sw::usize j = 0; j < m_blueprint.size(); ++j)
                {
                    const auto& other = m_blueprint[j];
                    if ((other.parentIndex == static_cast<sw::i32>(i) &&
                         other.parentPoint == p) ||
                        (j == i && other.parentIndex >= 0 && other.childPoint == p))
                    {
                        occupied = true;
                        break;
                    }
                }
                if (occupied)
                {
                    continue;
                }
                OpenAttachPoint point{};
                point.part = {};
                point.pointIndex = p;
                point.vesselPosition =
                    m_blueprint[i].localPosition + definition->attachPoints[p].position;
                point.vesselDirection = definition->attachPoints[p].direction;
                // Reuse `part` to carry the blueprint INDEX (hangar-local).
                point.part.index = static_cast<sw::u32>(i);
                point.part.generation = 0xFFFFFFFFu;
                open.push_back(point);
            }
        }
        return open;
    }

    bool StarWorksGame::ghostPose(const OpenAttachPoint& target, sw::u32 definitionId,
                                  sw::Vec3& outLocalPosition, sw::u8& outChildPoint,
                                  bool& outCollides, bool& outOverloaded)
    {
        const auto* definition = sw::parts::findDefinition(definitionId);
        if (definition == nullptr)
        {
            return false;
        }
        sw::i32 childPoint = -1;
        for (sw::u8 i = 0; i < definition->attachPointCount; ++i)
        {
            if (glm::dot(definition->attachPoints[i].direction,
                         -target.vesselDirection) > 0.5f)
            {
                childPoint = i;
                break;
            }
        }
        if (childPoint < 0)
        {
            return false;
        }
        outChildPoint = static_cast<sw::u8>(childPoint);
        outLocalPosition = target.vesselPosition -
                           definition->attachPoints[childPoint].position;

        auto approxRadius = [](const sw::parts::PartDefinition& d) {
            return std::cbrt(static_cast<sw::f32>(d.volumeM3)) * 0.62f + 0.55f;
        };
        outCollides = false;
        for (sw::usize i = 0; i < m_blueprint.size(); ++i)
        {
            if (i == target.part.index)
            {
                continue;
            }
            const auto* other = sw::parts::findDefinition(m_blueprint[i].definitionId);
            if (other == nullptr)
            {
                continue;
            }
            const sw::f32 clearance =
                (approxRadius(*definition) + approxRadius(*other)) * 0.72f;
            if (glm::distance(outLocalPosition, m_blueprint[i].localPosition) <
                clearance)
            {
                outCollides = true;
                break;
            }
        }

        sw::f64 childMass = definition->dryMassKg;
        for (const auto& capacity : definition->capacities)
        {
            if (capacity.resource != sw::res::Resource::Count)
            {
                childMass += capacity.units *
                             sw::res::definition(capacity.resource).massPerUnitKg;
            }
        }
        const auto* parentDefinition = sw::parts::findDefinition(
            m_blueprint[target.part.index].definitionId);
        outOverloaded = childMass * 12.0 >
                        std::min(definition->breakingForceN,
                                 parentDefinition->breakingForceN);
        return true;
    }

    void StarWorksGame::placePart(const OpenAttachPoint& target, sw::u32 definitionId)
    {
        sw::Vec3 localPosition{};
        sw::u8 childPoint = 0;
        bool collides = false;
        bool overloaded = false;
        if (!ghostPose(target, definitionId, localPosition, childPoint, collides,
                       overloaded) ||
            collides || overloaded)
        {
            SW_LOG_WARN("Game", "HANGAR: invalid placement rejected");
            return;
        }
        BlueprintPart part{};
        part.definitionId = definitionId;
        part.localPosition = localPosition;
        part.parentIndex = static_cast<sw::i32>(target.part.index);
        part.parentPoint = target.pointIndex;
        part.childPoint = childPoint;
        m_blueprint.push_back(part);
    }

    sw::ecs::Entity StarWorksGame::instantiateBlueprint(sw::ecs::Entity existingRoot)
    {
        sw::ecs::Entity root = existingRoot;
        if (root.isNull())
        {
            // NEW vessel: born on the LAUNCH PAD, standing on Terra's
            // terrain next to the mining outpost, co-rotating with the
            // planet, nose to the sky.
            const auto& terra = m_world.getComponent<TransformComponent>(m_terraEntity);
            const auto& gravity =
                m_world.getComponent<sw::phys::GravitySourceComponent>(m_terraEntity);
            const sw::Vec3 padDir = glm::normalize(sw::Vec3{0.05f, 0.0f, 1.0f});
            const sw::f64 elevation =
                sw::planet::terrainElevation(terraTerrain(), padDir);
            const sw::WorldVec3 padLocal =
                sw::WorldVec3(padDir) * (kTerraRadius + elevation + 11.0);
            const sw::WorldVec3 position =
                terra.position + glm::dquat(terra.rotation) * padLocal;
            const sw::WorldVec3 radial = position - terra.position;
            const sw::Vec3 up = sw::Vec3(glm::normalize(radial));
            const sw::Vec3 zAxis = -up; // rocket +Z (tail) points down
            const sw::Vec3 reference =
                (std::abs(zAxis.y) < 0.99f) ? sw::Vec3{0, 1, 0} : sw::Vec3{1, 0, 0};
            const sw::Vec3 xAxis = glm::normalize(glm::cross(reference, zAxis));
            const sw::Vec3 yAxis = glm::cross(zAxis, xAxis);

            root = m_world.createEntity();
            TransformComponent transform{};
            transform.position = position;
            transform.rotation = glm::quat_cast(sw::Mat3{xAxis, yAxis, zAxis});
            m_world.addComponent(root, transform);
            m_world.addComponent(root, PreviousTransformComponent{transform.position,
                                                                  transform.rotation});
            m_world.addComponent(root, BoundsComponent{0.1f});
            m_world.addComponent(root, MapMarkerComponent{{0.4f, 0.9f, 1.0f, 1.0f}});
            m_world.addComponent(root, ShipComponent{});
            m_world.addComponent(root, ShipControlsComponent{});
            m_world.addComponent(root, SasComponent{});
            m_world.addComponent(root, sw::parts::VesselComponent{});
            sw::phys::DynamicBodyComponent body{};
            body.velocity = gravity.worldVelocity +
                            glm::cross(gravity.angularVelocity, radial);
            body.mass = 1.0e4;
            m_world.addComponent(root, body);
        }
        else
        {
            // APPLY to the loaded vessel: tear out its old parts & joints.
            std::vector<sw::ecs::Entity> stale;
            m_world.forEach<sw::parts::PartComponent>(
                [&](sw::ecs::Entity entity, sw::parts::PartComponent& part) {
                    if (part.vessel == root)
                    {
                        stale.push_back(entity);
                    }
                });
            m_world.forEach<sw::parts::JointComponent>(
                [&](sw::ecs::Entity entity, sw::parts::JointComponent& joint) {
                    for (const sw::ecs::Entity part : stale)
                    {
                        if (joint.partA == part || joint.partB == part)
                        {
                            stale.push_back(entity);
                            return;
                        }
                    }
                });
            for (const sw::ecs::Entity entity : stale)
            {
                m_world.destroyEntity(entity);
            }
        }

        // Blueprint -> live part entities + joints.
        const auto& rootTransform = m_world.getComponent<TransformComponent>(root);
        std::vector<sw::ecs::Entity> spawned;
        for (const BlueprintPart& bp : m_blueprint)
        {
            const auto* definition = sw::parts::findDefinition(bp.definitionId);
            const sw::ecs::Entity part = m_world.createEntity();
            TransformComponent transform{};
            transform.position =
                rootTransform.position +
                sw::WorldVec3(rootTransform.rotation * bp.localPosition);
            transform.rotation = rootTransform.rotation;
            m_world.addComponent(part, transform);
            m_world.addComponent(part, PreviousTransformComponent{transform.position,
                                                                  transform.rotation});
            m_world.addComponent(part, BoundsComponent{3.0f});
            m_world.addComponent(part, MeshComponent{m_partMeshIds[bp.definitionId]});
            sw::parts::PartComponent component{};
            component.definitionId = bp.definitionId;
            component.vessel = root;
            component.localPosition = bp.localPosition;
            m_world.addComponent(part, component);
            if (definition->capacities[0].resource != sw::res::Resource::Count)
            {
                sw::factory::InventoryComponent inventory{};
                const auto resource = definition->capacities[0].resource;
                inventory.volumeCapacityM3 =
                    definition->capacities[0].units *
                    sw::res::definition(resource).volumePerUnitM3 * 1.02;
                if (definition->type == sw::parts::PartType::FuelTank)
                {
                    sw::factory::inventoryAdd(inventory, resource,
                                              definition->capacities[0].units);
                }
                m_world.addComponent(part, inventory);
            }
            spawned.push_back(part);
        }
        for (sw::usize i = 0; i < m_blueprint.size(); ++i)
        {
            const BlueprintPart& bp = m_blueprint[i];
            if (bp.parentIndex < 0)
            {
                continue;
            }
            const auto* a = sw::parts::findDefinition(
                m_blueprint[static_cast<sw::usize>(bp.parentIndex)].definitionId);
            const auto* b = sw::parts::findDefinition(bp.definitionId);
            const sw::f64 force = std::min(a->breakingForceN, b->breakingForceN);
            const auto& parentDef = *a;
            const bool radial =
                std::abs(parentDef.attachPoints[bp.parentPoint].direction.z) < 0.7f;
            sw::parts::connectParts(
                m_world, spawned[static_cast<sw::usize>(bp.parentIndex)], spawned[i],
                bp.parentPoint, bp.childPoint,
                radial ? sw::parts::JointType::Radial : sw::parts::JointType::Stack,
                force, force);
        }
        return root;
    }

    void StarWorksGame::hangarBuild()
    {
        if (m_blueprint.empty())
        {
            return;
        }
        const sw::ecs::Entity vessel = instantiateBlueprint(m_hangarSource);
        if (m_hangarSource.isNull())
        {
            m_shipEntity = vessel; // fly the new build from the pad
            m_sasMode = 0;
            SW_LOG_INFO("Game", "HANGAR: new vessel BUILT on the launch pad");
        }
        else
        {
            SW_LOG_INFO("Game", "HANGAR: modifications applied to loaded vessel");
        }
        exitEditor();
    }

    void StarWorksGame::cyclePilotedVessel()
    {
        std::vector<sw::ecs::Entity> pilotable;
        m_world.forEach<ShipComponent>([&](sw::ecs::Entity entity, ShipComponent&) {
            pilotable.push_back(entity);
        });
        if (pilotable.size() < 2)
        {
            return;
        }
        sw::usize next = 0;
        for (sw::usize i = 0; i < pilotable.size(); ++i)
        {
            if (pilotable[i] == m_shipEntity)
            {
                next = (i + 1) % pilotable.size();
            }
        }
        m_shipEntity = pilotable[next];
        m_evaMode = false;
        m_sasMode = 0;
        SW_LOG_INFO("Game", "PILOTING vessel {}", m_shipEntity.index);
    }

    void StarWorksGame::updateEditor()
    {
        // Hangar camera: right-drag orbits, wheel zooms.
        if (input().isMouseButtonDown(sw::MouseButton::Right))
        {
            m_hangarYaw -= input().mouseDeltaX() * 0.005f;
            m_hangarPitch = std::clamp(m_hangarPitch - input().mouseDeltaY() * 0.005f,
                                       -1.2f, 1.4f);
        }
        if (const sw::f32 scroll = input().scrollDeltaY(); scroll != 0.0f)
        {
            m_hangarDistance =
                std::clamp(m_hangarDistance * std::pow(1.15f, -scroll), 8.0f, 90.0f);
        }
        const sw::f32 cosPitch = std::cos(m_hangarPitch);
        const sw::Vec3 offset{cosPitch * std::sin(m_hangarYaw) * m_hangarDistance,
                              std::sin(m_hangarPitch) * m_hangarDistance,
                              cosPitch * std::cos(m_hangarYaw) * m_hangarDistance};
        m_hangarCamera.setPosition(sw::WorldVec3(offset));
        const sw::Vec3 forward = glm::normalize(-offset);
        const sw::Vec3 right = glm::normalize(glm::cross(forward, sw::Vec3{0, 1, 0}));
        const sw::Vec3 up = glm::cross(right, forward);
        m_hangarCamera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
        m_hangarCamera.setAspectRatio(renderer().aspectRatio());

        const auto open = openAttachPoints();
        const auto catalogSpan = sw::parts::catalog();
        if (!open.empty())
        {
            m_editorPointIndex %= open.size();
            if (input().wasKeyPressed(sw::KeyCode::Right)) { ++m_editorPointIndex; }
            if (input().wasKeyPressed(sw::KeyCode::Left))
            {
                m_editorPointIndex =
                    (m_editorPointIndex + open.size() - 1) % open.size();
            }
            m_editorPointIndex %= open.size();
            if (input().wasKeyPressed(sw::KeyCode::Enter))
            {
                placePart(open[m_editorPointIndex], catalogSpan[m_editorTypeIndex].id);
            }
        }
        if (input().wasKeyPressed(sw::KeyCode::Down))
        {
            m_editorTypeIndex = (m_editorTypeIndex + 1) % catalogSpan.size();
        }
        if (input().wasKeyPressed(sw::KeyCode::Up))
        {
            m_editorTypeIndex =
                (m_editorTypeIndex + catalogSpan.size() - 1) % catalogSpan.size();
        }
    }

    void StarWorksGame::collectHangarItems()
    {
        m_drawItems.clear();
        const sw::WorldVec3 cameraPosition = m_hangarCamera.position();

        // Floor grid: the hangar deck.
        {
            sw::DrawItem floor{};
            floor.mesh = &m_meshes[m_hangarFloorMeshIndex];
            floor.transform = glm::translate(
                sw::Mat4{1.0f}, sw::Vec3(sw::WorldVec3{0.0, -14.0, 0.0} - cameraPosition));
            floor.boundsCenter = sw::Vec3(sw::WorldVec3{0.0, -14.0, 0.0} - cameraPosition);
            floor.boundsRadius = 60.0f;
            m_drawItems.push_back(floor);
        }

        // Blueprint parts (vertical: rocket -Z nose shown pointing up via a
        // fixed display rotation).
        const sw::Quat display = glm::angleAxis(-1.5707963f, sw::Vec3{1, 0, 0});
        auto toWorld = [&](const sw::Vec3& local) {
            return sw::WorldVec3(display * local);
        };
        for (const BlueprintPart& bp : m_blueprint)
        {
            const sw::Vec3 relative = sw::Vec3(toWorld(bp.localPosition) - cameraPosition);
            sw::DrawItem item{};
            item.mesh = &m_meshes[m_partMeshIds[bp.definitionId]];
            item.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                             glm::mat4_cast(display);
            item.boundsCenter = relative;
            item.boundsRadius = 4.0f;
            m_drawItems.push_back(item);
        }

        // Open attach nodes + ghost.
        const auto open = openAttachPoints();
        if (!open.empty())
        {
            const sw::usize targetIndex = m_editorPointIndex % open.size();
            for (sw::usize i = 0; i < open.size(); ++i)
            {
                const sw::Vec3 relative =
                    sw::Vec3(toWorld(open[i].vesselPosition) - cameraPosition);
                const sw::f32 scale = (i == targetIndex) ? 0.5f : 0.28f;
                sw::DrawItem marker{};
                marker.mesh = &m_meshes[m_markerMeshIndex];
                marker.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                marker.boundsCenter = relative;
                marker.boundsRadius = scale;
                marker.tint = (i == targetIndex) ? sw::Vec4{1.0f, 1.0f, 1.0f, 2.0f}
                                                 : sw::Vec4{0.3f, 0.9f, 1.0f, 2.0f};
                m_drawItems.push_back(marker);
            }
            const sw::u32 definitionId = sw::parts::catalog()[m_editorTypeIndex].id;
            sw::Vec3 localPosition{};
            sw::u8 childPoint = 0;
            bool collides = false;
            bool overloaded = false;
            if (ghostPose(open[targetIndex], definitionId, localPosition, childPoint,
                          collides, overloaded))
            {
                const bool valid = !collides && !overloaded;
                const sw::Vec3 relative =
                    sw::Vec3(toWorld(localPosition) - cameraPosition);
                sw::DrawItem ghost{};
                ghost.mesh = &m_meshes[m_partMeshIds[definitionId]];
                ghost.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                                  glm::mat4_cast(display);
                ghost.boundsCenter = relative;
                ghost.boundsRadius = 4.0f;
                ghost.tint = valid ? sw::Vec4{0.35f, 1.0f, 0.45f, 0.45f}
                                   : sw::Vec4{1.0f, 0.25f, 0.2f, 0.5f};
                ghost.transparent = true;
                m_drawItems.push_back(ghost);
            }
        }

        collectEditorUi();
    }

    // ---- hangar UI: title, clickable part palette, action row, stats ------
    void StarWorksGame::collectEditorUi()
    {
        // The hangar owns the whole button set for the frame (the SAS row
        // is a flight instrument and stays out of the hangar).
        m_hudButtons.clear();

        const sw::Vec4 titleColor{1.0f, 0.85f, 0.35f, 1.0f};
        const sw::Vec4 textColor{0.8f, 0.9f, 1.0f, 0.95f};
        hudText("HANGAR - ARROWS = NODE/TYPE, ENTER = PLACE",
                -0.97f, -0.96f, 0.048f, titleColor);
        hudText(m_hangarSource.isNull() ? "MODE: NEW BUILD -> LAUNCH PAD"
                                        : "MODE: MODIFYING LOADED VESSEL",
                -0.97f, -0.885f, 0.036f, textColor);
        hudText("B = EXIT WITHOUT BUILDING", -0.97f, -0.825f, 0.030f,
                sw::Vec4{0.6f, 0.72f, 0.82f, 0.85f});

        auto panel = [&](sw::f32 x0, sw::f32 y0, sw::f32 x1, sw::f32 y1,
                         const sw::Vec4& color) {
            sw::DrawItem item{};
            item.mesh = &m_meshes[m_navLineMeshIndex]; // unit quad
            item.transform =
                glm::translate(sw::Mat4{1.0f},
                               {(x0 + x1) * 0.5f, (y0 + y1) * 0.5f, 0.0f}) *
                glm::scale(sw::Mat4{1.0f},
                           {(x1 - x0) * 0.5f, (y1 - y0) * 0.5f, 1.0f});
            item.screenSpace = true;
            item.tint = color;
            m_drawItems.push_back(item);
        };

        // ---- part palette: one clickable row per catalog entry -------------
        const auto partCatalog = sw::parts::catalog();
        constexpr sw::f32 kRowStride = 0.082f;
        constexpr sw::f32 kRowHeight = 0.068f;
        constexpr sw::f32 kRowWidth = 0.40f;
        sw::f32 rowY = -0.72f;
        for (sw::usize i = 0; i < partCatalog.size(); ++i)
        {
            const bool selected = (i == m_editorTypeIndex % partCatalog.size());
            panel(-0.98f, rowY, -0.98f + kRowWidth, rowY + kRowHeight,
                  selected ? sw::Vec4{0.20f, 0.52f, 0.30f, 0.85f}
                           : sw::Vec4{0.13f, 0.19f, 0.28f, 0.60f});
            hudText(partCatalog[i].name, -0.962f, rowY + 0.017f, 0.030f,
                    selected ? sw::Vec4{0.9f, 1.0f, 0.9f, 1.0f}
                             : sw::Vec4{0.68f, 0.78f, 0.88f, 0.9f});
            m_hudButtons.push_back({-0.98f, rowY, -0.98f + kRowWidth,
                                    rowY + kRowHeight,
                                    100u + static_cast<sw::u32>(i)});
            rowY += kRowStride;
        }

        // Selected part's property sheet, under the palette.
        {
            const sw::parts::PartDefinition& selected =
                partCatalog[m_editorTypeIndex % partCatalog.size()];
            hudText(std::format("MASS {:.0f} KG  COST {:.0f}  VOL {:.1f} M3",
                                selected.dryMassKg, selected.costCredits,
                                selected.volumeM3),
                    -0.97f, rowY + 0.012f, 0.028f, textColor);
            if (selected.thrustNewtons > 0.0)
            {
                hudText(std::format("THRUST {:.0f} KN  ISP {:.0f} S",
                                    selected.thrustNewtons / 1000.0,
                                    selected.specificImpulseS),
                        -0.97f, rowY + 0.058f, 0.028f, textColor);
            }
        }

        // ---- action row (bottom-center) -------------------------------------
        const char* actions[5] = {"PLACE", "UNDO", "NEW", "LOAD", "BUILD"};
        constexpr sw::f32 kButtonWidth = 0.155f;
        constexpr sw::f32 kButtonHeight = 0.072f;
        constexpr sw::f32 kButtonGap = 0.02f;
        sw::f32 buttonX = -0.42f;
        const sw::f32 buttonY = 0.86f;
        for (sw::u32 i = 0; i < 5; ++i)
        {
            const sw::f32 x1 = buttonX + kButtonWidth;
            panel(buttonX, buttonY, x1, buttonY + kButtonHeight,
                  i == 4 ? sw::Vec4{0.60f, 0.38f, 0.10f, 0.9f}   // BUILD stands out
                         : sw::Vec4{0.16f, 0.24f, 0.34f, 0.75f});
            hudText(actions[i], buttonX + 0.02f, buttonY + 0.019f, 0.034f,
                    sw::Vec4{0.92f, 0.96f, 1.0f, 1.0f});
            m_hudButtons.push_back({buttonX, buttonY, x1,
                                    buttonY + kButtonHeight, 200u + i});
            buttonX = x1 + kButtonGap;
        }

        // ---- blueprint stats (top-right) -------------------------------------
        sw::f64 wetMassKg = 0.0;
        sw::f64 costCredits = 0.0;
        for (const BlueprintPart& blueprintPart : m_blueprint)
        {
            const sw::parts::PartDefinition* definition =
                sw::parts::findDefinition(blueprintPart.definitionId);
            if (definition == nullptr)
            {
                continue;
            }
            wetMassKg += definition->dryMassKg;
            for (const sw::parts::ResourceCapacity& capacity : definition->capacities)
            {
                wetMassKg += capacity.units; // 1 unit = 1 kg, filled at build
            }
            costCredits += definition->costCredits;
        }
        hudText(std::format("WET MASS {:.1f} T  COST {:.0f}  PARTS {}",
                            wetMassKg / 1000.0, costCredits, m_blueprint.size()),
                0.16f, -0.95f, 0.034f, textColor);
    }

    void StarWorksGame::collectSasButtons()
    {
        // First clickable UI: three buttons above the bottom-left corner.
        m_hudButtons.clear();
        constexpr sw::f32 kHeight = 0.062f;
        constexpr sw::f32 kWidth = 0.115f;
        constexpr sw::f32 kGap = 0.018f;
        const sw::f32 y0 = 0.87f;
        sw::f32 x0 = -0.97f;

        const char* labels[3] = {"SAS", "PGD", "RTG"};
        for (sw::u32 id = 0; id < 3; ++id)
        {
            const sw::f32 x1 = x0 + kWidth;
            const bool active = (id == 0) ? (m_sasMode == 0) : (m_sasMode == id);
            const sw::Vec4 background =
                active ? sw::Vec4{0.15f, 0.55f, 0.30f, 0.85f}
                       : sw::Vec4{0.16f, 0.22f, 0.30f, 0.65f};

            sw::DrawItem panel{};
            panel.mesh = &m_meshes[m_navLineMeshIndex]; // unit quad
            panel.transform =
                glm::translate(sw::Mat4{1.0f},
                               {(x0 + x1) * 0.5f, y0 + kHeight * 0.5f, 0.0f}) *
                glm::scale(sw::Mat4{1.0f},
                           {kWidth * 0.5f, kHeight * 0.5f, 1.0f});
            panel.screenSpace = true;
            panel.tint = background;
            m_drawItems.push_back(panel);

            hudText(labels[id], x0 + 0.022f, y0 + 0.015f, 0.036f,
                    active ? sw::Vec4{0.9f, 1.0f, 0.9f, 1.0f}
                           : sw::Vec4{0.7f, 0.8f, 0.9f, 0.9f});

            m_hudButtons.push_back({x0, y0, x1, y0 + kHeight, id});
            x0 = x1 + kGap;
        }
    }

    void StarWorksGame::handleHudClicks()
    {
        if (m_mapView || !input().wasMouseButtonPressed(sw::MouseButton::Left))
        {
            return;
        }
        sw::u32 width = 0;
        sw::u32 height = 0;
        window().framebufferSize(width, height);
        if (width == 0 || height == 0)
        {
            return;
        }
        const sw::f32 ndcX = input().mouseX() / static_cast<sw::f32>(width) * 2.0f - 1.0f;
        const sw::f32 ndcY = input().mouseY() / static_cast<sw::f32>(height) * 2.0f - 1.0f;
        for (const HudButton& button : m_hudButtons)
        {
            if (ndcX >= button.x0 && ndcX <= button.x1 && ndcY >= button.y0 &&
                ndcY <= button.y1)
            {
                // ---- editor palette / actions -------------------------------
                if (button.id >= 200)
                {
                    if (button.id == 200) // PLACE
                    {
                        const auto open = openAttachPoints();
                        if (!open.empty())
                        {
                            placePart(open[m_editorPointIndex % open.size()],
                                      sw::parts::catalog()[m_editorTypeIndex].id);
                        }
                    }
                    else if (button.id == 201 && m_blueprint.size() > 1) // UNDO
                    {
                        m_blueprint.pop_back();
                    }
                    else if (button.id == 202) { hangarNewBlueprint(); }
                    else if (button.id == 203) { hangarLoadNextVessel(); }
                    else if (button.id == 204) { hangarBuild(); }
                    return;
                }
                if (button.id >= 100) // palette
                {
                    m_editorTypeIndex = button.id - 100;
                    return;
                }
                // SAS button = off; PGD/RTG toggle their mode.
                if (button.id == 0) { m_sasMode = 0; }
                else { m_sasMode = (m_sasMode == button.id) ? 0 : button.id; }
                SW_LOG_INFO("Game", "SAS mode: {}",
                            m_sasMode == 0 ? "OFF"
                                           : (m_sasMode == 1 ? "PROGRADE"
                                                             : "RETROGRADE"));
                break;
            }
        }
    }

    void StarWorksGame::collectNavball()
    {
        const sw::i32 primaryIndex = controlledPrimaryIndex();
        if (primaryIndex < 0)
        {
            return; // no reference vertical in deep space
        }
        const sw::ecs::Entity entity = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(entity);
        const sw::f64 time = m_physicsLane->presentSeconds();

        sw::WorldVec3 primaryPosition{};
        sw::WorldVec3 primaryVelocity{};
        m_celestialIndex.stateAt(primaryIndex, time, primaryPosition, &primaryVelocity);
        const sw::WorldVec3 radial = transform.position - primaryPosition;
        const sw::f64 distance = glm::length(radial);
        if (distance <= 1.0)
        {
            return;
        }
        const sw::Vec3 up = sw::Vec3(radial / distance);

        // ---- attitude vs the local horizon --------------------------------------
        const sw::Quat rotation = transform.rotation;
        const sw::Vec3 forward = rotation * sw::math::kWorldForward;
        const sw::Vec3 rightWing = rotation * sw::Vec3{1.0f, 0.0f, 0.0f};
        const sw::Vec3 shipUp = rotation * sw::Vec3{0.0f, 1.0f, 0.0f};
        const sw::f32 pitch =
            std::asin(std::clamp(glm::dot(forward, up), -1.0f, 1.0f));
        const sw::f32 roll = std::atan2(glm::dot(rightWing, up), glm::dot(shipUp, up));

        const sw::f32 aspect = renderer().aspectRatio();
        const sw::f32 ballRadius = kNavballRadius;

        // Isotropic instrument space: rotate/offset there, compress X by the
        // aspect ratio last (same convention as hudText).
        const sw::Mat4 base =
            glm::translate(sw::Mat4{1.0f}, {0.0f, kNavballCenterY, 0.0f}) *
            glm::scale(sw::Mat4{1.0f}, {1.0f / aspect, 1.0f, 1.0f});

        auto pushNav = [&](sw::u32 meshIndex, const sw::Mat4& local,
                           const sw::Vec4& color) {
            sw::DrawItem item{};
            item.mesh = &m_meshes[meshIndex];
            item.transform = base * local;
            item.screenSpace = true;
            item.tint = color;
            m_drawItems.push_back(item);
        };

        const sw::Vec4 frameColor{0.65f, 0.85f, 0.9f, 0.55f};
        const sw::Vec4 horizonColor{0.55f, 0.95f, 1.0f, 0.9f};
        const sw::Vec4 referenceColor{1.0f, 0.62f, 0.15f, 0.95f};

        // Outer ring.
        pushNav(m_navRingMeshIndex,
                glm::scale(sw::Mat4{1.0f}, sw::Vec3{ballRadius}), frameColor);

        // Horizon line: rotated by roll, shifted by pitch (nose up -> the
        // horizon drops on screen; screen Y grows downward). Each line is
        // clipped to the CHORD of the ball at its offset, so the instrument
        // never bleeds outside its ring (and degrades gracefully at the
        // straight-up/straight-down gimbal poles, where the chord vanishes).
        const sw::Mat4 rollRotation =
            glm::rotate(sw::Mat4{1.0f}, roll, {0.0f, 0.0f, 1.0f});
        auto pushHorizonLine = [&](sw::f32 angleFromHorizon, sw::f32 widthFactor,
                                   sw::f32 thickness, sw::f32 alpha) {
            const sw::f32 normalized =
                std::clamp((pitch + angleFromHorizon) / kHalfPi, -1.0f, 1.0f);
            const sw::f32 offset = normalized * ballRadius * 0.92f;
            const sw::f32 chord = std::sqrt(std::max(
                0.0f, 1.0f - normalized * normalized * 0.85f)); // 0 at the poles
            if (chord < 0.05f)
            {
                return;
            }
            pushNav(m_navLineMeshIndex,
                    rollRotation *
                        glm::translate(sw::Mat4{1.0f}, {0.0f, offset, 0.0f}) *
                        glm::scale(sw::Mat4{1.0f},
                                   {ballRadius * widthFactor * chord,
                                    ballRadius * thickness, 1.0f}),
                    {horizonColor.r, horizonColor.g, horizonColor.b, alpha});
        };
        pushHorizonLine(0.0f, 0.86f, 0.012f, 0.9f);
        // Short pitch ticks at +/- 30 degrees from the horizon.
        pushHorizonLine(-0.5235988f, 0.34f, 0.007f, 0.5f);
        pushHorizonLine(0.5235988f, 0.34f, 0.007f, 0.5f);

        // Fixed craft reference: center diamond + stub wings.
        pushNav(m_navDiamondMeshIndex,
                glm::scale(sw::Mat4{1.0f}, sw::Vec3{ballRadius * 0.05f}),
                referenceColor);
        for (const sw::f32 side : {-1.0f, 1.0f})
        {
            pushNav(m_navLineMeshIndex,
                    glm::translate(sw::Mat4{1.0f},
                                   {side * ballRadius * 0.17f, 0.0f, 0.0f}) *
                        glm::scale(sw::Mat4{1.0f},
                                   {ballRadius * 0.09f, ballRadius * 0.012f, 1.0f}),
                    referenceColor);
        }

        // ---- prograde / retrograde markers ---------------------------------------
        // Velocity in the HUD's current reference frame (ORB or SRF, like
        // the speed readout), projected into the craft's body frame.
        sw::WorldVec3 referenceVelocity = primaryVelocity;
        if (m_speedSurfaceRelative)
        {
            if (const auto* source =
                    m_world.tryGetComponent<sw::phys::GravitySourceComponent>(
                        m_celestialIndex.body(static_cast<sw::usize>(primaryIndex))
                            .entity))
            {
                referenceVelocity += glm::cross(source->angularVelocity, radial);
            }
        }
        const sw::WorldVec3 relativeVelocity =
            controlledVelocity() - referenceVelocity;
        const sw::f64 relativeSpeed = glm::length(relativeVelocity);
        if (relativeSpeed > 0.5)
        {
            const sw::Vec3 direction = sw::Vec3(relativeVelocity / relativeSpeed);
            const sw::Quat inverseRotation = glm::inverse(rotation);
            for (const sw::f32 sign : {1.0f, -1.0f}) // prograde, retrograde
            {
                const sw::Vec3 local = inverseRotation * (direction * sign);
                if (local.z >= 0.0f)
                {
                    continue; // behind the craft: not on the front hemisphere
                }
                const sw::Vec2 ballPosition{local.x * ballRadius,
                                            -local.y * ballRadius};
                const sw::Mat4 place = glm::translate(
                    sw::Mat4{1.0f}, {ballPosition.x, ballPosition.y, 0.0f});
                if (sign > 0.0f) // prograde: filled diamond
                {
                    pushNav(m_navDiamondMeshIndex,
                            place * glm::scale(sw::Mat4{1.0f},
                                               sw::Vec3{ballRadius * 0.085f}),
                            {0.55f, 1.0f, 0.35f, 0.95f});
                }
                else // retrograde: hollow ring
                {
                    pushNav(m_navRingMeshIndex,
                            place * glm::scale(sw::Mat4{1.0f},
                                               sw::Vec3{ballRadius * 0.085f}),
                            {1.0f, 0.5f, 0.25f, 0.95f});
                }
            }
        }

        // ---- maneuver burn marker: point the nose at it, burn, watch DV --
        if (m_nodeActive)
        {
            const sw::WorldVec3 burnVector =
                m_nodePostBurnVelocity - controlledVelocity();
            const sw::f64 burnLength = glm::length(burnVector);
            if (burnLength > 0.05)
            {
                const sw::Vec3 local = glm::inverse(rotation) *
                                       sw::Vec3(burnVector / burnLength);
                if (local.z < 0.0f) // front hemisphere
                {
                    const sw::Mat4 place = glm::translate(
                        sw::Mat4{1.0f},
                        {local.x * ballRadius, -local.y * ballRadius, 0.0f});
                    pushNav(m_navDiamondMeshIndex,
                            place * glm::scale(sw::Mat4{1.0f},
                                               sw::Vec3{ballRadius * 0.11f}),
                            {0.75f, 0.4f, 1.0f, 0.95f});
                    pushNav(m_navRingMeshIndex,
                            place * glm::scale(sw::Mat4{1.0f},
                                               sw::Vec3{ballRadius * 0.13f}),
                            {0.75f, 0.4f, 1.0f, 0.7f});
                }
            }
        }
    }

    void StarWorksGame::collectMapTrajectories(const sw::Camera& activeCamera)
    {
        const sw::WorldVec3 cameraPosition = activeCamera.position();
        const sw::f32 markerFactor =
            kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);
        const sw::f64 time = m_physicsLane->presentSeconds();

        // One dot of the dotted trajectory (emissive: tint alpha 2.0).
        auto plotDot = [&](const sw::WorldVec3& point, const sw::Vec4& color,
                           sw::f32 sizeMultiplier) {
            const sw::Vec3 relative = sw::Vec3(point - cameraPosition);
            const sw::f32 scale =
                glm::length(relative) * markerFactor * 0.22f * sizeMultiplier;
            sw::DrawItem item{};
            item.mesh = &m_meshes[m_markerMeshIndex];
            item.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                             glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
            item.boundsCenter = relative;
            item.boundsRadius = scale;
            item.tint = {color.r, color.g, color.b, 2.0f};
            m_drawItems.push_back(item);
        };

        // Samples a conic around a primary's CURRENT world position over
        // [t0, t1] — KSP map convention: patches are drawn in the frame of
        // where their primary is NOW.
        auto plotConic = [&](const sw::phys::KeplerOrbit& orbit,
                             const sw::WorldVec3& primaryPosition, const sw::Vec4& color,
                             sw::f64 t0, sw::f64 t1, sw::u32 samples) {
            for (sw::u32 sample = 0; sample < samples; ++sample)
            {
                const sw::f64 ts =
                    t0 + (t1 - t0) * static_cast<sw::f64>(sample) / samples;
                sw::WorldVec3 relativePoint{};
                sw::phys::kepler::evaluate(orbit, ts, relativePoint);
                plotDot(primaryPosition + relativePoint, color, 1.0f);
            }
        };

        // Full closed orbit (elliptic only).
        auto plotFullOrbit = [&](const sw::phys::KeplerOrbit& orbit,
                                 const sw::WorldVec3& primaryPosition,
                                 const sw::Vec4& color) {
            if (!orbit.isHyperbolic())
            {
                plotConic(orbit, primaryPosition, color, time,
                          time + sw::phys::kepler::period(orbit), kTrajectorySamples);
            }
        };

        // ---- celestial orbits: each body around its parent's current position --
        for (sw::usize i = 0; i < m_celestialIndex.size(); ++i)
        {
            const auto& body = m_celestialIndex.body(i);
            if (body.hasOrbit == 0 || body.parentIndex < 0)
            {
                continue;
            }
            sw::Vec4 color{0.5f, 0.5f, 0.55f, 1.0f};
            if (const auto* marker = m_world.tryGetComponent<MapMarkerComponent>(
                    body.entity))
            {
                color = marker->color * 0.6f;
            }
            plotFullOrbit(body.orbit,
                          m_celestialIndex.positionAt(body.parentIndex, time), color);
        }

        // ---- generic rails objects (station modules...) --------------------------
        m_world.forEach<sw::phys::OnRailsComponent, MapMarkerComponent>(
            [&](sw::ecs::Entity entity, sw::phys::OnRailsComponent& rails,
                MapMarkerComponent& marker) {
                if (entity == controlledEntity())
                {
                    return; // the controlled craft gets the full flight plan
                }
                sw::WorldVec3 primaryPosition{0.0};
                if (const auto* primaryTransform =
                        m_world.tryGetComponent<TransformComponent>(rails.primary))
                {
                    primaryPosition = primaryTransform->position;
                }
                plotFullOrbit(rails.orbit, primaryPosition, marker.color * 0.6f);
            });

        // ---- other dynamic objects: single conic around their SOI primary --------
        m_world.forEach<TransformComponent, sw::phys::DynamicBodyComponent,
                        MapMarkerComponent>(
            [&](sw::ecs::Entity entity, TransformComponent& transform,
                sw::phys::DynamicBodyComponent& body, MapMarkerComponent& marker) {
                if (entity == controlledEntity() || m_celestialIndex.size() == 0)
                {
                    return;
                }
                const sw::i32 primaryIndex =
                    m_celestialIndex.soiPrimaryAt(transform.position, time);
                if (primaryIndex < 0)
                {
                    return;
                }
                const auto& primary =
                    m_celestialIndex.body(static_cast<sw::usize>(primaryIndex));
                sw::WorldVec3 primaryPosition{};
                sw::WorldVec3 primaryVelocity{};
                m_celestialIndex.stateAt(primaryIndex, time, primaryPosition,
                                         &primaryVelocity);
                sw::phys::KeplerOrbit orbit{};
                if (sw::phys::kepler::fromStateVectors(
                        primary.mu, transform.position - primaryPosition,
                        body.velocity - primaryVelocity, time, orbit))
                {
                    plotFullOrbit(orbit, primaryPosition, marker.color * 0.6f);
                }
            });

        // ---- THE FLIGHT PLAN: patched-conics prediction of the controlled craft --
        auto plotPlan = [&](const std::vector<sw::space::TrajectorySegment>& plan,
                            bool nodePlan) {
            for (sw::usize segmentIndex = 0; segmentIndex < plan.size(); ++segmentIndex)
            {
                const sw::space::TrajectorySegment& segment = plan[segmentIndex];
                if (segment.primaryIndex < 0 ||
                    segment.endReason == sw::space::SegmentEnd::Lost)
                {
                    continue;
                }
                // The node plan glows white-violet so it never reads as the
                // current trajectory.
                const sw::Vec4 color =
                    nodePlan
                        ? sw::Vec4{0.85f, 0.75f + 0.25f * (segmentIndex == 0), 1.0f,
                                   1.0f}
                        : kPatchColors[std::min(segmentIndex,
                                                std::size(kPatchColors) - 1)];
                const sw::WorldVec3 primaryPosition =
                    m_celestialIndex.positionAt(segment.primaryIndex, time);

                // A closed, event-free orbit draws one full revolution;
                // every other patch draws exactly its [start, end] arc.
                sw::f64 t1 = segment.endTime;
                if (segment.endReason == sw::space::SegmentEnd::Horizon &&
                    !segment.orbit.isHyperbolic())
                {
                    t1 = std::min(segment.endTime,
                                  segment.startTime +
                                      sw::phys::kepler::period(segment.orbit));
                }
                plotConic(segment.orbit, primaryPosition, color, segment.startTime, t1,
                          kPredictionDisplaySamples);

                // Event marker at the patch hand-off point.
                sw::Vec4 eventColor{};
                bool hasEvent = true;
                switch (segment.endReason)
                {
                case sw::space::SegmentEnd::Encounter:
                    eventColor = {0.4f, 1.0f, 0.9f, 1.0f};
                    break;
                case sw::space::SegmentEnd::Impact:
                    eventColor = {1.0f, 0.25f, 0.2f, 1.0f};
                    break;
                case sw::space::SegmentEnd::SoiExit:
                    eventColor = {1.0f, 0.85f, 0.4f, 1.0f};
                    break;
                default:
                    hasEvent = false;
                    break;
                }
                if (hasEvent)
                {
                    sw::WorldVec3 eventRelative{};
                    sw::phys::kepler::evaluate(segment.orbit, segment.endTime,
                                               eventRelative);
                    plotDot(primaryPosition + eventRelative, eventColor, 3.0f);
                }
            }
        };
        plotPlan(m_prediction, false);
        plotPlan(m_nodePrediction, true);

        // The maneuver node itself: a large violet diamond at the burn point,
        // drawn around its primary's CURRENT position like every patch.
        if (m_nodeActive && m_nodePrimaryIndex >= 0)
        {
            plotDot(m_celestialIndex.positionAt(m_nodePrimaryIndex, time) +
                        m_nodeRelativePosition,
                    {0.75f, 0.4f, 1.0f, 1.0f}, 4.0f);
        }
    }

    void StarWorksGame::collectDrawItems(const sw::Camera& activeCamera, bool mapView)
    {
        m_drawItems.clear();
        m_drawItems.reserve(m_world.aliveCount() + 512);

        // Static star dome: CAMERA-CENTERED (no translation), so the stars
        // are parallax-free — an infinitely distant, never-changing sky to
        // orient by. One emissive mesh, one draw call.
        {
            sw::DrawItem stars{};
            stars.mesh = &m_meshes[m_starfieldMeshIndex];
            stars.transform = glm::scale(sw::Mat4{1.0f}, sw::Vec3{kStarDomeRadius});
            stars.boundsCenter = {0.0f, 0.0f, 0.0f};
            stars.boundsRadius = kStarDomeRadius;
            stars.tint = {1.0f, 1.0f, 1.0f, 2.0f};
            m_drawItems.push_back(stars);
        }

        // The sun's soft glow: two emissive radial-falloff discs, always
        // facing the camera, drawn in the transparent pass.
        if (const auto* sol = m_world.tryGetComponent<TransformComponent>(m_solEntity))
        {
            const sw::Vec3 toSol = sw::Vec3(sol->position - activeCamera.position());
            const sw::f32 distance = glm::length(toSol);
            if (distance > static_cast<sw::f32>(kSolRadius) * 3.0f)
            {
                const sw::Vec3 z = -toSol / distance; // disc normal, toward camera
                const sw::Vec3 reference =
                    (std::abs(z.y) < 0.99f) ? sw::Vec3{0, 1, 0} : sw::Vec3{1, 0, 0};
                const sw::Vec3 x = glm::normalize(glm::cross(reference, z));
                const sw::Vec3 yAxis = glm::cross(z, x);
                const sw::Mat4 basis{sw::Vec4(x, 0.0f), sw::Vec4(yAxis, 0.0f),
                                     sw::Vec4(z, 0.0f), sw::Vec4(toSol, 1.0f)};

                auto pushGlow = [&](sw::u32 meshIndex, sw::f32 radiusFactor) {
                    const sw::f32 radius =
                        static_cast<sw::f32>(kSolRadius) * radiusFactor;
                    sw::DrawItem glow{};
                    glow.mesh = &m_meshes[meshIndex];
                    glow.transform =
                        basis * glm::scale(sw::Mat4{1.0f}, sw::Vec3{radius});
                    glow.boundsCenter = toSol;
                    glow.boundsRadius = radius;
                    glow.tint = {1.0f, 1.0f, 1.0f, 1.0f};
                    glow.transparent = true;
                    m_drawItems.push_back(glow);
                };
                pushGlow(m_sunHaloMeshIndex, 7.5f);
                pushGlow(m_sunCoreMeshIndex, 2.1f);
            }
        }

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::f64 alpha64 = static_cast<sw::f64>(alpha);
        const sw::WorldVec3 cameraPosition = activeCamera.position();

        auto makeTransform = [&](const TransformComponent& transform,
                                 const PreviousTransformComponent& previous,
                                 sw::Vec3& outRelative) {
            const sw::WorldVec3 position =
                glm::mix(previous.position, transform.position, alpha64);
            const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);
            outRelative = sw::Vec3(position - cameraPosition);
            return glm::translate(sw::Mat4{1.0f}, outRelative) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{transform.uniformScale});
        };

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        MeshComponent>(
            [&](sw::ecs::Entity entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                MeshComponent& mesh) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                sw::DrawItem item{&m_meshes[mesh.meshIndex], model, relative,
                                  bounds.localRadius * transform.uniformScale};
                item.transparent = mesh.transparent != 0;

                // Reentry glow: the craft reddens with heating and turns
                // emissive (self-lit plasma sheath) when it gets severe.
                sw::f32 heat = 0.0f;
                if (entity == m_shipEntity) { heat = m_shipHeat; }
                else if (entity == m_capsuleEntity) { heat = m_capsuleHeat; }
                else if (const auto* part =
                             m_world.tryGetComponent<sw::parts::PartComponent>(entity);
                         part != nullptr && part->vessel == m_shipEntity)
                {
                    heat = m_shipHeat; // the whole rocket glows
                }
                if (heat > 0.0f)
                {
                    const sw::Vec3 glow =
                        glm::mix(sw::Vec3{1.0f, 1.0f, 1.0f},
                                 sw::Vec3{1.0f, 0.30f, 0.12f}, heat);
                    item.tint = {glow.r, glow.g, glow.b, heat > 0.55f ? 2.0f : 1.0f};
                }
                m_drawItems.push_back(item);
            });

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        CelestialLodComponent>(
            [&](sw::ecs::Entity entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                CelestialLodComponent& lod) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                const sw::f64 worldRadius = static_cast<sw::f64>(transform.uniformScale);
                const sw::f64 distance =
                    glm::length(transform.position - cameraPosition);
                const sw::u32 level = selectLodLevel(distance, worldRadius);
                sw::DrawItem item{&m_meshes[lod.meshIndex[level]], model, relative,
                                  bounds.localRadius * transform.uniformScale};
                if (entity == m_solEntity)
                {
                    // The star is self-lit (emissive tint convention).
                    item.tint = {1.0f, 0.96f, 0.82f, 2.0f};
                }
                m_drawItems.push_back(item);
            });

        // ---- procedural terrain patch (near the ground, not in map view) ------
        if (!mapView && m_terrainVisible && m_terrainMeshSlot != 0xFFFFFFFFu)
        {
            if (const auto* body =
                    m_world.tryGetComponent<TransformComponent>(m_terrainBody))
            {
                sw::WorldVec3 bodyPosition = body->position;
                sw::Quat bodyRotation = body->rotation;
                if (const auto* previous =
                        m_world.tryGetComponent<PreviousTransformComponent>(
                            m_terrainBody))
                {
                    bodyPosition = glm::mix(previous->position, body->position, alpha64);
                    bodyRotation =
                        glm::slerp(previous->rotation, body->rotation, alpha);
                }
                const sw::WorldVec3 originWorld =
                    bodyPosition + glm::dquat(bodyRotation) * m_terrainOriginLocal;
                const sw::Vec3 relative = sw::Vec3(originWorld - cameraPosition);
                sw::DrawItem item{};
                item.mesh = &m_meshes[m_terrainMeshSlot];
                item.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                                 glm::mat4_cast(bodyRotation);
                item.boundsCenter = relative;
                item.boundsRadius = static_cast<sw::f32>(m_terrainExtent * 1.8);
                m_drawItems.push_back(item);
            }
        }

        if (mapView)
        {
            const sw::f32 markerFactor =
                kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);

            m_world.forEach<TransformComponent, BoundsComponent, MapMarkerComponent>(
                [&](sw::ecs::Entity, TransformComponent& transform, BoundsComponent& bounds,
                    MapMarkerComponent& marker) {
                    const sw::WorldVec3 toCamera = cameraPosition - transform.position;
                    const sw::f64 distance = glm::length(toCamera);
                    if (distance < 1.0)
                    {
                        return;
                    }
                    const sw::f64 surfaceOffset =
                        static_cast<sw::f64>(bounds.localRadius * transform.uniformScale) *
                        1.05;
                    const sw::WorldVec3 beaconPosition =
                        transform.position + (toCamera / distance) * surfaceOffset;

                    const sw::f32 scale =
                        static_cast<sw::f32>(glm::length(beaconPosition - cameraPosition)) *
                        markerFactor;
                    const sw::Vec3 relative = sw::Vec3(beaconPosition - cameraPosition);
                    const sw::Mat4 model = glm::translate(sw::Mat4{1.0f}, relative) *
                                           glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                    m_drawItems.push_back(
                        {&m_meshes[m_markerMeshIndex], model, relative, scale,
                         {marker.color.r, marker.color.g, marker.color.b, 2.0f}});
                });

            collectMapTrajectories(activeCamera);
        }
        else
        {
            collectParticles(activeCamera);
        }

        collectHud();
    }

    void StarWorksGame::onRender()
    {
        if (m_editorMode)
        {
            // The hangar is its own little world: fixed light, no eclipse.
            renderer().setSunPosition({60.0f, 90.0f, 40.0f});
            renderer().setShadowSpheres({});
            collectHangarItems();
            renderer().renderFrame(m_hangarCamera, m_drawItems);
            return;
        }
        const sw::Camera& activeCamera = m_mapView ? m_mapCamera : m_camera;
        const sw::WorldVec3 cameraPosition = activeCamera.position();

        // Light comes from Sol's actual position (camera-relative), and
        // every celestial body except the star casts an analytic shadow —
        // no sunlight behind a planet.
        if (const auto* sol = m_world.tryGetComponent<TransformComponent>(m_solEntity))
        {
            renderer().setSunPosition(sw::Vec3(sol->position - cameraPosition));
        }
        std::array<sw::Renderer::ShadowSphere, sw::Renderer::kMaxShadowSpheres>
            occluders{};
        sw::u32 occluderCount = 0;
        for (sw::usize i = 0;
             i < m_celestialIndex.size() &&
             occluderCount < sw::Renderer::kMaxShadowSpheres;
             ++i)
        {
            const auto& body = m_celestialIndex.body(i);
            if (body.entity == m_solEntity)
            {
                continue;
            }
            if (const auto* bodyTransform =
                    m_world.tryGetComponent<TransformComponent>(body.entity))
            {
                occluders[occluderCount++] = {
                    sw::Vec3(bodyTransform->position - cameraPosition),
                    static_cast<sw::f32>(body.bodyRadius)};
            }
        }
        renderer().setShadowSpheres(
            std::span<const sw::Renderer::ShadowSphere>(occluders.data(),
                                                        occluderCount));

        collectDrawItems(activeCamera, m_mapView);
        renderer().renderFrame(activeCamera, m_drawItems);
    }
} // namespace game
