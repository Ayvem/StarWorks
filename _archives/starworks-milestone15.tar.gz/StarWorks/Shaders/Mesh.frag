#version 450

// ============================================================================
// Mesh.frag — Lambert diffuse + ambient, in linear space (sRGB swapchain
// performs the final gamma encoding). Placeholder until the PBR pipeline.
// ============================================================================

layout(set = 0, binding = 0) uniform CameraUniforms
{
    mat4 viewProjection;
    vec4 cameraPosition;    // xyz = world position
    vec4 sunPosition;       // xyz = camera-relative sun position, w = shadow count
    vec4 shadowSpheres[8];  // xyz = camera-relative center, w = radius
} uCamera;

layout(location = 0) in vec3 vWorldNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUv;
layout(location = 3) in vec3 vWorldPosition;

layout(location = 0) out vec4 outColor;

const vec3 kSunColor = vec3(1.0, 0.96, 0.9);
const vec3 kAmbient = vec3(0.03, 0.035, 0.05); // faint cold space ambient

void main()
{
    // EMISSIVE convention: alpha in (1, 2] marks self-lit geometry (the
    // star, beacons, trajectory dots, plasma, sun glow) — full color,
    // independent of the sun, with OPACITY = alpha - 1 (2.0 = opaque; the
    // interpolated 1..2 range gives soft radial glow falloffs for free).
    if (vColor.a > 1.0001)
    {
        outColor = vec4(vColor.rgb, clamp(vColor.a - 1.0, 0.0, 1.0));
        return;
    }

    const vec3 normal = normalize(vWorldNormal);

    // Light direction PER FRAGMENT from the star's actual position: Terra
    // and Mars are lit from genuinely different directions, and a station
    // module's day side is the side facing Sol — not a global constant.
    const vec3 toSun = uCamera.sunPosition.xyz - vWorldPosition;
    const float distanceToSun = length(toSun);
    const vec3 lightDir = toSun / max(distanceToSun, 1.0e-3);
    const float lambert = max(dot(normal, lightDir), 0.0);

    // Analytic eclipse: no light behind a planet. Ray fragment->sun tested
    // against each occluder sphere. Formulated around the FRAGMENT-to-center
    // vector m (small numbers), which stays numerically stable where naive
    // sun-distance math would lose the planet radius in f32 rounding.
    // A fragment ON an occluder is handled by the t > 1 gate: day side hits
    // behind the ray origin (t < 0), night side is already lambert-dark.
    float shadow = 1.0;
    const int shadowCount = int(uCamera.sunPosition.w);
    for (int i = 0; i < shadowCount; ++i)
    {
        const vec3 m = vWorldPosition - uCamera.shadowSpheres[i].xyz;
        const float r = uCamera.shadowSpheres[i].w;
        const float b = dot(m, lightDir);
        const float c = dot(m, m) - r * r;
        const float discriminant = b * b - c;
        if (discriminant > 0.0)
        {
            const float t = -b - sqrt(discriminant);
            if (t > 1.0 && t < distanceToSun)
            {
                shadow = 0.0;
                break;
            }
        }
    }

    const vec3 lit = vColor.rgb * (kAmbient + kSunColor * lambert * shadow);
    outColor = vec4(lit, vColor.a);
}
