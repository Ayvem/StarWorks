#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <algorithm>
#include <cmath>

namespace game
{
    namespace
    {
        // ---- real-world dimensions and gravity (meters, m^3/s^2) --------------
        constexpr sw::f64 kTerraRadius = 6.371e6;    // Earth
        constexpr sw::f64 kMuTerra = 3.986004418e14; // Earth GM
        constexpr sw::f64 kLunaRadius = 1.7374e6;    // Moon
        constexpr sw::f64 kMuLuna = 4.9048695e12;    // Moon GM
        constexpr sw::f64 kLunaDistance = 3.844e8;   // Earth-Moon distance
        constexpr sw::f64 kStationAltitude = 4.0e5;  // 400 km (LEO)
        constexpr sw::f64 kStationOrbitRadius = kTerraRadius + kStationAltitude;
        /// Mean anomaly placing an equatorial-circular object at world +Z.
        constexpr sw::f64 kStationPhase = 4.71238898038468986; // 3*pi/2

        constexpr sw::u32 kStationModuleCount = 8;

        /// Simulation bubble: only objects this close to the focus are
        /// really integrated; everything else stays on rails.
        constexpr sw::f64 kBubbleEnterRadius = 1.0e4; // 10 km
        constexpr sw::f64 kBubbleExitRadius = 1.5e4;  // 15 km (hysteresis)

        // Star map: constant on-screen marker size and zoom limits.
        constexpr sw::f32 kMarkerScreenFraction = 0.016f; // of vertical FOV extent
        constexpr sw::f64 kMapMinHeight = 2.0e7;
        constexpr sw::f64 kMapMaxHeight = 1.6e9;

        // ---- time warp -----------------------------------------------------------
        constexpr sw::f32 kWarpLadder[] = {1.0f,    2.0f,     5.0f,     10.0f,   50.0f,
                                           100.0f, 1000.0f, 10000.0f, 100000.0f};
        constexpr sw::u32 kWarpSteps = static_cast<sw::u32>(std::size(kWarpLadder));

        /// Highest warp factor allowed at a given altitude above the nearest
        /// body's surface — warping hard while skimming a planet is how you
        /// tunnel through it.
        [[nodiscard]] sw::f32 maxWarpForAltitude(sw::f64 altitudeMeters)
        {
            if (altitudeMeters < 1.2e5) { return 1.0f; }
            if (altitudeMeters < 3.0e5) { return 10.0f; }
            if (altitudeMeters < 1.0e6) { return 100.0f; }
            if (altitudeMeters < 5.0e6) { return 1000.0f; }
            if (altitudeMeters < 2.0e7) { return 10000.0f; }
            return 100000.0f;
        }

        /// Sphere LOD resolutions, most to least detailed (rings, segments).
        constexpr sw::u32 kLodRings[CelestialLodComponent::kLodLevels] = {64, 32, 16, 8, 6};
        constexpr sw::u32 kLodSegments[CelestialLodComponent::kLodLevels] = {96, 48, 24, 12, 9};

        /// LOD thresholds as fractions of the vertical FOV covered by the
        /// body's angular diameter (descending; below the last -> coarsest).
        constexpr sw::f32 kLodScreenFractions[CelestialLodComponent::kLodLevels - 1] = {
            0.5f, 0.15f, 0.04f, 0.008f};

        /// Half-diagonal of the unit cube: bounding sphere of cube meshes.
        constexpr sw::f32 kCubeBoundsRadius = 0.8660254f;

        /// Sun direction (toward the scene), shared with the renderer and
        /// with the marker full-bright trick below.
        constexpr sw::Vec3 kSunDirection{-0.45f, -0.35f, -0.82f};

        /// Assembles the player ship from box parts (hull, cockpit, engine
        /// block, two nacelles). Unit: meters; forward is -Z.
        [[nodiscard]] sw::MeshData buildShipMesh()
        {
            using PF = sw::PrimitiveFactory;
            sw::MeshData ship = PF::makeBox({3.0f, 1.6f, 8.0f}, {0.72f, 0.74f, 0.78f, 1.0f});
            PF::append(ship, PF::makeBox({1.6f, 1.0f, 2.2f}, {0.25f, 0.55f, 0.75f, 1.0f}),
                       {0.0f, 2.2f, -4.5f}); // cockpit
            PF::append(ship, PF::makeBox({2.2f, 1.2f, 1.6f}, {0.30f, 0.30f, 0.33f, 1.0f}),
                       {0.0f, 0.0f, 9.0f}); // engine block
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {4.0f, 0.0f, 2.0f}); // right nacelle
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {-4.0f, 0.0f, 2.0f}); // left nacelle
            return ship;
        }

        /// Star-map beacon: octahedron with all normals forced toward the
        /// sun so the lit shader renders it full-bright regardless of
        /// orientation. (Pragmatic until an unlit pipeline exists.)
        [[nodiscard]] sw::MeshData buildMarkerMesh()
        {
            sw::MeshData marker =
                sw::PrimitiveFactory::makeOctahedron(1.0f, {1.0f, 1.0f, 1.0f, 1.0f});
            const sw::Vec3 towardSun = -glm::normalize(kSunDirection);
            for (sw::Vertex& vertex : marker.vertices)
            {
                vertex.normal = towardSun;
            }
            return marker;
        }

        /// Deterministic pseudo-random in [0, 1).
        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        // Near plane 0.5 m (station scale), far 1e9 m (beyond the moon) —
        // usable together only thanks to reverse-Z.
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.5f, 1.0e9f);
        // Map camera: everything is far; generous near plane, far past Luna.
        m_mapCamera.setPerspective(sw::math::toRadians(60.0f), 1.0e5f, 4.0e9f);

        buildScene();

        // Start 2 km outside the station cluster, looking at it with the
        // planet filling the background.
        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};
        m_cameraController.setPose(stationCenter + sw::WorldVec3{0.0, 250.0, 2000.0}, 0.0f,
                                   -0.08f);

        // ---- simulation lanes ---------------------------------------------------
        m_physicsLane = m_simulation.findLane("Physics");
        m_physicsLane->scheduler().addSystem(std::make_unique<SnapshotSystem>());
        m_physicsLane->scheduler().addSystem(
            std::make_unique<sw::phys::GravityIntegrationSystem>());
        m_physicsLane->scheduler().addSystem(std::make_unique<ThrustSystem>());
        m_physicsLane->scheduler().addSystem(std::make_unique<SpinSystem>());
        m_physicsLane->scheduler().addSystem(std::make_unique<CelestialSpinSystem>());

        // Automation 5 Hz: production machines.
        auto& automation = m_simulation.findLane("Automation")->scheduler();
        automation.addSystem(std::make_unique<sw::factory::MinerSystem>());
        automation.addSystem(std::make_unique<sw::factory::RefinerySystem>());

        // Logistics 10 Hz: analytic rails refresh + bubble + item transfers.
        auto& logistics = m_simulation.findLane("Logistics")->scheduler();
        logistics.addSystem(std::make_unique<sw::phys::RailsSystem>(m_simulation));
        logistics.addSystem(std::make_unique<sw::factory::TransferSystem>());
        sw::phys::SimulationBubbleSystem::Config bubbleConfig{};
        bubbleConfig.enterRadius = kBubbleEnterRadius;
        bubbleConfig.exitRadius = kBubbleExitRadius;
        auto bubble = std::make_unique<sw::phys::SimulationBubbleSystem>(
            m_commands, m_simulation, bubbleConfig);
        m_bubbleSystem = bubble.get();
        logistics.addSystem(std::move(bubble));

        m_simulation.findLane("World")->scheduler().addSystem(
            std::make_unique<StatsSystem>());

        SW_LOG_INFO("Game", "Milestone 7 scene ready: {} entities, ship online",
                    m_world.aliveCount());
        SW_LOG_INFO("Game",
                    "Controls: Tab = pilot ship (W/S thrust, A/D yaw, arrows pitch, Q/E "
                    "roll, X kill rotation) | M = star map (wheel zooms) | free camera: "
                    "RMB look, WASD, Q/E, Shift, wheel | Space pause, 1/2/3 time scale, "
                    "Esc quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    CelestialLodComponent StarWorksGame::makeSphereLodSet(const sw::Vec4& color)
    {
        CelestialLodComponent lod{};
        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels; ++level)
        {
            lod.meshIndex[level] = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, kLodRings[level],
                                                   kLodSegments[level], color)));
        }
        return lod;
    }

    void StarWorksGame::buildScene()
    {
        // ---- meshes -------------------------------------------------------------
        const CelestialLodComponent terraLod =
            makeSphereLodSet({0.21f, 0.33f, 0.48f, 1.0f}); // oceanic blue-grey
        const CelestialLodComponent lunaLod =
            makeSphereLodSet({0.42f, 0.41f, 0.43f, 1.0f}); // regolith grey

        sw::u32 asteroidMeshId = 0;
        sw::f32 asteroidBoundsRadius = 2.5f;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f})));
            asteroidBoundsRadius = 1.0f;
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        const sw::u32 shipMeshId = registerMesh(renderer().createMesh(buildShipMesh()));
        m_markerMeshIndex = registerMesh(renderer().createMesh(buildMarkerMesh()));

        renderer().setSunDirection(kSunDirection);

        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};

        auto snapshotOf = [](const TransformComponent& transform) {
            return PreviousTransformComponent{transform.position, transform.rotation};
        };

        // ---- Terra (real radius, GM and sidereal rotation rate) ---------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {0.0, 0.0, 0.0};
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, terraLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.2921e-5f});
            m_world.addComponent(e,
                                 sw::phys::GravitySourceComponent{kMuTerra, kTerraRadius});
            m_world.addComponent(e, MapMarkerComponent{{0.35f, 0.65f, 1.0f, 1.0f}});
        }

        // ---- Luna ------------------------------------------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {kLunaDistance, 0.0, 0.0};
            transform.uniformScale = static_cast<sw::f32>(kLunaRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, lunaLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.66e-6f});
            m_world.addComponent(e, sw::phys::GravitySourceComponent{kMuLuna, kLunaRadius});
            m_world.addComponent(e, MapMarkerComponent{{0.75f, 0.75f, 0.78f, 1.0f}});
        }

        // ---- asteroid: dynamic body + MINING SITE ---------------------------------
        sw::ecs::Entity asteroidEntity{};
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{650.0, 120.0, -300.0};
            transform.uniformScale = 120.0f; // ~300 m rock
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{asteroidBoundsRadius});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.05f});
            m_world.addComponent(e, MapMarkerComponent{{0.85f, 0.65f, 0.35f, 1.0f}});

            const sw::f64 radius = glm::length(transform.position);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(
                e, sw::phys::DynamicBodyComponent{{speed, 0.0, 0.0}, 5.0e8});

            // The first machine of the game: a drill on the rock.
            sw::factory::InventoryComponent hopper{};
            hopper.volumeCapacityM3 = 40.0; // ~100 t of ore buffer
            m_world.addComponent(e, hopper);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 2.0, 0.0});
            asteroidEntity = e;
        }

        // ---- the player ship: dynamic, controllable, in formation ----------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{-250.0, 60.0, 400.0};
            transform.uniformScale = 1.0f; // mesh already in meters
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{13.0f}); // hull + nacelles
            m_world.addComponent(e, MeshComponent{shipMeshId});
            m_world.addComponent(e, MapMarkerComponent{{0.3f, 1.0f, 0.5f, 1.0f}});
            m_world.addComponent(e, ShipComponent{});
            m_world.addComponent(e, ShipControlsComponent{});

            const sw::f64 radius = glm::length(transform.position);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(
                e, sw::phys::DynamicBodyComponent{{speed, 0.0, 0.0}, 5.0e4}); // 50 t
            m_shipEntity = e;
        }

        // ---- station modules: shared circular orbit (rails), tiny offsets -------
        sw::ecs::Entity refineryEntity{};
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f64 offset =
                (static_cast<sw::f64>(i) / kStationModuleCount - 0.5) * 1.0e-4;
            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, {0.0, 0.0, 0.0},
                kStationOrbitRadius + (static_cast<sw::f64>(i) - 3.5) * 12.0,
                /*e=*/0.0, /*i=*/0.0, /*raan=*/0.0, /*argPeriapsis=*/0.0,
                /*M0=*/kStationPhase + offset, /*epoch=*/0.0);

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(orbit, 0.0, transform.position);
            transform.uniformScale = 30.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            m_world.addComponent(e, sw::phys::OnRailsComponent{orbit});
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f},
                                                  0.1f + hash01(i) * 0.1f});
            if (i == 0)
            {
                m_world.addComponent(e, MapMarkerComponent{{1.0f, 1.0f, 1.0f, 1.0f}});

                // Module 0 is the REFINERY: ore in (hauled from the
                // asteroid), iron out — with a realistic 90% yield.
                sw::factory::InventoryComponent tanks{};
                tanks.volumeCapacityM3 = 15.0;
                m_world.addComponent(e, tanks);
                m_world.addComponent(e, sw::factory::RefineryComponent{
                                            sw::res::Resource::IronOre,
                                            sw::res::Resource::Iron, 1.0, 0.9, 0.0});
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            asteroidEntity, sw::res::Resource::IronOre,
                                            1.5});
                refineryEntity = e;
            }
            else if (i == 1)
            {
                // Module 1 is the STORAGE DEPOT: pulls refined iron.
                sw::factory::InventoryComponent silo{};
                silo.volumeCapacityM3 = 60.0; // ~470 t of iron
                m_world.addComponent(e, silo);
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            refineryEntity, sw::res::Resource::Iron, 1.0});
            }
        }
    }

    void StarWorksGame::updateWarp()
    {
        // ---- ladder input ------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::Period) && m_warpIndex + 1 < kWarpSteps)
        {
            ++m_warpIndex;
        }
        if (input().wasKeyPressed(sw::KeyCode::Comma) && m_warpIndex > 0)
        {
            --m_warpIndex;
        }

        // ---- altitude limit: min altitude over every celestial body -----------
        const sw::WorldVec3 shipPosition =
            m_world.getComponent<TransformComponent>(m_shipEntity).position;
        sw::f64 minAltitude = 1.0e18;
        m_world.forEach<TransformComponent, sw::phys::GravitySourceComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                sw::phys::GravitySourceComponent& source) {
                const sw::f64 altitude =
                    glm::length(shipPosition - transform.position) - source.bodyRadius;
                minAltitude = std::min(minAltitude, altitude);
            });

        const sw::f32 maxAllowed = maxWarpForAltitude(minAltitude);
        while (m_warpIndex > 0 && kWarpLadder[m_warpIndex] > maxAllowed)
        {
            --m_warpIndex; // auto-downshift when diving toward a body
            SW_LOG_INFO("Game", "Warp limited to x{:g} (altitude {:.0f} km)",
                        kWarpLadder[m_warpIndex], minAltitude / 1000.0);
        }

        // ---- apply: warp == rails-only simulation -------------------------------
        const sw::f32 warpFactor = kWarpLadder[m_warpIndex];
        m_simulation.setTimeScale(warpFactor);
        // During warp only analytic orbits advance (exact at any speed);
        // Newtonian integration resumes when the player drops back to x1.
        m_bubbleSystem->setForceRails(m_warpIndex > 0);
    }

    void StarWorksGame::updateShipControls()
    {
        auto& controls = m_world.getComponent<ShipControlsComponent>(m_shipEntity);
        controls = {};
        if (!m_shipMode || m_mapView || m_warpIndex > 0)
        {
            return; // engines idle when not piloting (or while warping on rails)
        }

        if (input().isKeyDown(sw::KeyCode::W)) { controls.thrustAxis += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::S)) { controls.thrustAxis -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Up)) { controls.rotationInput.x -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Down)) { controls.rotationInput.x += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::A)) { controls.rotationInput.y += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::D)) { controls.rotationInput.y -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Q)) { controls.rotationInput.z += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::E)) { controls.rotationInput.z -= 1.0f; }
        controls.killRotation = input().isKeyDown(sw::KeyCode::X) ? 1u : 0u;
    }

    void StarWorksGame::updateChaseCamera()
    {
        const auto& transform = m_world.getComponent<TransformComponent>(m_shipEntity);
        const auto& previous =
            m_world.getComponent<PreviousTransformComponent>(m_shipEntity);

        // Follow the INTERPOLATED ship pose so the chase view is as smooth
        // as the rendered ship itself.
        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::WorldVec3 shipPosition =
            glm::mix(previous.position, transform.position, static_cast<sw::f64>(alpha));
        const sw::Quat shipRotation =
            glm::slerp(previous.rotation, transform.rotation, alpha);

        const sw::WorldVec3 cameraPosition =
            shipPosition + sw::WorldVec3(shipRotation * sw::Vec3{0.0f, 12.0f, 42.0f});
        m_camera.setPosition(cameraPosition);

        // Look at the ship with the ship's own up vector.
        const sw::Vec3 forward =
            glm::normalize(sw::Vec3(shipPosition - cameraPosition));
        const sw::Vec3 shipUp = shipRotation * sw::Vec3{0.0f, 1.0f, 0.0f};
        const sw::Vec3 right = glm::normalize(glm::cross(forward, shipUp));
        const sw::Vec3 up = glm::cross(right, forward);
        // Camera convention: -Z forward => third basis column is -forward.
        m_camera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        // --- mode toggles -------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::M))
        {
            m_mapView = !m_mapView;
            SW_LOG_INFO("Game", "Star map {}", m_mapView ? "opened" : "closed");
        }
        if (input().wasKeyPressed(sw::KeyCode::Tab))
        {
            m_shipMode = !m_shipMode;
            if (!m_shipMode)
            {
                // Hand the free camera over exactly where the chase camera
                // was: derive yaw/pitch from the current forward vector.
                const sw::Vec3 forward = m_camera.forward();
                const sw::f32 yaw = std::atan2(-forward.x, -forward.z);
                const sw::f32 pitch =
                    std::asin(std::clamp(forward.y, -1.0f, 1.0f));
                m_cameraController.setPose(m_camera.position(), yaw, pitch);
            }
            SW_LOG_INFO("Game", "{}", m_shipMode ? "Piloting ship (chase camera)"
                                                 : "Free camera");
        }
        if (input().wasKeyPressed(sw::KeyCode::Space))
        {
            m_simulation.setPaused(!m_simulation.isPaused());
            SW_LOG_INFO("Game", "Simulation {}", m_simulation.isPaused() ? "paused" : "resumed");
        }

        // Time warp ladder (','/'.') with altitude-based limiting.
        updateWarp();

        // --- per-mode camera & controls ------------------------------------------
        if (m_mapView)
        {
            // Wheel zooms the map; the view camera hovers above the system.
            const sw::f32 scroll = input().scrollDeltaY();
            if (scroll != 0.0f)
            {
                m_mapHeightMeters = std::clamp(
                    m_mapHeightMeters * std::pow(1.3, static_cast<sw::f64>(-scroll)),
                    kMapMinHeight, kMapMaxHeight);
            }
            m_mapCamera.setPosition({0.0, m_mapHeightMeters, 0.0});
            // Look straight down (-Y), with -Z at the top of the screen:
            // camX->+X, camY->-Z, camZ->+Y.
            m_mapCamera.setOrientation(glm::quat_cast(
                sw::Mat3{{1, 0, 0}, {0, 0, -1}, {0, 1, 0}}));
            m_mapCamera.setAspectRatio(renderer().aspectRatio());
        }
        else if (!m_shipMode)
        {
            m_cameraController.update(input(), window(), deltaSeconds);
        }
        m_camera.setAspectRatio(renderer().aspectRatio());

        updateShipControls();

        // The bubble follows what the player controls.
        const sw::WorldVec3 focus =
            m_shipMode ? m_world.getComponent<TransformComponent>(m_shipEntity).position
                       : m_camera.position();
        m_bubbleSystem->setFocus(focus);

        // Wall-clock time goes in; lanes tick at their own fixed rates.
        m_simulation.advance(m_world, deltaSeconds, &threadPool());

        // Apply deferred structural changes (bubble conversions).
        m_commands.playback(m_world);

        // Chase camera reads the post-tick ship state.
        if (m_shipMode && !m_mapView)
        {
            updateChaseCamera();
        }

        // --- periodic statistics ------------------------------------------------
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastStatsLogSeconds > 5.0)
        {
            m_lastStatsLogSeconds = now;
            const sw::RenderStats& stats = renderer().stats();
            SW_LOG_INFO("Game",
                        "render: {} submitted, {} culled, {} instances in {} draw calls | "
                        "sim: {} dynamic / {} rails, warp x{:g} ({:.0f} FPS, prepare "
                        "{:.1f} ms)",
                        stats.itemsSubmitted, stats.itemsCulled, stats.instancesDrawn,
                        stats.drawCalls, m_world.count<sw::phys::DynamicBodyComponent>(),
                        m_world.count<sw::phys::OnRailsComponent>(),
                        kWarpLadder[m_warpIndex], clock().smoothedFps(),
                        stats.cpuPrepareMs);
        }
    }

    sw::u32 StarWorksGame::selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const
    {
        // Fraction of the vertical FOV covered by the body's angular diameter.
        const sw::f64 clampedDistance = std::max(distance, worldRadius * 1.0001);
        const sw::f64 angularDiameter = 2.0 * std::atan(worldRadius / clampedDistance);
        const sw::f32 fraction =
            static_cast<sw::f32>(angularDiameter) / m_camera.verticalFov();

        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels - 1; ++level)
        {
            if (fraction >= kLodScreenFractions[level])
            {
                return level;
            }
        }
        return CelestialLodComponent::kLodLevels - 1;
    }

    void StarWorksGame::collectDrawItems(const sw::Camera& activeCamera, bool mapView)
    {
        m_drawItems.clear();
        m_drawItems.reserve(m_world.aliveCount() + 8);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::f64 alpha64 = static_cast<sw::f64>(alpha);
        const sw::WorldVec3 cameraPosition = activeCamera.position();

        // Shared path: interpolate in f64, narrow to camera-relative f32.
        // (Rails entities have Previous == current: the mix is a no-op.)
        auto makeTransform = [&](const TransformComponent& transform,
                                 const PreviousTransformComponent& previous,
                                 sw::Vec3& outRelative) {
            const sw::WorldVec3 position =
                glm::mix(previous.position, transform.position, alpha64);
            const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);
            outRelative = sw::Vec3(position - cameraPosition);
            return glm::translate(sw::Mat4{1.0f}, outRelative) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{transform.uniformScale});
        };

        // ---- fixed-mesh entities ------------------------------------------------
        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        MeshComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                MeshComponent& mesh) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                m_drawItems.push_back({&m_meshes[mesh.meshIndex], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        // ---- celestial bodies: LOD by angular size ---------------------------------
        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        CelestialLodComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                CelestialLodComponent& lod) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);

                const sw::f64 worldRadius = static_cast<sw::f64>(transform.uniformScale);
                const sw::f64 distance =
                    glm::length(transform.position - cameraPosition);
                const sw::u32 level = selectLodLevel(distance, worldRadius);

                m_drawItems.push_back({&m_meshes[lod.meshIndex[level]], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        // ---- star-map beacons: constant on-screen size --------------------------
        if (mapView)
        {
            const sw::f32 markerFactor =
                kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);

            m_world.forEach<TransformComponent, BoundsComponent, MapMarkerComponent>(
                [&](sw::ecs::Entity, TransformComponent& transform, BoundsComponent& bounds,
                    MapMarkerComponent& marker) {
                    const sw::WorldVec3 toCamera = cameraPosition - transform.position;
                    const sw::f64 distance = glm::length(toCamera);
                    if (distance < 1.0)
                    {
                        return;
                    }
                    // Lift the beacon out of the object's own surface toward
                    // the camera so it never hides inside a planet.
                    const sw::f64 surfaceOffset =
                        static_cast<sw::f64>(bounds.localRadius * transform.uniformScale) *
                        1.05;
                    const sw::WorldVec3 beaconPosition =
                        transform.position + (toCamera / distance) * surfaceOffset;

                    const sw::f32 scale =
                        static_cast<sw::f32>(glm::length(beaconPosition - cameraPosition)) *
                        markerFactor;
                    const sw::Vec3 relative = sw::Vec3(beaconPosition - cameraPosition);
                    const sw::Mat4 model = glm::translate(sw::Mat4{1.0f}, relative) *
                                           glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                    m_drawItems.push_back(
                        {&m_meshes[m_markerMeshIndex], model, relative, scale, marker.color});
                });
        }
    }

    void StarWorksGame::onRender()
    {
        const sw::Camera& activeCamera = m_mapView ? m_mapCamera : m_camera;
        collectDrawItems(activeCamera, m_mapView);
        renderer().renderFrame(activeCamera, m_drawItems);
    }
} // namespace game
