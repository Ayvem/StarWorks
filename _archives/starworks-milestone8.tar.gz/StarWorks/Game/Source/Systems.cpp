#include "Systems.hpp"

#include <algorithm>
#include <cmath>

namespace game
{
    void SnapshotSystem::update(sw::ecs::World& world, sw::f32 /*deltaSeconds*/)
    {
        world.forEach<TransformComponent, PreviousTransformComponent,
                      sw::phys::DynamicBodyComponent>(
            [](sw::ecs::Entity, const TransformComponent& transform,
               PreviousTransformComponent& previous, sw::phys::DynamicBodyComponent&) {
                previous.position = transform.position;
                previous.rotation = transform.rotation;
            });
    }

    void SpinSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, SpinComponent, sw::phys::DynamicBodyComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           const SpinComponent& spin, sw::phys::DynamicBodyComponent&) {
                const sw::Quat step =
                    glm::angleAxis(spin.radiansPerSecond * deltaSeconds, spin.axis);
                transform.rotation = glm::normalize(step * transform.rotation);
            });
    }

    void CelestialSpinSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, PreviousTransformComponent, SpinComponent,
                      sw::phys::GravitySourceComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           PreviousTransformComponent& previous, const SpinComponent& spin,
                           sw::phys::GravitySourceComponent&) {
                previous.position = transform.position;
                previous.rotation = transform.rotation;
                const sw::Quat step =
                    glm::angleAxis(spin.radiansPerSecond * deltaSeconds, spin.axis);
                transform.rotation = glm::normalize(step * transform.rotation);
            });
    }

    void ThrustSystem::update(sw::ecs::World& world, sw::f32 deltaSeconds)
    {
        world.forEach<TransformComponent, sw::phys::DynamicBodyComponent, ShipComponent,
                      ShipControlsComponent>(
            [deltaSeconds](sw::ecs::Entity, TransformComponent& transform,
                           sw::phys::DynamicBodyComponent& body, ShipComponent& ship,
                           const ShipControlsComponent& controls) {
                // ---- attitude (RCS): integrate body-frame angular velocity --
                ship.angularVelocity += controls.rotationInput * ship.angularAccel *
                                        deltaSeconds;
                if (controls.killRotation != 0)
                {
                    const sw::f32 decay =
                        std::max(0.0f, 1.0f - 3.0f * deltaSeconds);
                    ship.angularVelocity *= decay;
                }
                const sw::f32 angularSpeed = glm::length(ship.angularVelocity);
                if (angularSpeed > ship.maxAngularSpeed)
                {
                    ship.angularVelocity *= ship.maxAngularSpeed / angularSpeed;
                }
                if (angularSpeed > 1.0e-6f)
                {
                    const sw::Vec3 axis = ship.angularVelocity / angularSpeed;
                    const sw::Quat step =
                        glm::angleAxis(angularSpeed * deltaSeconds, axis);
                    // Body-frame rotation: post-multiply.
                    transform.rotation = glm::normalize(transform.rotation * step);
                }

                // ---- main engine: F = ma along the ship's forward (-Z) ------
                if (controls.thrustAxis != 0.0f)
                {
                    const sw::Vec3 forward = transform.rotation * sw::math::kWorldForward;
                    const sw::f64 acceleration =
                        static_cast<sw::f64>(controls.thrustAxis) * ship.mainThrustNewtons /
                        body.mass;
                    body.velocity += sw::WorldVec3(forward) * acceleration *
                                     static_cast<sw::f64>(deltaSeconds);
                }
            });
    }

    void StatsSystem::update(sw::ecs::World& world, sw::f32 /*deltaSeconds*/)
    {
        // Every 30 ticks of the 1 Hz World lane ≈ every 30 simulated seconds.
        if ((m_ticks++ % 30) != 0)
        {
            return;
        }

        sw::f64 totalMined = 0.0;
        sw::f64 totalRefined = 0.0;
        sw::f64 storedOre = 0.0;
        sw::f64 storedIron = 0.0;
        world.forEach<sw::factory::MinerComponent>(
            [&](sw::ecs::Entity, sw::factory::MinerComponent& miner) {
                totalMined += miner.totalMined;
            });
        world.forEach<sw::factory::RefineryComponent>(
            [&](sw::ecs::Entity, sw::factory::RefineryComponent& refinery) {
                totalRefined += refinery.totalRefined;
            });
        world.forEach<sw::factory::InventoryComponent>(
            [&](sw::ecs::Entity, sw::factory::InventoryComponent& inventory) {
                storedOre += sw::factory::inventoryCount(inventory,
                                                         sw::res::Resource::IronOre);
                storedIron +=
                    sw::factory::inventoryCount(inventory, sw::res::Resource::Iron);
            });

        SW_LOG_INFO("Game",
                    "[World lane] tick {}: {} entities ({} dynamic, {} rails) | factory: "
                    "mined {:.1f} u, refined {:.1f} u, stored ore {:.1f} u / iron {:.1f} u",
                    m_ticks - 1, world.aliveCount(),
                    world.count<sw::phys::DynamicBodyComponent>(),
                    world.count<sw::phys::OnRailsComponent>(), totalMined, totalRefined,
                    storedOre, storedIron);
    }
} // namespace game
