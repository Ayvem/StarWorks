// ============================================================================
// PhysicsTests.cpp — Kepler orbits, Newtonian integrator and the
// simulation bubble (rails <-> dynamic conversions).
// ============================================================================

#include "TestFramework.hpp"

#include <ECS/CommandBuffer.hpp>
#include <ECS/World.hpp>
#include <Physics/Kepler.hpp>
#include <Physics/PhysicsSystems.hpp>
#include <Scene/TransformComponents.hpp>
#include <Simulation/Simulation.hpp>

#include <cmath>

namespace
{
    constexpr sw::f64 kMuTerra = 3.986004418e14;
    constexpr sw::f64 kLeoRadius = 6.771e6; // 400 km altitude

    [[nodiscard]] sw::f64 relativeError(const sw::WorldVec3& a, const sw::WorldVec3& b,
                                        sw::f64 scale)
    {
        return glm::length(a - b) / scale;
    }
} // namespace

using namespace sw;
using namespace sw::phys;

SW_TEST(KeplerCircularOrbitGeometry)
{
    const KeplerOrbit orbit = kepler::fromElements(kMuTerra, {0.0, 0.0, 0.0}, kLeoRadius,
                                                   0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

    // Radius stays constant; a quarter period advances the anomaly by 90°.
    const f64 period = kepler::period(orbit);
    SW_CHECK(std::abs(period - 5546.0) < 10.0); // real LEO period ~92.4 min

    WorldVec3 p0{};
    WorldVec3 pQuarter{};
    WorldVec3 v0{};
    kepler::evaluate(orbit, 0.0, p0, &v0);
    kepler::evaluate(orbit, period * 0.25, pQuarter);

    SW_CHECK(std::abs(glm::length(p0) - kLeoRadius) / kLeoRadius < 1.0e-12);
    SW_CHECK(std::abs(glm::length(pQuarter) - kLeoRadius) / kLeoRadius < 1.0e-9);
    // Perpendicular position vectors after a quarter of a circular orbit.
    SW_CHECK(std::abs(glm::dot(glm::normalize(p0), glm::normalize(pQuarter))) < 1.0e-6);
    // Circular speed = sqrt(mu/r) ~ 7.67 km/s in LEO.
    SW_CHECK(std::abs(glm::length(v0) - kepler::circularOrbitSpeed(kMuTerra, kLeoRadius)) <
             1.0e-6);
    // Full period returns to the start.
    WorldVec3 pFull{};
    kepler::evaluate(orbit, period, pFull);
    SW_CHECK(relativeError(pFull, p0, kLeoRadius) < 1.0e-9);
}

SW_TEST(KeplerStateVectorRoundTrip)
{
    // An inclined, eccentric orbit built from elements...
    const KeplerOrbit original = kepler::fromElements(
        kMuTerra, {0.0, 0.0, 0.0}, 8.0e6, 0.3, 0.4, 1.1, 2.2, 0.7, /*epoch=*/100.0);

    // ...sampled mid-flight into state vectors...
    const f64 sampleTime = 1234.5;
    WorldVec3 position{};
    WorldVec3 velocity{};
    kepler::evaluate(original, sampleTime, position, &velocity);

    // ...must reconstruct an orbit with identical future motion.
    KeplerOrbit rebuilt{};
    SW_CHECK(kepler::fromStateVectors(kMuTerra, {0.0, 0.0, 0.0}, position, velocity,
                                      sampleTime, rebuilt));
    SW_CHECK(std::abs(rebuilt.semiMajorAxis - original.semiMajorAxis) /
                 original.semiMajorAxis <
             1.0e-9);
    SW_CHECK(std::abs(rebuilt.eccentricity - original.eccentricity) < 1.0e-9);

    for (const f64 probeTime : {sampleTime, sampleTime + 500.0, sampleTime + 4321.0})
    {
        WorldVec3 expected{};
        WorldVec3 actual{};
        kepler::evaluate(original, probeTime, expected);
        kepler::evaluate(rebuilt, probeTime, actual);
        SW_CHECK(relativeError(actual, expected, original.semiMajorAxis) < 1.0e-8);
    }
}

SW_TEST(KeplerRejectsUnboundTrajectories)
{
    KeplerOrbit orbit{};
    const WorldVec3 position{kLeoRadius, 0.0, 0.0};
    // Twice escape velocity: clearly hyperbolic.
    const f64 escape = std::sqrt(2.0 * kMuTerra / kLeoRadius);
    SW_CHECK(!kepler::fromStateVectors(kMuTerra, {0.0, 0.0, 0.0}, position,
                                       {0.0, 0.0, 2.0 * escape}, 0.0, orbit));
}

SW_TEST(GravityIntegratorHoldsACircularOrbit)
{
    ecs::World world;

    // Terra at the origin.
    {
        const ecs::Entity terra = world.createEntity();
        world.addComponent(terra, TransformComponent{});
        world.addComponent(terra, GravitySourceComponent{kMuTerra});
    }

    // Dynamic body with exact circular velocity.
    const ecs::Entity body = world.createEntity();
    {
        TransformComponent transform{};
        transform.position = {0.0, 0.0, kLeoRadius};
        world.addComponent(body, transform);
        const f64 speed = kepler::circularOrbitSpeed(kMuTerra, kLeoRadius);
        world.addComponent(body, DynamicBodyComponent{{speed, 0.0, 0.0}, 1000.0});
    }

    GravityIntegrationSystem gravity;
    constexpr f32 kDt = 0.02f; // Physics lane step
    constexpr int kTicks = 5000; // 100 simulated seconds
    for (int i = 0; i < kTicks; ++i)
    {
        gravity.update(world, kDt);
    }

    // Semi-implicit Euler on a circular orbit: radius drift must stay tiny.
    const f64 radius = glm::length(world.getComponent<TransformComponent>(body).position);
    SW_CHECK(std::abs(radius - kLeoRadius) / kLeoRadius < 5.0e-4);

    // Specific orbital energy must match the circular value closely.
    const auto& dynamicBody = world.getComponent<DynamicBodyComponent>(body);
    const f64 energy =
        0.5 * glm::dot(dynamicBody.velocity, dynamicBody.velocity) - kMuTerra / radius;
    const f64 expectedEnergy = -kMuTerra / (2.0 * kLeoRadius);
    SW_CHECK(std::abs(energy - expectedEnergy) / std::abs(expectedEnergy) < 1.0e-3);
}

SW_TEST(BubbleConvertsRailsToDynamicAndBack)
{
    ecs::World world;
    ecs::EntityCommandBuffer commands;
    sim::Simulation simulation({{"Logistics", 10.0f, 4}});

    // Terra.
    {
        const ecs::Entity terra = world.createEntity();
        world.addComponent(terra, TransformComponent{});
        world.addComponent(terra, GravitySourceComponent{kMuTerra});
    }

    // On-rails object at world +Z LEO.
    const KeplerOrbit orbit =
        kepler::fromElements(kMuTerra, {0.0, 0.0, 0.0}, kLeoRadius, 0.0, 0.0, 0.0, 0.0,
                             /*M0=*/4.71238898038468986, 0.0);
    const ecs::Entity object = world.createEntity();
    {
        TransformComponent transform{};
        kepler::evaluate(orbit, 0.0, transform.position);
        world.addComponent(object, transform);
        world.addComponent(object, PreviousTransformComponent{});
        world.addComponent(object, OnRailsComponent{orbit});
    }

    SimulationBubbleSystem::Config config{};
    config.enterRadius = 1.0e4;
    config.exitRadius = 1.5e4;

    auto rails = std::make_unique<RailsSystem>(simulation);
    auto bubble = std::make_unique<SimulationBubbleSystem>(commands, simulation, config);
    auto* bubblePtr = bubble.get();
    auto& scheduler = simulation.findLane("Logistics")->scheduler();
    scheduler.addSystem(std::move(rails));
    scheduler.addSystem(std::move(bubble));

    // ---- focus near the object: it must become dynamic --------------------
    const WorldVec3 objectPosition =
        world.getComponent<TransformComponent>(object).position;
    bubblePtr->setFocus(objectPosition + WorldVec3{500.0, 0.0, 0.0});

    simulation.advance(world, 0.1f, nullptr); // one Logistics tick
    commands.playback(world);

    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));
    SW_CHECK(!world.hasComponent<OnRailsComponent>(object));
    // Continuity: the hand-off position equals the ANALYTIC position at the
    // conversion time (the object legitimately moved ~767 m during the
    // 0.1 s Logistics tick), and the velocity is the circular speed.
    const auto& converted = world.getComponent<DynamicBodyComponent>(object);
    SW_CHECK(std::abs(glm::length(converted.velocity) -
                      kepler::circularOrbitSpeed(kMuTerra, kLeoRadius)) < 1.0);
    WorldVec3 expectedAtConversion{};
    kepler::evaluate(orbit, simulation.simulatedSeconds(), expectedAtConversion);
    SW_CHECK(relativeError(world.getComponent<TransformComponent>(object).position,
                           expectedAtConversion, kLeoRadius) < 1.0e-9);

    // ---- focus far away: it must go back on rails ---------------------------
    bubblePtr->setFocus(objectPosition + WorldVec3{1.0e6, 0.0, 0.0});
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);

    SW_CHECK(!world.hasComponent<DynamicBodyComponent>(object));
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));

    // The rebuilt rails orbit must continue the motion seamlessly: its
    // evaluation now must match the object's current transform.
    const auto& backOnRails = world.getComponent<OnRailsComponent>(object);
    WorldVec3 railsPosition{};
    kepler::evaluate(backOnRails.orbit, simulation.simulatedSeconds(), railsPosition);
    SW_CHECK(relativeError(railsPosition,
                           world.getComponent<TransformComponent>(object).position,
                           kLeoRadius) < 1.0e-6);

    // ---- force-rails (time warp): dynamic INSIDE the bubble still railifies
    bubblePtr->setFocus(world.getComponent<TransformComponent>(object).position);
    simulation.advance(world, 0.1f, nullptr); // converts back to dynamic
    commands.playback(world);
    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));

    bubblePtr->setForceRails(true);
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));
    SW_CHECK(!world.hasComponent<DynamicBodyComponent>(object));

    // While forced, nothing may come off the rails even at distance zero.
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<OnRailsComponent>(object));

    // Releasing force-rails lets the bubble re-acquire it.
    bubblePtr->setForceRails(false);
    bubblePtr->setFocus(world.getComponent<TransformComponent>(object).position);
    simulation.advance(world, 0.1f, nullptr);
    commands.playback(world);
    SW_CHECK(world.hasComponent<DynamicBodyComponent>(object));
}
