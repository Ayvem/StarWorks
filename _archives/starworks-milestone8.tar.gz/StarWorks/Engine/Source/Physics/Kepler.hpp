#pragma once

// ============================================================================
// Physics/Kepler.hpp
// Analytic two-body (Keplerian) orbits — the "on rails" half of the physics
// architecture.
//
// An on-rails object stores ONLY its orbital elements; its position is a
// closed-form function of time. No per-tick integration, no error
// accumulation, evaluation on demand at any frequency. This is what makes
// tens of thousands of orbiting objects affordable: the engine truly
// simulates only what is near the player (see BubbleSystem), everything
// else is a cheap analytic evaluation.
//
// Conventions (engine-wide): +Y is "north", the reference plane is XZ.
// Elliptic orbits only (e < 1); the bubble keeps hyperbolic escapes in the
// dynamic set instead of putting them on rails.
//
// Storage layout: the perifocal basis (P toward periapsis, Q 90° ahead in
// the direction of motion) is PRECOMPUTED, so evaluate() is just a Kepler
// solve + two trig calls + a linear combination.
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Math.hpp"

#include <cmath>
#include <type_traits>

namespace sw::phys
{
    struct KeplerOrbit
    {
        f64 mu = 0.0;                 // gravitational parameter GM of the primary
        f64 semiMajorAxis = 0.0;      // meters
        f64 eccentricity = 0.0;       // [0, 1)
        f64 meanMotion = 0.0;         // rad/s (precomputed sqrt(mu/a^3))
        f64 meanAnomalyAtEpoch = 0.0; // radians
        f64 epochSeconds = 0.0;       // simulation time of the elements
        WorldVec3 center{0.0};        // primary body position (static for now)
        WorldVec3 basisP{1.0, 0.0, 0.0}; // unit vector toward periapsis
        WorldVec3 basisQ{0.0, 0.0, 1.0}; // unit vector 90 deg ahead (motion side)
    };
    static_assert(std::is_trivially_copyable_v<KeplerOrbit>);

    namespace kepler
    {
        /// Builds an orbit from classical elements (angles in radians,
        /// Y-up convention: inclination vs the XZ plane, RAAN about +Y from
        /// +X, argument of periapsis in-plane from the ascending node).
        [[nodiscard]] KeplerOrbit fromElements(f64 mu, const WorldVec3& center,
                                               f64 semiMajorAxis, f64 eccentricity,
                                               f64 inclination, f64 raan,
                                               f64 argumentOfPeriapsis, f64 meanAnomalyAtEpoch,
                                               f64 epochSeconds);

        /// Builds an orbit from a position/velocity pair (relative motion
        /// around `center`) at time `epochSeconds`. Requires a bound
        /// (elliptic) trajectory; returns false without touching `out` for
        /// parabolic/hyperbolic states.
        [[nodiscard]] bool fromStateVectors(f64 mu, const WorldVec3& center,
                                            const WorldVec3& position,
                                            const WorldVec3& velocity, f64 epochSeconds,
                                            KeplerOrbit& out);

        /// Position (and optionally velocity) at absolute simulation time.
        void evaluate(const KeplerOrbit& orbit, f64 timeSeconds, WorldVec3& outPosition,
                      WorldVec3* outVelocity = nullptr);

        [[nodiscard]] f64 period(const KeplerOrbit& orbit);

        /// Circular-orbit speed at radius r around a body of parameter mu.
        [[nodiscard]] inline f64 circularOrbitSpeed(f64 mu, f64 radius)
        {
            return std::sqrt(mu / radius);
        }
    } // namespace kepler
} // namespace sw::phys
