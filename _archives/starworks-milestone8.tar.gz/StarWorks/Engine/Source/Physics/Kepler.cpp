#include "Physics/Kepler.hpp"

#include "Core/Assert.hpp"

#include <glm/gtc/quaternion.hpp>

#include <algorithm>

namespace sw::phys::kepler
{
    namespace
    {
        constexpr f64 kTwoPi = 6.283185307179586476925286766559;

        [[nodiscard]] f64 wrapAngle(f64 angle)
        {
            angle = std::fmod(angle, kTwoPi);
            return (angle < 0.0) ? angle + kTwoPi : angle;
        }

        /// Solves Kepler's equation M = E - e*sin(E) for the eccentric
        /// anomaly E (Newton-Raphson; converges in < 8 iterations for e<0.97).
        [[nodiscard]] f64 solveEccentricAnomaly(f64 meanAnomaly, f64 eccentricity)
        {
            const f64 m = wrapAngle(meanAnomaly);
            // Good starting guess: E = M for small e, pi for very eccentric.
            f64 eccentricAnomaly = (eccentricity < 0.8) ? m : 3.14159265358979323846;

            for (int iteration = 0; iteration < 16; ++iteration)
            {
                const f64 f = eccentricAnomaly - eccentricity * std::sin(eccentricAnomaly) - m;
                const f64 fPrime = 1.0 - eccentricity * std::cos(eccentricAnomaly);
                const f64 step = f / fPrime;
                eccentricAnomaly -= step;
                if (std::abs(step) < 1.0e-14)
                {
                    break;
                }
            }
            return eccentricAnomaly;
        }
    } // namespace

    KeplerOrbit fromElements(f64 mu, const WorldVec3& center, f64 semiMajorAxis,
                             f64 eccentricity, f64 inclination, f64 raan,
                             f64 argumentOfPeriapsis, f64 meanAnomalyAtEpoch, f64 epochSeconds)
    {
        SW_ASSERT(mu > 0.0 && semiMajorAxis > 0.0 && eccentricity >= 0.0 && eccentricity < 1.0,
                  "Invalid Kepler elements (mu={}, a={}, e={})", mu, semiMajorAxis,
                  eccentricity);

        // Y-up frame: reference plane XZ, node measured about +Y from +X.
        const glm::dvec3 up{0.0, 1.0, 0.0};
        const glm::dvec3 xAxis{1.0, 0.0, 0.0};

        const glm::dquat nodeRotation = glm::angleAxis(raan, up);
        const glm::dvec3 nodeDirection = nodeRotation * xAxis;
        const glm::dquat inclinationRotation = glm::angleAxis(inclination, nodeDirection);
        const glm::dvec3 orbitNormal = inclinationRotation * up;
        const glm::dquat periapsisRotation = glm::angleAxis(argumentOfPeriapsis, orbitNormal);

        KeplerOrbit orbit{};
        orbit.mu = mu;
        orbit.semiMajorAxis = semiMajorAxis;
        orbit.eccentricity = eccentricity;
        orbit.meanMotion = std::sqrt(mu / (semiMajorAxis * semiMajorAxis * semiMajorAxis));
        orbit.meanAnomalyAtEpoch = wrapAngle(meanAnomalyAtEpoch);
        orbit.epochSeconds = epochSeconds;
        orbit.center = center;
        orbit.basisP = periapsisRotation * nodeDirection;
        orbit.basisQ = glm::cross(orbitNormal, orbit.basisP);
        return orbit;
    }

    bool fromStateVectors(f64 mu, const WorldVec3& center, const WorldVec3& position,
                          const WorldVec3& velocity, f64 epochSeconds, KeplerOrbit& out)
    {
        const WorldVec3 r = position - center;
        const f64 radius = glm::length(r);
        const f64 speedSq = glm::dot(velocity, velocity);
        if (radius <= 0.0 || mu <= 0.0)
        {
            return false;
        }

        // Bound orbit check via specific orbital energy.
        const f64 energy = 0.5 * speedSq - mu / radius;
        if (energy >= -1.0e-9) // parabolic/hyperbolic: keep it dynamic
        {
            return false;
        }
        const f64 semiMajorAxis = -mu / (2.0 * energy);

        const WorldVec3 angularMomentum = glm::cross(r, velocity);
        const f64 hLength = glm::length(angularMomentum);
        if (hLength <= 0.0) // radial trajectory: not representable
        {
            return false;
        }
        const WorldVec3 orbitNormal = angularMomentum / hLength;

        // Eccentricity vector points toward periapsis.
        const WorldVec3 eccVector =
            glm::cross(velocity, angularMomentum) / mu - r / radius;
        const f64 eccentricity = glm::length(eccVector);
        if (eccentricity >= 1.0)
        {
            return false;
        }

        // Perifocal basis straight from the vectors (no angle round-trips):
        // near-circular orbits use the current radial direction as P, which
        // pins the true anomaly to ~0 at epoch.
        const WorldVec3 basisP =
            (eccentricity > 1.0e-9) ? eccVector / eccentricity : r / radius;
        const WorldVec3 basisQ = glm::cross(orbitNormal, basisP);

        // True anomaly at epoch, with quadrant from the radial velocity.
        const f64 cosNu = std::clamp(glm::dot(basisP, r / radius), -1.0, 1.0);
        f64 trueAnomaly = std::acos(cosNu);
        if (glm::dot(r, velocity) < 0.0)
        {
            trueAnomaly = kTwoPi - trueAnomaly;
        }

        // True -> eccentric -> mean anomaly.
        const f64 halfNu = 0.5 * trueAnomaly;
        const f64 eccentricAnomaly =
            2.0 * std::atan2(std::sqrt(1.0 - eccentricity) * std::sin(halfNu),
                             std::sqrt(1.0 + eccentricity) * std::cos(halfNu));
        const f64 meanAnomaly =
            eccentricAnomaly - eccentricity * std::sin(eccentricAnomaly);

        out.mu = mu;
        out.semiMajorAxis = semiMajorAxis;
        out.eccentricity = eccentricity;
        out.meanMotion =
            std::sqrt(mu / (semiMajorAxis * semiMajorAxis * semiMajorAxis));
        out.meanAnomalyAtEpoch = wrapAngle(meanAnomaly);
        out.epochSeconds = epochSeconds;
        out.center = center;
        out.basisP = basisP;
        out.basisQ = basisQ;
        return true;
    }

    void evaluate(const KeplerOrbit& orbit, f64 timeSeconds, WorldVec3& outPosition,
                  WorldVec3* outVelocity)
    {
        const f64 meanAnomaly =
            orbit.meanAnomalyAtEpoch + orbit.meanMotion * (timeSeconds - orbit.epochSeconds);
        const f64 eccentricAnomaly = solveEccentricAnomaly(meanAnomaly, orbit.eccentricity);

        const f64 cosE = std::cos(eccentricAnomaly);
        const f64 e = orbit.eccentricity;

        // True anomaly and radius from the eccentric anomaly.
        const f64 halfE = 0.5 * eccentricAnomaly;
        const f64 trueAnomaly = 2.0 * std::atan2(std::sqrt(1.0 + e) * std::sin(halfE),
                                                 std::sqrt(1.0 - e) * std::cos(halfE));
        const f64 radius = orbit.semiMajorAxis * (1.0 - e * cosE);

        const f64 cosNu = std::cos(trueAnomaly);
        const f64 sinNu = std::sin(trueAnomaly);

        outPosition = orbit.center + orbit.basisP * (radius * cosNu) +
                      orbit.basisQ * (radius * sinNu);

        if (outVelocity != nullptr)
        {
            const f64 semiLatus = orbit.semiMajorAxis * (1.0 - e * e);
            const f64 speedFactor = std::sqrt(orbit.mu / semiLatus);
            *outVelocity = orbit.basisP * (-speedFactor * sinNu) +
                           orbit.basisQ * (speedFactor * (e + cosNu));
        }
    }

    f64 period(const KeplerOrbit& orbit)
    {
        return kTwoPi / orbit.meanMotion;
    }
} // namespace sw::phys::kepler
