#pragma once

// ============================================================================
// Math/Noise.hpp
// Deterministic 3D value noise + fBm (header-only).
//
// THE single source of procedural randomness for planetary content: the
// terrain heightfield (collision!), the globe vertex colors and the cloud
// coverage all sample these functions — same seed, same result, forever.
// No std::rand, no state: pure functions of (position, seed).
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Math.hpp"

#include <cmath>

namespace sw::math
{
    [[nodiscard]] inline f32 hashToUnitFloat(u32 x)
    {
        x ^= 2747636419u;
        x *= 2654435769u;
        x ^= x >> 16;
        x *= 2654435769u;
        x ^= x >> 16;
        return static_cast<f32>(x & 0xFFFFFF) / 16777216.0f;
    }

    [[nodiscard]] inline f32 latticeHash(i32 x, i32 y, i32 z, u32 seed)
    {
        const u32 h = static_cast<u32>(x) * 374761393u +
                      static_cast<u32>(y) * 668265263u +
                      static_cast<u32>(z) * 1274126177u + seed * 2246822519u;
        return hashToUnitFloat(h);
    }

    /// Trilinear value noise in [0,1), C1-smooth (smoothstep fade).
    [[nodiscard]] inline f32 valueNoise3(const Vec3& p, u32 seed)
    {
        const Vec3 cell = glm::floor(p);
        const Vec3 f = p - cell;
        const Vec3 u = f * f * (3.0f - 2.0f * f);
        const i32 x = static_cast<i32>(cell.x);
        const i32 y = static_cast<i32>(cell.y);
        const i32 z = static_cast<i32>(cell.z);

        auto corner = [&](i32 dx, i32 dy, i32 dz) {
            return latticeHash(x + dx, y + dy, z + dz, seed);
        };
        const f32 x00 = glm::mix(corner(0, 0, 0), corner(1, 0, 0), u.x);
        const f32 x10 = glm::mix(corner(0, 1, 0), corner(1, 1, 0), u.x);
        const f32 x01 = glm::mix(corner(0, 0, 1), corner(1, 0, 1), u.x);
        const f32 x11 = glm::mix(corner(0, 1, 1), corner(1, 1, 1), u.x);
        return glm::mix(glm::mix(x00, x10, u.y), glm::mix(x01, x11, u.y), u.z);
    }

    /// Fractal Brownian motion, ~[0,1).
    [[nodiscard]] inline f32 fbm3(const Vec3& p, i32 octaves, u32 seed)
    {
        f32 sum = 0.0f;
        f32 amplitude = 0.5f;
        Vec3 q = p;
        for (i32 i = 0; i < octaves; ++i)
        {
            sum += amplitude * valueNoise3(q, seed + static_cast<u32>(i) * 101u);
            q *= 2.03f;
            amplitude *= 0.5f;
        }
        return sum;
    }
} // namespace sw::math
