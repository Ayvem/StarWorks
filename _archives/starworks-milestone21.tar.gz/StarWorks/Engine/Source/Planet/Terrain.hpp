#pragma once

// ============================================================================
// Planet/Terrain.hpp
// Procedural planetary terrain as an ANALYTIC HEIGHTFIELD (header-only).
//
// The elevation is a pure function of (body-fixed direction, parameters):
// no stored grid, no streaming state. That single property is what makes
// terrain collision exact and cheap — physics samples the very same
// function the renderer displaces its patches with, at any point, at any
// resolution, and a landed base sits on the same mountain after a save,
// a warp, or a year of drift.
//
// Directions are in the BODY'S ROTATING FRAME (the terrain spins with the
// planet). Elevation is meters ABOVE the sea-level sphere (bodyRadius);
// oceans clamp to 0 — the sphere itself is the water surface.
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Noise.hpp"

#include <type_traits>

namespace sw::planet
{
    struct TerrainComponent
    {
        u32 seed = 1337;
        i32 octaves = 5;
        f32 frequency = 2.3f;   // fBm frequency on the unit sphere
        f32 amplitude = 9000.0f; // peak elevation scale, meters
        /// fBm value at the coastline; below it the terrain is ocean
        /// (elevation 0). 0 = no ocean (airless worlds).
        f32 seaLevelFraction = 0.50f;
        Vec3 noiseOffset{7.31f, 1.17f, 4.73f}; // decorrelates worlds
    };
    static_assert(std::is_trivially_copyable_v<TerrainComponent>);

    /// Elevation (meters above the sea-level sphere) at a unit direction in
    /// the body's rotating frame. Squaring the land fraction gives wide
    /// coastal plains and steep peaks.
    [[nodiscard]] inline f64 terrainElevation(const TerrainComponent& terrain,
                                              const Vec3& unitDirectionBodyFrame)
    {
        const f32 n = math::fbm3(unitDirectionBodyFrame * terrain.frequency +
                                     terrain.noiseOffset,
                                 terrain.octaves, terrain.seed);
        const f32 land = (n - terrain.seaLevelFraction) /
                         (1.0f - terrain.seaLevelFraction);
        if (land <= 0.0f)
        {
            return 0.0; // ocean: the sphere IS the surface
        }
        return static_cast<f64>(land * land * terrain.amplitude);
    }
} // namespace sw::planet
