#pragma once

// ============================================================================
// Factory/FactoryComponents.hpp
// Industrial automation components. All machines work on INVENTORIES: a
// fixed number of typed slots bounded by real VOLUME (m^3), so denser
// refined materials pack tighter than raw ore — matter is conserved and
// physical from the first machine.
//
//  MinerComponent    : extracts a resource into the entity's own inventory.
//  RefineryComponent : converts input units to output units (with losses)
//                      inside the entity's own inventory.
//  ItemLinkComponent : pulls a resource from ANOTHER entity's inventory
//                      into this one (drone/conveyor abstraction; becomes a
//                      real conveyor entity chain in a later milestone).
//
// Machines run in the Automation lane (5 Hz), transfers in the Logistics
// lane (10 Hz) — production keeps working under time warp at the lanes'
// real-time budget, and never depends on rendering.
// ============================================================================

#include "Core/Types.hpp"
#include "ECS/Entity.hpp"
#include "Resources/ResourceTypes.hpp"

#include <type_traits>

namespace sw::factory
{
    inline constexpr u32 kInventorySlots = 8;

    struct InventorySlot
    {
        res::Resource resource = res::Resource::Count; // Count == empty slot
        f64 units = 0.0;
    };

    struct InventoryComponent
    {
        InventorySlot slots[kInventorySlots]{};
        f64 volumeCapacityM3 = 10.0;
    };

    struct MinerComponent
    {
        res::Resource output = res::Resource::IronOre;
        f64 unitsPerSecond = 1.0;
        f64 totalMined = 0.0; // lifetime statistics
    };

    struct RefineryComponent
    {
        res::Resource input = res::Resource::IronOre;
        res::Resource output = res::Resource::Iron;
        f64 inputUnitsPerSecond = 1.0;
        f64 conversionRatio = 0.9; // output units per input unit
        f64 totalRefined = 0.0;    // lifetime statistics
    };

    struct ItemLinkComponent
    {
        ecs::Entity source{};
        res::Resource resource = res::Resource::IronOre;
        f64 unitsPerSecond = 1.0;
    };

    static_assert(std::is_trivially_copyable_v<InventoryComponent>);
    static_assert(std::is_trivially_copyable_v<MinerComponent>);
    static_assert(std::is_trivially_copyable_v<RefineryComponent>);
    static_assert(std::is_trivially_copyable_v<ItemLinkComponent>);

    // ---- inventory operations (free functions, unit-tested) -----------------

    /// Total occupied volume in m^3.
    [[nodiscard]] f64 inventoryVolume(const InventoryComponent& inventory);

    /// Units of one resource currently stored.
    [[nodiscard]] f64 inventoryCount(const InventoryComponent& inventory,
                                     res::Resource resource);

    /// Adds up to `units`; bounded by volume capacity and free slots.
    /// Returns the units actually accepted.
    f64 inventoryAdd(InventoryComponent& inventory, res::Resource resource, f64 units);

    /// Removes up to `units`. Returns the units actually removed.
    f64 inventoryRemove(InventoryComponent& inventory, res::Resource resource, f64 units);
} // namespace sw::factory
