#pragma once

// ============================================================================
// Factory/FactorySystems.hpp
// Production and logistics systems. See FactoryComponents.hpp for the data
// model. Lane placement (game decides): Miner/Refinery in Automation
// (5 Hz), Transfer in Logistics (10 Hz).
// ============================================================================

#include "ECS/System.hpp"
#include "Factory/FactoryComponents.hpp"

namespace sw::factory
{
    /// Extracts the miner's output resource into its own inventory.
    class MinerSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "MinerSystem"; }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<MinerComponent>()
                .write<InventoryComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };

    /// Converts input units to output units inside the same inventory.
    /// Output volume is reserved before input is consumed: a full tank
    /// stalls the refinery instead of destroying matter.
    class RefinerySystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "RefinerySystem"; }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<RefineryComponent>()
                .write<InventoryComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };

    /// Pulls resources across entity links (drone/conveyor abstraction).
    class TransferSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "TransferSystem"; }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .read<ItemLinkComponent>()
                .write<InventoryComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };
} // namespace sw::factory
