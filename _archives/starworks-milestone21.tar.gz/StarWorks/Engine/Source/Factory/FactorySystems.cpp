#include "Factory/FactorySystems.hpp"

#include "ECS/World.hpp"

#include <algorithm>

namespace sw::factory
{
    void MinerSystem::update(ecs::World& world, f32 deltaSeconds)
    {
        const f64 dt = static_cast<f64>(deltaSeconds);
        world.forEach<MinerComponent, InventoryComponent>(
            [dt](ecs::Entity, MinerComponent& miner, InventoryComponent& inventory) {
                const f64 mined =
                    inventoryAdd(inventory, miner.output, miner.unitsPerSecond * dt);
                miner.totalMined += mined;
            });
    }

    void RefinerySystem::update(ecs::World& world, f32 deltaSeconds)
    {
        const f64 dt = static_cast<f64>(deltaSeconds);
        world.forEach<RefineryComponent, InventoryComponent>(
            [dt](ecs::Entity, RefineryComponent& refinery, InventoryComponent& inventory) {
                const f64 wantedInput = refinery.inputUnitsPerSecond * dt;
                const f64 availableInput =
                    std::min(wantedInput, inventoryCount(inventory, refinery.input));
                if (availableInput <= 0.0)
                {
                    return; // starved
                }

                // Reserve output space FIRST: never destroy matter.
                const f64 wantedOutput = availableInput * refinery.conversionRatio;
                const f64 acceptedOutput =
                    inventoryAdd(inventory, refinery.output, wantedOutput);
                if (acceptedOutput <= 0.0)
                {
                    return; // output full: stall
                }

                const f64 consumedInput = acceptedOutput / refinery.conversionRatio;
                inventoryRemove(inventory, refinery.input, consumedInput);
                refinery.totalRefined += acceptedOutput;
            });
    }

    void TransferSystem::update(ecs::World& world, f32 deltaSeconds)
    {
        const f64 dt = static_cast<f64>(deltaSeconds);
        world.forEach<ItemLinkComponent, InventoryComponent>(
            [&world, dt](ecs::Entity, ItemLinkComponent& link,
                         InventoryComponent& destination) {
                auto* source = world.tryGetComponent<InventoryComponent>(link.source);
                if (source == nullptr)
                {
                    return; // source gone (destroyed): link idles
                }

                const f64 wanted = std::min(link.unitsPerSecond * dt,
                                            inventoryCount(*source, link.resource));
                if (wanted <= 0.0)
                {
                    return;
                }
                // Accept first (volume-bound), then take exactly that much.
                const f64 accepted = inventoryAdd(destination, link.resource, wanted);
                if (accepted > 0.0)
                {
                    inventoryRemove(*source, link.resource, accepted);
                }
            });
    }
} // namespace sw::factory
