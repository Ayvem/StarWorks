#version 450

// ============================================================================
// Mesh.frag — the M21 visual overhaul.
//
//  - Blinn-Phong SPECULAR + fresnel sheen, driven by a per-vertex material
//    channel (uv.x = specular strength, uv.y = glossiness) — oceans glint,
//    hulls shine, regolith stays matte (uv = 0).
//  - AERIAL PERSPECTIVE: exponential distance fog toward the horizon color
//    + sky-scattered ambient, both fed per frame by the game from the
//    camera's altitude and the local sun elevation (sunsets included).
//  - ATMOSPHERE SHELLS (instance tint alpha > 2.5): fresnel limb glow —
//    a bright rim of air when seen from orbit, a glowing horizon band
//    from inside — lit day-side by the real sun direction.
//  - Filmic tonemapping (ACES fit) with a soft exposure, in linear space
//    (the sRGB swapchain still performs the final gamma encoding).
//
// Analytic eclipse shadows (no light behind a planet) are unchanged.
// ============================================================================

layout(set = 0, binding = 0) uniform CameraUniforms
{
    mat4 viewProjection;
    vec4 cameraPosition;    // xyz = world position
    vec4 sunPosition;       // xyz = camera-relative sun position, w = shadow count
    vec4 shadowSpheres[8];  // xyz = camera-relative center, w = radius
    vec4 fogColorDensity;   // xyz = horizon color, w = fog density
    vec4 skyAmbient;        // xyz = sky-scattered ambient
} uCamera;

layout(location = 0) in vec3 vWorldNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUv;
layout(location = 3) in vec3 vWorldPosition;
layout(location = 4) flat in float vTintAlpha;

layout(location = 0) out vec4 outColor;

const vec3 kSunColor = vec3(1.0, 0.96, 0.9);
const vec3 kAmbient = vec3(0.020, 0.024, 0.035); // faint cold space ambient

// ACES filmic fit (Narkowicz). Input linear, output [0,1] linear.
vec3 tonemapAces(vec3 color)
{
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((color * (a * color + b)) / (color * (c * color + d) + e), 0.0, 1.0);
}

void main()
{
    const vec3 viewDir = normalize(-vWorldPosition); // camera at the origin
    const float fragmentDistance = length(vWorldPosition);

    // ---- ATMOSPHERE SHELL material (instance tint alpha > 2.5) ---------------
    // Fresnel limb glow: air is thickest along grazing view rays — the rim
    // of a planet from orbit, the horizon band from inside. Day side lit
    // by the true sun direction with a soft wrap (twilight ring).
    if (vTintAlpha > 2.5)
    {
        const vec3 normal = normalize(vWorldNormal);
        const vec3 lightDir = normalize(uCamera.sunPosition.xyz - vWorldPosition);
        const float baseAlpha = clamp(vColor.a / 3.0, 0.0, 1.0);
        const float grazing = 1.0 - abs(dot(normal, viewDir));
        const float limb = pow(clamp(grazing, 0.0, 1.0), 2.4);
        const float dayWrap = clamp(dot(normal, lightDir) * 0.65 + 0.42, 0.0, 1.0);
        const vec3 air = vColor.rgb * (0.22 + 1.15 * dayWrap);
        const float alpha = baseAlpha * (0.30 + 1.55 * limb) * (0.15 + 0.85 * dayWrap);
        outColor = vec4(tonemapAces(air), clamp(alpha, 0.0, 1.0));
        return;
    }

    // ---- EMISSIVE convention: alpha in (1, 2] = self-lit --------------------
    // (star, beacons, plasma, glow discs). Opacity = alpha - 1; the 1..2
    // interpolation range gives soft radial falloffs for free.
    if (vColor.a > 1.0001)
    {
        outColor = vec4(tonemapAces(vColor.rgb),
                        clamp(vColor.a - 1.0, 0.0, 1.0));
        return;
    }

    const vec3 normal = normalize(vWorldNormal);

    // Light direction PER FRAGMENT from the star's actual position.
    const vec3 toSun = uCamera.sunPosition.xyz - vWorldPosition;
    const float distanceToSun = length(toSun);
    const vec3 lightDir = toSun / max(distanceToSun, 1.0e-3);
    const float lambert = max(dot(normal, lightDir), 0.0);

    // Analytic eclipse: no light behind a planet (stable small-number form).
    float shadow = 1.0;
    const int shadowCount = int(uCamera.sunPosition.w);
    for (int i = 0; i < shadowCount; ++i)
    {
        const vec3 m = vWorldPosition - uCamera.shadowSpheres[i].xyz;
        const float r = uCamera.shadowSpheres[i].w;
        const float b = dot(m, lightDir);
        const float c = dot(m, m) - r * r;
        const float discriminant = b * b - c;
        if (discriminant > 0.0)
        {
            const float t = -b - sqrt(discriminant);
            if (t > 1.0 && t < distanceToSun)
            {
                shadow = 0.0;
                break;
            }
        }
    }

    // ---- material: uv.x = specular strength, uv.y = glossiness ----------------
    const float specularStrength = clamp(vUv.x, 0.0, 1.0);
    const float glossiness = clamp(vUv.y, 0.0, 1.0);
    vec3 specular = vec3(0.0);
    if (specularStrength > 0.001 && lambert > 0.0)
    {
        const vec3 halfway = normalize(lightDir + viewDir);
        const float exponent = mix(12.0, 260.0, glossiness);
        const float highlight = pow(max(dot(normal, halfway), 0.0), exponent);
        // Fresnel-boosted at grazing angles (ocean sun glitter).
        const float fresnel =
            0.35 + 0.65 * pow(1.0 - max(dot(normal, viewDir), 0.0), 3.0);
        specular = kSunColor * (highlight * specularStrength * fresnel * shadow);
    }

    // Ambient = cold space floor + the game's sky-scattered light; a hint
    // of fill from the sky color on upward-facing surfaces.
    const vec3 ambient = kAmbient + uCamera.skyAmbient.xyz;
    const vec3 lit =
        vColor.rgb * (ambient + kSunColor * (lambert * shadow)) + specular;

    // ---- aerial perspective ----------------------------------------------------
    // Exponential extinction toward the horizon color. Density comes from
    // the camera's air density; the color already encodes day/sunset/night.
    const float fogDensity = uCamera.fogColorDensity.w;
    vec3 finalColor = lit;
    if (fogDensity > 0.0)
    {
        const float fogFactor =
            1.0 - exp(-fogDensity * fragmentDistance);
        finalColor = mix(lit, uCamera.fogColorDensity.xyz, clamp(fogFactor, 0.0, 0.97));
    }

    vec3 graded = tonemapAces(finalColor);
    // ACES desaturates the mids a touch: restore a little chroma.
    const float luminance = dot(graded, vec3(0.2126, 0.7152, 0.0722));
    graded = clamp(mix(vec3(luminance), graded, 1.14), 0.0, 1.0);
    outColor = vec4(graded, vColor.a);
}
