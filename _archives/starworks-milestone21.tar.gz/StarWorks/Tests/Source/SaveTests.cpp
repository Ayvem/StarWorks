// ============================================================================
// SaveTests.cpp — binary layer, world snapshot round trip, post-load
// determinism of the factory simulation, and surface anchoring.
// ============================================================================

#include "TestFramework.hpp"

#include <ECS/World.hpp>
#include <Factory/FactorySystems.hpp>
#include <Physics/PhysicsSystems.hpp>
#include <Save/Snapshot.hpp>
#include <Scene/TransformComponents.hpp>
#include <Simulation/Simulation.hpp>

#include <cmath>

using namespace sw;
using sw::res::Resource;

namespace
{
    struct RefHolder
    {
        ecs::Entity target{};
        int value = 0;
    };

    save::Schema makeTestSchema()
    {
        save::Schema schema;
        schema.registerComponent<TransformComponent>("sw.Transform", 1);
        schema.registerComponent<PreviousTransformComponent>("sw.PreviousTransform", 1);
        schema.registerComponent<phys::SurfaceAnchorComponent>("phys.SurfaceAnchor", 1);
        schema.registerComponent<phys::GravitySourceComponent>("phys.GravitySource", 1);
        schema.registerComponent<factory::InventoryComponent>("factory.Inventory", 1);
        schema.registerComponent<factory::MinerComponent>("factory.Miner", 1);
        schema.registerComponent<factory::RefineryComponent>("factory.Refinery", 1);
        schema.registerComponent<factory::ItemLinkComponent>("factory.ItemLink", 1);
        schema.registerComponent<RefHolder>("test.RefHolder", 1);
        return schema;
    }
} // namespace

SW_TEST(BinaryWriterReaderRoundTripAndBounds)
{
    ser::BinaryWriter writer;
    writer.write<u32>(0xC0FFEE01);
    writer.write<f64>(3.14159);
    writer.writeString("StarWorks");
    writer.write<ecs::Entity>({42, 7});

    ser::BinaryReader reader(writer.bytes());
    SW_CHECK_EQ(reader.read<u32>(), 0xC0FFEE01u);
    SW_CHECK_EQ(reader.read<f64>(), 3.14159);
    SW_CHECK(reader.readString() == "StarWorks");
    const auto entity = reader.read<ecs::Entity>();
    SW_CHECK(entity.index == 42 && entity.generation == 7);
    SW_CHECK_EQ(reader.remaining(), 0u);

    // Overrun must throw, not read garbage.
    bool threw = false;
    try
    {
        (void)reader.read<u32>();
    }
    catch (const Exception&)
    {
        threw = true;
    }
    SW_CHECK(threw);
}

SW_TEST(WorldSnapshotPreservesEntitiesGenerationsAndReferences)
{
    const save::Schema schema = makeTestSchema();

    ecs::World world;
    // Force generation churn so the snapshot must preserve generations.
    const ecs::Entity dead1 = world.createEntity();
    const ecs::Entity dead2 = world.createEntity();
    world.destroyEntity(dead1);
    world.destroyEntity(dead2);

    const ecs::Entity target = world.createEntity(); // recycled index, gen>0
    {
        TransformComponent transform{};
        transform.position = {1.0e6, -2.0e6, 3.0e6};
        world.addComponent(target, transform);
    }
    const ecs::Entity holder = world.createEntity();
    world.addComponent(holder, RefHolder{target, 1234});

    // ---- save -> fresh world -> verify ------------------------------------
    ser::BinaryWriter writer;
    save::saveWorld(world, schema, writer);

    ecs::World loaded;
    ser::BinaryReader reader(writer.bytes());
    save::loadWorld(loaded, schema, reader);

    SW_CHECK_EQ(loaded.aliveCount(), 2u);
    SW_CHECK(loaded.isAlive(target)); // same index AND generation
    SW_CHECK(loaded.isAlive(holder));
    SW_CHECK(!loaded.isAlive(dead1)); // stale handles stay stale

    const auto& restoredRef = loaded.getComponent<RefHolder>(holder);
    SW_CHECK(restoredRef.value == 1234);
    SW_CHECK(restoredRef.target == target);
    // The reference must actually resolve in the loaded world.
    SW_CHECK(loaded.isAlive(restoredRef.target));
    SW_CHECK(std::abs(loaded.getComponent<TransformComponent>(restoredRef.target).position.z -
                      3.0e6) < 1.0e-9);

    // New entities after load must not collide with restored ones.
    const ecs::Entity fresh = loaded.createEntity();
    SW_CHECK(loaded.isAlive(fresh));
    SW_CHECK(loaded.isAlive(target));
    SW_CHECK(loaded.aliveCount() == 3u);
}

SW_TEST(FactorySimulationIsDeterministicAcrossSaveLoad)
{
    const save::Schema schema = makeTestSchema();

    // Build a mining->refining->hauling chain, run it, save it MID-RUN.
    auto buildChain = [](ecs::World& world, ecs::Entity& outDepot) {
        const ecs::Entity rock = world.createEntity();
        factory::InventoryComponent hopper{};
        hopper.volumeCapacityM3 = 10.0;
        world.addComponent(rock, hopper);
        world.addComponent(rock, factory::MinerComponent{Resource::IronOre, 2.0, 0.0});

        const ecs::Entity refinery = world.createEntity();
        factory::InventoryComponent tanks{};
        tanks.volumeCapacityM3 = 10.0;
        world.addComponent(refinery, tanks);
        world.addComponent(refinery, factory::RefineryComponent{
                                         Resource::IronOre, Resource::Iron, 1.0, 0.9, 0.0});
        world.addComponent(refinery,
                           factory::ItemLinkComponent{rock, Resource::IronOre, 1.5});

        const ecs::Entity depot = world.createEntity();
        factory::InventoryComponent silo{};
        silo.volumeCapacityM3 = 10.0;
        world.addComponent(depot, silo);
        world.addComponent(depot, factory::ItemLinkComponent{refinery, Resource::Iron, 1.0});
        outDepot = depot;
    };
    auto makeSim = [] {
        auto simulation = std::make_unique<sim::Simulation>(
            std::vector<sim::LaneConfig>{{"Logistics", 10.0f, 8}, {"Automation", 5.0f, 8}});
        simulation->findLane("Automation")
            ->scheduler()
            .addSystem(std::make_unique<factory::MinerSystem>());
        simulation->findLane("Automation")
            ->scheduler()
            .addSystem(std::make_unique<factory::RefinerySystem>());
        simulation->findLane("Logistics")
            ->scheduler()
            .addSystem(std::make_unique<factory::TransferSystem>());
        return simulation;
    };

    ecs::World original;
    ecs::Entity depot{};
    buildChain(original, depot);
    auto simulationA = makeSim();

    for (int i = 0; i < 100; ++i) // 12.5 s, mid-production
    {
        simulationA->advance(original, 0.125f, nullptr);
    }

    // Snapshot world + simulation clocks.
    ser::BinaryWriter writer;
    save::saveWorld(original, schema, writer);
    save::saveSimulation(*simulationA, writer);

    ecs::World restored;
    auto simulationB = makeSim();
    ser::BinaryReader reader(writer.bytes());
    save::loadWorld(restored, schema, reader);
    save::loadSimulation(*simulationB, reader);

    // Run BOTH for the same further time with identical slicing.
    for (int i = 0; i < 100; ++i)
    {
        simulationA->advance(original, 0.125f, nullptr);
        simulationB->advance(restored, 0.125f, nullptr);
    }

    // Bitwise-equal factory outcome: same iron in the depot, same totals.
    const f64 ironA = factory::inventoryCount(
        original.getComponent<factory::InventoryComponent>(depot), Resource::Iron);
    const f64 ironB = factory::inventoryCount(
        restored.getComponent<factory::InventoryComponent>(depot), Resource::Iron);
    SW_CHECK(ironA > 5.0);   // production really happened
    SW_CHECK(ironA == ironB); // EXACT determinism, not approximate
}

SW_TEST(SurfaceAnchorCoRotatesAndSurvivesSnapshot)
{
    const save::Schema schema = makeTestSchema();

    ecs::World world;
    const ecs::Entity planet = world.createEntity();
    {
        TransformComponent transform{}; // identity rotation at origin
        world.addComponent(planet, transform);
        world.addComponent(planet, phys::GravitySourceComponent{1.0e14, 1.0e6});
    }
    const ecs::Entity base = world.createEntity();
    {
        world.addComponent(base, TransformComponent{});
        world.addComponent(base, PreviousTransformComponent{});
        world.addComponent(base, phys::SurfaceAnchorComponent{planet, {0.0, 0.0, 1.0e6}});
    }

    phys::SurfaceAnchorSystem anchorSystem;

    // Rotate the planet a quarter turn around +Y: the base must follow to
    // the rotated surface point (+Z -> +X for a -90°? verify via the quat).
    auto& planetTransform = world.getComponent<TransformComponent>(planet);
    planetTransform.rotation = glm::angleAxis(math::kHalfPi, Vec3{0.0f, 1.0f, 0.0f});
    anchorSystem.update(world, 0.02f);

    const WorldVec3 expected =
        glm::dquat(planetTransform.rotation) * WorldVec3{0.0, 0.0, 1.0e6};
    const WorldVec3 actual = world.getComponent<TransformComponent>(base).position;
    SW_CHECK(glm::length(actual - expected) < 0.5); // f32 quat: sub-meter

    // Snapshot and make sure the ANCHOR (not the world position) is what
    // persists: rotate further after load, the base keeps following.
    ser::BinaryWriter writer;
    save::saveWorld(world, schema, writer);
    ecs::World loaded;
    ser::BinaryReader reader(writer.bytes());
    save::loadWorld(loaded, schema, reader);

    auto& loadedPlanet = loaded.getComponent<TransformComponent>(planet);
    loadedPlanet.rotation = glm::angleAxis(math::kPi, Vec3{0.0f, 1.0f, 0.0f});
    anchorSystem.update(loaded, 0.02f);

    const WorldVec3 expectedAfter =
        glm::dquat(loadedPlanet.rotation) * WorldVec3{0.0, 0.0, 1.0e6};
    SW_CHECK(glm::length(loaded.getComponent<TransformComponent>(base).position -
                         expectedAfter) < 0.5);
}
