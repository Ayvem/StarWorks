// ============================================================================
// PartsTests.cpp — the part system: catalog integrity, vessel aggregation
// (mass/thrust/drag from parts + carried resources) and rigid attachment.
// ============================================================================

#include "TestFramework.hpp"

#include <ECS/World.hpp>
#include <Gameplay/Parts.hpp>

#include <cmath>

using namespace sw;
using namespace sw::parts;

SW_TEST(PartCatalogCoversEveryTypeWithSaneData)
{
    // Every one of the 9 part types exists, ids are unique and stable,
    // and every definition exposes the full property sheet.
    bool typeSeen[static_cast<usize>(PartType::Count)] = {};
    u32 seenIds[64] = {};
    usize idCount = 0;
    for (const PartDefinition& definition : catalog())
    {
        typeSeen[static_cast<usize>(definition.type)] = true;
        for (usize i = 0; i < idCount; ++i)
        {
            SW_CHECK(seenIds[i] != definition.id); // unique ids
        }
        seenIds[idCount++] = definition.id;

        SW_CHECK(definition.dryMassKg > 0.0);
        SW_CHECK(definition.costCredits > 0.0);
        SW_CHECK(definition.volumeM3 > 0.0);
        SW_CHECK(definition.crashToleranceMps > 0.0);
        SW_CHECK(definition.breakingForceN > 0.0);
        SW_CHECK(definition.dragCoefficientArea > 0.0);
        SW_CHECK(definition.attachPointCount > 0); // every part connects
        SW_CHECK(!definition.name.empty());
        SW_CHECK(findDefinition(definition.id) == &definition);
    }
    for (usize type = 0; type < static_cast<usize>(PartType::Count); ++type)
    {
        SW_CHECK(typeSeen[type]);
    }
    // Function-specific data.
    SW_CHECK(findDefinition(kPartEngineVector)->thrustNewtons > 0.0);
    SW_CHECK(findDefinition(kPartEngineVector)->specificImpulseS > 0.0);
    SW_CHECK(findDefinition(kPartSolarWing)->chargeRateKw > 0.0);
    SW_CHECK(findDefinition(kPartFinBasic)->liftCoefficient > 0.0);
    SW_CHECK(findDefinition(kPartFuelTankMedium)->capacities[0].resource ==
             res::Resource::Fuel);
}

SW_TEST(VesselAssemblyAggregatesPartsAndCargo)
{
    ecs::World world;

    // Vessel root.
    const ecs::Entity root = world.createEntity();
    world.addComponent(root, TransformComponent{});
    world.addComponent(root, VesselComponent{});
    world.addComponent(root, phys::DynamicBodyComponent{{0.0, 0.0, 0.0}, 1.0});

    auto addPart = [&world, root](u32 definitionId, const Vec3& localPosition) {
        const ecs::Entity part = world.createEntity();
        world.addComponent(part, TransformComponent{});
        world.addComponent(part, PreviousTransformComponent{});
        PartComponent component{};
        component.definitionId = definitionId;
        component.vessel = root;
        component.localPosition = localPosition;
        world.addComponent(part, component);
        return part;
    };
    addPart(kPartCoreStructural, {0.0f, 0.0f, -3.0f});
    const ecs::Entity tank = addPart(kPartFuelTankMedium, {0.0f, 0.0f, 0.0f});
    addPart(kPartEngineVector, {0.0f, 0.0f, 3.0f});

    factory::InventoryComponent inventory{};
    inventory.volumeCapacityM3 = 21.0;
    factory::inventoryAdd(inventory, res::Resource::Fuel, 16000.0);
    world.addComponent(tank, inventory);

    VesselAssemblySystem assembly;
    assembly.update(world, 0.02f);

    const auto& vessel = world.getComponent<VesselComponent>(root);
    const f64 expectedDry = findDefinition(kPartCoreStructural)->dryMassKg +
                            findDefinition(kPartFuelTankMedium)->dryMassKg +
                            findDefinition(kPartEngineVector)->dryMassKg;
    SW_CHECK_EQ(vessel.partCount, 3u);
    SW_CHECK(std::abs(vessel.dryMassKg - expectedDry) < 1.0e-6);
    // Total = dry + 16 t of fuel (1 unit = 1 kg), pushed into the body.
    SW_CHECK(std::abs(vessel.totalMassKg - (expectedDry + 16000.0)) < 1.0e-6);
    const auto& body = world.getComponent<phys::DynamicBodyComponent>(root);
    SW_CHECK(std::abs(body.mass - vessel.totalMassKg) < 1.0e-6);
    SW_CHECK(std::abs(vessel.maxThrustNewtons - 4.0e5) < 1.0);
    // Mass flow = F / (Isp * g0).
    SW_CHECK(std::abs(vessel.maxMassFlowKgps - 4.0e5 / (345.0 * 9.80665)) < 1.0e-6);
    SW_CHECK(body.ballisticFactor > 0.0);

    // Burn half the fuel: the vessel gets lighter on the next pass — the
    // rocket equation emerges from cargo mass alone.
    factory::inventoryRemove(world.getComponent<factory::InventoryComponent>(tank),
                             res::Resource::Fuel, 8000.0);
    assembly.update(world, 0.02f);
    SW_CHECK(std::abs(world.getComponent<VesselComponent>(root).totalMassKg -
                      (expectedDry + 8000.0)) < 1.0e-6);
}

SW_TEST(DecouplingSplitsTheVesselAlongTheJoint)
{
    ecs::World world;

    const ecs::Entity root = world.createEntity();
    TransformComponent rootTransform{};
    rootTransform.position = {1.0e6, 0.0, 0.0};
    world.addComponent(root, rootTransform);
    world.addComponent(root, PreviousTransformComponent{});
    world.addComponent(root, VesselComponent{});
    world.addComponent(root, phys::DynamicBodyComponent{{100.0, 0.0, 0.0}, 1.0});

    auto addPart = [&](u32 definitionId, f32 z) {
        const ecs::Entity part = world.createEntity();
        world.addComponent(part, TransformComponent{});
        world.addComponent(part, PreviousTransformComponent{});
        PartComponent component{};
        component.definitionId = definitionId;
        component.vessel = root;
        component.localPosition = {0.0f, 0.0f, z};
        world.addComponent(part, component);
        return part;
    };
    // core -- decoupler -- tank -- engine  (nose to tail)
    const ecs::Entity core = addPart(kPartCoreStructural, -4.0f);
    const ecs::Entity decoupler = addPart(kPartDecouplerFlat, -2.0f);
    const ecs::Entity tank = addPart(kPartFuelTankMedium, 0.5f);
    const ecs::Entity engine = addPart(kPartEngineVector, 3.5f);
    connectParts(world, core, decoupler, 1, 0, JointType::Stack, 2.5e5, 2.5e5);
    connectParts(world, decoupler, tank, 1, 0, JointType::Stack, 2.5e5, 2.5e5);
    connectParts(world, tank, engine, 1, 0, JointType::Stack, 4.0e5, 4.0e5);

    const ecs::Entity separated = decoupleAt(world, decoupler);
    SW_CHECK(!separated.isNull());

    // Core + decoupler stay; tank + engine ride the new vessel, which
    // inherited the velocity plus a separation shove.
    SW_CHECK(world.getComponent<PartComponent>(core).vessel == root);
    SW_CHECK(world.getComponent<PartComponent>(decoupler).vessel == root);
    SW_CHECK(world.getComponent<PartComponent>(tank).vessel == separated);
    SW_CHECK(world.getComponent<PartComponent>(engine).vessel == separated);
    const auto& body = world.getComponent<phys::DynamicBodyComponent>(separated);
    SW_CHECK(glm::length(body.velocity - WorldVec3{100.0, 0.0, 0.0}) > 0.5);
    // The decoupler-tank joint is gone: only 2 joints remain.
    u32 jointCount = 0;
    world.forEach<JointComponent>([&](ecs::Entity, JointComponent&) { ++jointCount; });
    SW_CHECK_EQ(jointCount, 2u);
}

SW_TEST(DockingMergesVesselsAndReroutesParts)
{
    ecs::World world;

    auto makeVessel = [&](const WorldVec3& position, const Quat& rotation) {
        const ecs::Entity vessel = world.createEntity();
        TransformComponent transform{};
        transform.position = position;
        transform.rotation = rotation;
        world.addComponent(vessel, transform);
        world.addComponent(vessel, PreviousTransformComponent{});
        world.addComponent(vessel, VesselComponent{});
        world.addComponent(vessel, phys::DynamicBodyComponent{{0.0, 0.0, 0.0}, 1.0});
        return vessel;
    };
    auto addPort = [&](ecs::Entity vessel, f32 z) {
        const ecs::Entity part = world.createEntity();
        world.addComponent(part, TransformComponent{});
        world.addComponent(part, PreviousTransformComponent{});
        PartComponent component{};
        component.definitionId = kPartDockingRing;
        component.vessel = vessel;
        component.localPosition = {0.0f, 0.0f, z};
        world.addComponent(part, component);
        return part;
    };

    const ecs::Entity vesselA = makeVessel({0.0, 0.0, 0.0}, {1, 0, 0, 0});
    const ecs::Entity vesselB = makeVessel({0.0, 0.0, -3.0}, {1, 0, 0, 0});
    const ecs::Entity portA = addPort(vesselA, -1.0f);
    const ecs::Entity portB = addPort(vesselB, 1.0f);

    // Attachment pass gives both ports their WORLD poses before docking.
    PartAttachmentSystem attachment;
    attachment.update(world, 0.02f);

    SW_CHECK(dockVessels(world, portA, portB));
    // B's port now belongs to vessel A, re-localized into A's frame
    // (B root was at z=-3, its port at local +1 -> world -2 -> A-local -2).
    const auto& merged = world.getComponent<PartComponent>(portB);
    SW_CHECK(merged.vessel == vesselA);
    SW_CHECK(std::abs(merged.localPosition.z - (-2.0f)) < 1.0e-3f);
    SW_CHECK(!world.isAlive(vesselB)); // absorbed root destroyed
    // A docking joint now links the two ports.
    u32 dockingJoints = 0;
    world.forEach<JointComponent>([&](ecs::Entity, JointComponent& joint) {
        if (joint.type == JointType::Docking &&
            ((joint.partA == portA && joint.partB == portB) ||
             (joint.partA == portB && joint.partB == portA)))
        {
            ++dockingJoints;
        }
    });
    SW_CHECK_EQ(dockingJoints, 1u);
}

SW_TEST(PartsRideTheirVesselRigidly)
{
    ecs::World world;

    const ecs::Entity root = world.createEntity();
    TransformComponent rootTransform{};
    rootTransform.position = {1000.0, 2000.0, 3000.0};
    rootTransform.rotation =
        glm::angleAxis(1.2f, glm::normalize(Vec3{0.3f, 1.0f, 0.2f}));
    world.addComponent(root, rootTransform);
    world.addComponent(root, PreviousTransformComponent{{900.0, 2000.0, 3000.0},
                                                        rootTransform.rotation});

    const ecs::Entity part = world.createEntity();
    world.addComponent(part, TransformComponent{});
    world.addComponent(part, PreviousTransformComponent{});
    PartComponent component{};
    component.definitionId = kPartFuelTankMedium;
    component.vessel = root;
    component.localPosition = {0.0f, 0.0f, 4.0f};
    world.addComponent(part, component);

    PartAttachmentSystem attachment;
    attachment.update(world, 0.02f);

    const auto& transform = world.getComponent<TransformComponent>(part);
    const WorldVec3 expected =
        rootTransform.position +
        WorldVec3(rootTransform.rotation * Vec3{0.0f, 0.0f, 4.0f});
    SW_CHECK(glm::length(transform.position - expected) < 1.0e-4);
    // Previous derived from the vessel's previous: lockstep interpolation.
    const auto& previous = world.getComponent<PreviousTransformComponent>(part);
    SW_CHECK(std::abs(previous.position.x -
                      (900.0 + (expected.x - 1000.0))) < 1.0e-4);
}
