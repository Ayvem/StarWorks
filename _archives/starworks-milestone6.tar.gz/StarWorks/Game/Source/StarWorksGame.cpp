#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <cmath>

namespace game
{
    namespace
    {
        // ---- real-world dimensions and gravity (meters, m^3/s^2) --------------
        constexpr sw::f64 kTerraRadius = 6.371e6;    // Earth
        constexpr sw::f64 kMuTerra = 3.986004418e14; // Earth GM
        constexpr sw::f64 kLunaRadius = 1.7374e6;    // Moon
        constexpr sw::f64 kMuLuna = 4.9048695e12;    // Moon GM
        constexpr sw::f64 kLunaDistance = 3.844e8;   // Earth-Moon distance
        constexpr sw::f64 kStationAltitude = 4.0e5;  // 400 km (LEO)
        constexpr sw::f64 kStationOrbitRadius = kTerraRadius + kStationAltitude;
        /// Mean anomaly placing an equatorial-circular object at world +Z.
        constexpr sw::f64 kStationPhase = 4.71238898038468986; // 3*pi/2

        constexpr sw::u32 kStationModuleCount = 8;
        constexpr sw::u32 kDebrisCount = 12000;

        /// Simulation bubble: only objects this close to the camera are
        /// really integrated; everything else stays on rails.
        constexpr sw::f64 kBubbleEnterRadius = 1.0e4; // 10 km
        constexpr sw::f64 kBubbleExitRadius = 1.5e4;  // 15 km (hysteresis)

        /// Sphere LOD resolutions, most to least detailed (rings, segments).
        constexpr sw::u32 kLodRings[CelestialLodComponent::kLodLevels] = {64, 32, 16, 8, 6};
        constexpr sw::u32 kLodSegments[CelestialLodComponent::kLodLevels] = {96, 48, 24, 12, 9};

        /// LOD thresholds as fractions of the vertical FOV covered by the
        /// body's angular diameter (descending; below the last -> coarsest).
        constexpr sw::f32 kLodScreenFractions[CelestialLodComponent::kLodLevels - 1] = {
            0.5f, 0.15f, 0.04f, 0.008f};

        /// Deterministic pseudo-random in [0, 1) — scene layout must be
        /// reproducible run to run (and later, from a save file).
        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }

        [[nodiscard]] sw::f64 hash01d(sw::u32 x)
        {
            return static_cast<sw::f64>(hash01(x));
        }

        /// Half-diagonal of the unit cube: bounding sphere of cube meshes.
        constexpr sw::f32 kCubeBoundsRadius = 0.8660254f;
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        // Near plane 0.5 m (station scale), far 1e9 m (beyond the moon) —
        // usable together only thanks to reverse-Z.
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.5f, 1.0e9f);

        buildScene();

        // Start 2 km outside the station cluster, looking at it with the
        // planet filling the background.
        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};
        m_cameraController.setPose(stationCenter + sw::WorldVec3{0.0, 250.0, 2000.0}, 0.0f,
                                   -0.08f);

        // ---- simulation lanes ---------------------------------------------------
        // Physics 50 Hz: ONLY dynamic bodies (bubble contents) pay this cost.
        m_physicsLane = m_simulation.findLane("Physics");
        m_physicsLane->scheduler().addSystem(std::make_unique<SnapshotSystem>());
        m_physicsLane->scheduler().addSystem(
            std::make_unique<sw::phys::GravityIntegrationSystem>());
        m_physicsLane->scheduler().addSystem(std::make_unique<SpinSystem>());
        m_physicsLane->scheduler().addSystem(std::make_unique<CelestialSpinSystem>());

        // Logistics 10 Hz: analytic rails refresh + bubble classification.
        auto& logistics = m_simulation.findLane("Logistics")->scheduler();
        logistics.addSystem(std::make_unique<sw::phys::RailsSystem>(m_simulation));
        sw::phys::SimulationBubbleSystem::Config bubbleConfig{};
        bubbleConfig.enterRadius = kBubbleEnterRadius;
        bubbleConfig.exitRadius = kBubbleExitRadius;
        auto bubble = std::make_unique<sw::phys::SimulationBubbleSystem>(
            m_commands, m_simulation, bubbleConfig);
        m_bubbleSystem = bubble.get();
        logistics.addSystem(std::move(bubble));

        m_simulation.findLane("World")->scheduler().addSystem(
            std::make_unique<StatsSystem>());

        SW_LOG_INFO("Game",
                    "Two-regime physics ready: {} entities, bubble {}/{} km, Terra "
                    "mu={:.3e}, Luna at {:.0f} km",
                    m_world.aliveCount(), kBubbleEnterRadius / 1000.0,
                    kBubbleExitRadius / 1000.0, kMuTerra, kLunaDistance / 1000.0);

        SW_LOG_INFO("Game", "Controls: RMB + mouse = look, WASD = move, Q/E = down/up, "
                            "Shift = boost, wheel = speed, Space = pause, 1/2/3 = time "
                            "scale x0.25/x1/x4, Esc = quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    CelestialLodComponent StarWorksGame::makeSphereLodSet(const sw::Vec4& color)
    {
        CelestialLodComponent lod{};
        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels; ++level)
        {
            lod.meshIndex[level] = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, kLodRings[level],
                                                   kLodSegments[level], color)));
        }
        return lod;
    }

    void StarWorksGame::buildScene()
    {
        // ---- meshes -------------------------------------------------------------
        const CelestialLodComponent terraLod =
            makeSphereLodSet({0.21f, 0.33f, 0.48f, 1.0f}); // oceanic blue-grey
        const CelestialLodComponent lunaLod =
            makeSphereLodSet({0.42f, 0.41f, 0.43f, 1.0f}); // regolith grey

        sw::u32 asteroidMeshId = 0;
        sw::f32 asteroidBoundsRadius = 2.5f;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f})));
            asteroidBoundsRadius = 1.0f;
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        const sw::u32 debrisMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.55f, 0.50f, 0.45f, 1.0f})));

        renderer().setSunDirection({-0.45f, -0.35f, -0.82f});

        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};

        auto snapshotOf = [](const TransformComponent& transform) {
            return PreviousTransformComponent{transform.position, transform.rotation};
        };

        /// Creates an on-rails entity: transform initialized from the orbit
        /// so the very first frames are already correct.
        auto addRailsEntity = [&](const sw::phys::KeplerOrbit& orbit, sw::f32 scale,
                                  sw::u32 meshId) {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(orbit, 0.0, transform.position);
            transform.uniformScale = scale;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{meshId});
            m_world.addComponent(e, sw::phys::OnRailsComponent{orbit});
            return e;
        };

        // ---- Terra (real radius, GM and sidereal rotation rate) ---------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {0.0, 0.0, 0.0};
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, terraLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.2921e-5f});
            m_world.addComponent(e, sw::phys::GravitySourceComponent{kMuTerra});
        }

        // ---- Luna (real radius, GM, distance) -----------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {kLunaDistance, 0.0, 0.0};
            transform.uniformScale = static_cast<sw::f32>(kLunaRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, lunaLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.66e-6f});
            m_world.addComponent(e, sw::phys::GravitySourceComponent{kMuLuna});
        }

        // ---- asteroid: TRULY simulated from the start ----------------------------
        // Placed inside the bubble with exact circular orbital velocity; the
        // Newtonian integrator keeps it in orbit — no script, just gravity.
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{650.0, 120.0, -300.0};
            transform.uniformScale = 120.0f; // ~300 m rock
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{asteroidBoundsRadius});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.05f});

            const sw::f64 radius = glm::length(transform.position);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(
                e, sw::phys::DynamicBodyComponent{{speed, 0.0, 0.0}, 5.0e8});
        }

        // ---- station modules: shared circular orbit (rails), tiny offsets -------
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f64 offset =
                (static_cast<sw::f64>(i) / kStationModuleCount - 0.5) * 1.0e-4;
            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, {0.0, 0.0, 0.0},
                kStationOrbitRadius + (static_cast<sw::f64>(i) - 3.5) * 12.0,
                /*e=*/0.0, /*i=*/0.0, /*raan=*/0.0, /*argPeriapsis=*/0.0,
                /*M0=*/kStationPhase + offset, /*epoch=*/0.0);

            const sw::ecs::Entity e = addRailsEntity(orbit, 30.0f, moduleMeshId);
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f}, 0.15f});
        }

        // ---- debris belt: 12k objects on REAL orbital elements (rails) ---------
        for (sw::u32 i = 0; i < kDebrisCount; ++i)
        {
            const sw::f64 semiMajor =
                kStationOrbitRadius + (hash01d(i * 3 + 0) - 0.5) * 5.0e4;
            const sw::f64 eccentricity = hash01d(i * 7 + 1) * 8.0e-4;
            const sw::f64 inclination = hash01d(i * 7 + 2) * 0.006;
            const sw::f64 raan = hash01d(i * 7 + 3) * sw::math::kTwoPi;
            const sw::f64 argPeriapsis = hash01d(i * 7 + 4) * sw::math::kTwoPi;
            // Cluster near the station: for small i/e the in-orbit angle is
            // ~ raan + argPeriapsis + M, so compensate both.
            const sw::f64 meanAnomaly = kStationPhase - raan - argPeriapsis +
                                        (hash01d(i * 3 + 1) - 0.5) * 0.02;

            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, {0.0, 0.0, 0.0}, semiMajor, eccentricity, inclination, raan,
                argPeriapsis, meanAnomaly, 0.0);

            const sw::f32 scale = 2.0f + hash01(i * 13 + 7) * 28.0f; // 2..30 m
            const sw::ecs::Entity e = addRailsEntity(orbit, scale, debrisMeshId);

            const sw::Vec3 axis = glm::normalize(sw::Vec3{hash01(i * 5 + 1) - 0.5f,
                                                          hash01(i * 5 + 2) - 0.5f,
                                                          hash01(i * 5 + 3) - 0.5f});
            m_world.addComponent(e, SpinComponent{axis, 0.2f + hash01(i * 5 + 4) * 1.5f});
        }
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        // --- simulation controls (rendering never stops either way) ----------
        if (input().wasKeyPressed(sw::KeyCode::Space))
        {
            m_simulation.setPaused(!m_simulation.isPaused());
            SW_LOG_INFO("Game", "Simulation {}", m_simulation.isPaused() ? "paused" : "resumed");
        }
        if (input().wasKeyPressed(sw::KeyCode::Num1)) { m_simulation.setTimeScale(0.25f); }
        if (input().wasKeyPressed(sw::KeyCode::Num2)) { m_simulation.setTimeScale(1.0f); }
        if (input().wasKeyPressed(sw::KeyCode::Num3)) { m_simulation.setTimeScale(4.0f); }

        m_cameraController.update(input(), window(), deltaSeconds);
        m_camera.setAspectRatio(renderer().aspectRatio());

        // The bubble follows the player: only nearby space is truly simulated.
        m_bubbleSystem->setFocus(m_camera.position());

        // Wall-clock time goes in; lanes tick at their own fixed rates.
        m_simulation.advance(m_world, deltaSeconds, &threadPool());

        // Apply deferred structural changes (bubble conversions) at the
        // single well-defined point of the frame.
        m_commands.playback(m_world);

        // --- periodic statistics ------------------------------------------------
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastStatsLogSeconds > 5.0)
        {
            m_lastStatsLogSeconds = now;
            const sw::RenderStats& stats = renderer().stats();
            SW_LOG_INFO("Game",
                        "render: {} submitted, {} culled, {} instances in {} draw calls | "
                        "sim: {} dynamic / {} rails ({:.0f} FPS, prepare {:.1f} ms)",
                        stats.itemsSubmitted, stats.itemsCulled, stats.instancesDrawn,
                        stats.drawCalls, m_world.count<sw::phys::DynamicBodyComponent>(),
                        m_world.count<sw::phys::OnRailsComponent>(), clock().smoothedFps(),
                        stats.cpuPrepareMs);
        }
    }

    sw::u32 StarWorksGame::selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const
    {
        // Fraction of the vertical FOV covered by the body's angular diameter.
        const sw::f64 clampedDistance = std::max(distance, worldRadius * 1.0001);
        const sw::f64 angularDiameter = 2.0 * std::atan(worldRadius / clampedDistance);
        const sw::f32 fraction =
            static_cast<sw::f32>(angularDiameter) / m_camera.verticalFov();

        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels - 1; ++level)
        {
            if (fraction >= kLodScreenFractions[level])
            {
                return level;
            }
        }
        return CelestialLodComponent::kLodLevels - 1;
    }

    void StarWorksGame::collectDrawItems()
    {
        m_drawItems.clear();
        m_drawItems.reserve(m_world.aliveCount());

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::f64 alpha64 = static_cast<sw::f64>(alpha);
        const sw::WorldVec3 cameraPosition = m_camera.position();

        // Shared path: interpolate in f64, narrow to camera-relative f32.
        // (Rails entities have Previous == current: the mix is a no-op.)
        auto makeTransform = [&](const TransformComponent& transform,
                                 const PreviousTransformComponent& previous,
                                 sw::Vec3& outRelative) {
            const sw::WorldVec3 position =
                glm::mix(previous.position, transform.position, alpha64);
            const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);
            outRelative = sw::Vec3(position - cameraPosition);
            return glm::translate(sw::Mat4{1.0f}, outRelative) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{transform.uniformScale});
        };

        // ---- fixed-mesh entities ------------------------------------------------
        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        MeshComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                MeshComponent& mesh) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                m_drawItems.push_back({&m_meshes[mesh.meshIndex], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        // ---- celestial bodies: LOD by angular size ---------------------------------
        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        CelestialLodComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                CelestialLodComponent& lod) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);

                const sw::f64 worldRadius = static_cast<sw::f64>(transform.uniformScale);
                const sw::f64 distance =
                    glm::length(transform.position - cameraPosition);
                const sw::u32 level = selectLodLevel(distance, worldRadius);

                m_drawItems.push_back({&m_meshes[lod.meshIndex[level]], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });
    }

    void StarWorksGame::onRender()
    {
        collectDrawItems();
        renderer().renderFrame(m_camera, m_drawItems);
    }
} // namespace game
