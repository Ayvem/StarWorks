#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 6: two-regime Newtonian physics at real scale.
//
//  - Everything distant lives ON RAILS: analytic Kepler orbits, no
//    integration, positions refreshed at 10 Hz from the closed form.
//  - Only objects inside the simulation bubble around the camera are truly
//    simulated: f64 Newtonian gravity integrated at 50 Hz, with continuous
//    conversion rails <-> dynamic at the bubble boundary.
//  - Terra (6,371 km) and Luna (1,737 km at 384,400 km) are gravity
//    sources with real GM values; the debris belt sits in 400 km LEO on
//    real orbital elements.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        [[nodiscard]] CelestialLodComponent makeSphereLodSet(const sw::Vec4& color);
        void buildScene();
        void collectDrawItems();
        [[nodiscard]] sw::u32 selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const;

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Mesh table: components reference meshes by index (asset-ID
        // precursor; becomes the Assets registry in a later milestone).
        std::vector<sw::Mesh> m_meshes;

        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation
        sw::ecs::EntityCommandBuffer m_commands;
        /// Owned by the Logistics lane scheduler; kept to update the focus.
        sw::phys::SimulationBubbleSystem* m_bubbleSystem = nullptr;

        std::vector<sw::DrawItem> m_drawItems;
        sw::f64 m_lastStatsLogSeconds = 0.0;
    };
} // namespace game
