#pragma once

// ============================================================================
// Components.hpp — game-side ECS components.
//
// Spatial components (TransformComponent, PreviousTransformComponent) and
// physics components (DynamicBody, OnRails, GravitySource) are ENGINE types
// since Milestone 6 — aliased here so game code keeps short names.
//
// All components follow the engine rule: trivially copyable, no owning
// members. Meshes are referenced by index into the game's mesh table (an
// asset-ID precursor), never by pointer — save-file friendly by design.
// ============================================================================

#include <Engine.hpp>

namespace game
{
    // Engine spatial/physics components under their game-local names.
    using TransformComponent = sw::TransformComponent;
    using PreviousTransformComponent = sw::PreviousTransformComponent;

    /// Bounding sphere radius in mesh-local units (world radius =
    /// localRadius * uniformScale). Used for frustum culling.
    struct BoundsComponent
    {
        sw::f32 localRadius = 1.0f;
    };

    /// Constant-rate self rotation around a fixed axis. Only applied to
    /// entities that are really simulated (dynamic bodies) or to celestial
    /// bodies — on-rails debris keeps a frozen orientation, invisible at
    /// the distances where rails objects live.
    struct SpinComponent
    {
        sw::Vec3 axis{0.0f, 1.0f, 0.0f};
        sw::f32 radiansPerSecond = 1.0f;
    };

    /// Fixed-mesh renderable (index into the game mesh table).
    struct MeshComponent
    {
        sw::u32 meshIndex = 0;
    };

    /// Celestial body renderable with distance-based level of detail:
    /// meshes[0] is the most detailed sphere, meshes[kLodLevels-1] the
    /// coarsest. The level is chosen from the body's ANGULAR size on screen,
    /// so a moon 384,000 km away costs a few dozen triangles while the
    /// planet you are orbiting gets full geometry. (The Planet module's
    /// quadtree surface will later replace level 0 near the ground.)
    struct CelestialLodComponent
    {
        static constexpr sw::u32 kLodLevels = 5;
        sw::u32 meshIndex[kLodLevels] = {0, 0, 0, 0, 0};
    };

    static_assert(std::is_trivially_copyable_v<BoundsComponent>);
    static_assert(std::is_trivially_copyable_v<SpinComponent>);
    static_assert(std::is_trivially_copyable_v<MeshComponent>);
    static_assert(std::is_trivially_copyable_v<CelestialLodComponent>);
} // namespace game
