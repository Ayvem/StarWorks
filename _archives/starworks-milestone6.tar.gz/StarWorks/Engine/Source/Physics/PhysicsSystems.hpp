#pragma once

// ============================================================================
// Physics/PhysicsSystems.hpp
// Engine systems implementing the two-regime physics architecture.
//
//  GravityIntegrationSystem (Physics lane, 50 Hz)
//      Semi-implicit Euler in f64 over every DynamicBody: only the handful
//      of objects inside the simulation bubble ever pay this cost.
//
//  RailsSystem (Logistics lane, 10 Hz)
//      Writes the CURRENT analytic position of every on-rails object into
//      its transform (Previous == current: rails objects are far away and
//      need no interpolation). 10 Hz for thousands of objects costs
//      milliseconds per second — this is the "not really simulated" tier.
//
//  SimulationBubbleSystem (Logistics lane, after RailsSystem)
//      Classifies objects by distance to the focus (the player/camera):
//      rails objects entering the bubble become dynamic (state vectors from
//      the analytic orbit — position/velocity continuous); dynamic objects
//      leaving it are converted back to rails (elements from state vectors).
//      Hysteresis (exit > enter radius) prevents churn at the boundary.
//      Conversions are structural, so they go through the command buffer
//      and apply at the owner thread's playback point.
// ============================================================================

#include "ECS/CommandBuffer.hpp"
#include "ECS/System.hpp"
#include "Physics/PhysicsComponents.hpp"
#include "Scene/TransformComponents.hpp"

#include <vector>

namespace sw::sim
{
    class Simulation;
} // namespace sw::sim

namespace sw::phys
{
    class GravityIntegrationSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "GravityIntegrationSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<DynamicBodyComponent>()
                .read<GravitySourceComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        struct Source
        {
            WorldVec3 position;
            f64 mu;
        };
        std::vector<Source> m_sources; // scratch, rebuilt each tick
    };

    class RailsSystem final : public ecs::System
    {
    public:
        /// Reads the simulation clock for the analytic evaluation time.
        explicit RailsSystem(const sim::Simulation& simulation)
            : m_simulation(simulation)
        {
        }

        [[nodiscard]] std::string_view name() const override { return "RailsSystem"; }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<OnRailsComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        const sim::Simulation& m_simulation;
    };

    class SimulationBubbleSystem final : public ecs::System
    {
    public:
        struct Config
        {
            f64 enterRadius = 1.0e4; // rails -> dynamic below this distance
            f64 exitRadius = 1.5e4;  // dynamic -> rails beyond this distance
        };

        SimulationBubbleSystem(ecs::EntityCommandBuffer& commands,
                               const sim::Simulation& simulation, const Config& config);

        /// World-space focus of the bubble (typically the camera/player).
        void setFocus(const WorldVec3& focus) { m_focus = focus; }

        [[nodiscard]] std::string_view name() const override
        {
            return "SimulationBubbleSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            // Read-only over component data; conversions are deferred
            // through the command buffer.
            return ecs::SystemAccess{}
                .read<TransformComponent>()
                .read<OnRailsComponent>()
                .read<DynamicBodyComponent>()
                .read<GravitySourceComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        ecs::EntityCommandBuffer& m_commands;
        const sim::Simulation& m_simulation;
        Config m_config;
        WorldVec3 m_focus{0.0};
        /// Gravity parameters of the dominant source, cached per update for
        /// dynamic->rails conversions.
        WorldVec3 m_primaryCenter{0.0};
        f64 m_primaryMu = 0.0;
    };
} // namespace sw::phys
