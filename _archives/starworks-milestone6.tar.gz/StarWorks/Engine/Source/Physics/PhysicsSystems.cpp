#include "Physics/PhysicsSystems.hpp"

#include "Core/Log.hpp"
#include "ECS/World.hpp"
#include "Simulation/Simulation.hpp"

namespace sw::phys
{
    // ------------------------------------------------------------------------
    // GravityIntegrationSystem
    // ------------------------------------------------------------------------
    void GravityIntegrationSystem::update(ecs::World& world, f32 deltaSeconds)
    {
        // Collect gravity sources (a handful of celestial bodies).
        m_sources.clear();
        world.forEach<TransformComponent, GravitySourceComponent>(
            [this](ecs::Entity, TransformComponent& transform,
                   GravitySourceComponent& source) {
                m_sources.push_back({transform.position, source.mu});
            });

        const f64 dt = static_cast<f64>(deltaSeconds);

        // Semi-implicit (symplectic) Euler: v then p — stable for orbits.
        world.forEach<TransformComponent, DynamicBodyComponent>(
            [this, dt](ecs::Entity, TransformComponent& transform,
                       DynamicBodyComponent& body) {
                WorldVec3 acceleration{0.0};
                for (const Source& source : m_sources)
                {
                    const WorldVec3 toSource = source.position - transform.position;
                    const f64 distanceSq = glm::dot(toSource, toSource);
                    if (distanceSq > 1.0)
                    {
                        const f64 distance = std::sqrt(distanceSq);
                        acceleration += toSource * (source.mu / (distanceSq * distance));
                    }
                }
                body.velocity += acceleration * dt;
                transform.position += body.velocity * dt;
            });
    }

    // ------------------------------------------------------------------------
    // RailsSystem
    // ------------------------------------------------------------------------
    void RailsSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        const f64 time = m_simulation.simulatedSeconds();

        world.forEach<TransformComponent, PreviousTransformComponent, OnRailsComponent>(
            [time](ecs::Entity, TransformComponent& transform,
                   PreviousTransformComponent& previous, OnRailsComponent& rails) {
                WorldVec3 position{};
                kepler::evaluate(rails.orbit, time, position);
                transform.position = position;
                // No interpolation for rails objects: they are distant by
                // definition, and mirroring avoids a stale-previous sweep.
                previous.position = position;
                previous.rotation = transform.rotation;
            });
    }

    // ------------------------------------------------------------------------
    // SimulationBubbleSystem
    // ------------------------------------------------------------------------
    SimulationBubbleSystem::SimulationBubbleSystem(ecs::EntityCommandBuffer& commands,
                                                   const sim::Simulation& simulation,
                                                   const Config& config)
        : m_commands(commands)
        , m_simulation(simulation)
        , m_config(config)
    {
        SW_ASSERT(m_config.exitRadius > m_config.enterRadius,
                  "Bubble hysteresis requires exitRadius ({}) > enterRadius ({})",
                  m_config.exitRadius, m_config.enterRadius);
    }

    void SimulationBubbleSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        const f64 time = m_simulation.simulatedSeconds();
        const WorldVec3 focus = m_focus;

        // Cache the dominant gravity source (largest mu) for conversions.
        m_primaryMu = 0.0;
        world.forEach<TransformComponent, GravitySourceComponent>(
            [this](ecs::Entity, TransformComponent& transform,
                   GravitySourceComponent& source) {
                if (source.mu > m_primaryMu)
                {
                    m_primaryMu = source.mu;
                    m_primaryCenter = transform.position;
                }
            });
        if (m_primaryMu <= 0.0)
        {
            return; // no gravity source: nothing to convert against
        }

        const f64 enterSq = m_config.enterRadius * m_config.enterRadius;
        const f64 exitSq = m_config.exitRadius * m_config.exitRadius;

        // ---- rails -> dynamic (entering the bubble) --------------------------
        world.forEach<TransformComponent, OnRailsComponent>(
            [&](ecs::Entity entity, TransformComponent& transform, OnRailsComponent& rails) {
                const WorldVec3 delta = transform.position - focus;
                if (glm::dot(delta, delta) >= enterSq)
                {
                    return;
                }

                // Exact state vectors at conversion time: the hand-off is
                // continuous in both position and velocity.
                WorldVec3 position{};
                WorldVec3 velocity{};
                kepler::evaluate(rails.orbit, time, position, &velocity);

                m_commands.defer([entity, position, velocity](ecs::World& w) {
                    if (!w.isAlive(entity) ||
                        !w.hasComponent<OnRailsComponent>(entity))
                    {
                        return;
                    }
                    auto& t = w.getComponent<TransformComponent>(entity);
                    t.position = position;
                    if (auto* prev = w.tryGetComponent<PreviousTransformComponent>(entity))
                    {
                        prev->position = position;
                        prev->rotation = t.rotation;
                    }
                    w.removeComponent<OnRailsComponent>(entity);
                    w.addComponent(entity, DynamicBodyComponent{velocity, 1000.0});
                });
            });

        // ---- dynamic -> rails (leaving the bubble) -----------------------------
        const WorldVec3 primaryCenter = m_primaryCenter;
        const f64 primaryMu = m_primaryMu;
        world.forEach<TransformComponent, DynamicBodyComponent>(
            [&](ecs::Entity entity, TransformComponent& transform,
                DynamicBodyComponent& body) {
                // Gravity sources themselves are never bubble-managed.
                if (world.hasComponent<GravitySourceComponent>(entity))
                {
                    return;
                }
                const WorldVec3 delta = transform.position - focus;
                if (glm::dot(delta, delta) <= exitSq)
                {
                    return;
                }

                KeplerOrbit orbit{};
                if (!kepler::fromStateVectors(primaryMu, primaryCenter, transform.position,
                                              body.velocity, time, orbit))
                {
                    return; // unbound trajectory: keep it truly simulated
                }

                m_commands.defer([entity, orbit](ecs::World& w) {
                    if (!w.isAlive(entity) ||
                        !w.hasComponent<DynamicBodyComponent>(entity))
                    {
                        return;
                    }
                    w.removeComponent<DynamicBodyComponent>(entity);
                    w.addComponent(entity, OnRailsComponent{orbit});
                });
            });
    }
} // namespace sw::phys
