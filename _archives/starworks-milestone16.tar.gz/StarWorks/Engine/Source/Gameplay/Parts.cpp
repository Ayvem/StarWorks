#include "Gameplay/Parts.hpp"

#include "ECS/World.hpp"

#include <array>

namespace sw::parts
{
    namespace
    {
        /// Stack node helper: top/bottom joints on the part axis (-Z nose).
        [[nodiscard]] constexpr AttachPoint stackTop(f32 z)
        {
            return {{0.0f, 0.0f, z}, {0.0f, 0.0f, -1.0f}};
        }
        [[nodiscard]] constexpr AttachPoint stackBottom(f32 z)
        {
            return {{0.0f, 0.0f, z}, {0.0f, 0.0f, 1.0f}};
        }
        [[nodiscard]] constexpr AttachPoint radial(f32 x, f32 z)
        {
            return {{x, 0.0f, z}, {x >= 0.0f ? 1.0f : -1.0f, 0.0f, 0.0f}};
        }

        const std::array<PartDefinition, 9>& definitions()
        {
            static const std::array<PartDefinition, 9> kDefinitions = [] {
                std::array<PartDefinition, 9> defs{};

                PartDefinition& tank = defs[0];
                tank.id = kPartFuelTankMedium;
                tank.type = PartType::FuelTank;
                tank.name = "FT-16 Fuel Tank";
                tank.dryMassKg = 900.0;
                tank.costCredits = 1200.0;
                tank.volumeM3 = 21.0;
                tank.capacities[0] = {res::Resource::Fuel, 16000.0}; // 16 t
                tank.crashToleranceMps = 8.0;
                tank.breakingForceN = 4.0e5;
                tank.dragCoefficientArea = 1.6;
                tank.attachPoints[0] = stackTop(-2.1f);
                tank.attachPoints[1] = stackBottom(2.1f);
                tank.attachPoints[2] = radial(1.2f, 0.0f);
                tank.attachPoints[3] = radial(-1.2f, 0.0f);
                tank.attachPointCount = 4;

                PartDefinition& engine = defs[1];
                engine.id = kPartEngineVector;
                engine.type = PartType::Engine;
                engine.name = "V-400 Engine";
                engine.dryMassKg = 1400.0;
                engine.costCredits = 4200.0;
                engine.volumeM3 = 3.5;
                engine.crashToleranceMps = 10.0;
                engine.breakingForceN = 6.0e5;
                engine.dragCoefficientArea = 1.2;
                engine.thrustNewtons = 4.0e5; // 400 kN
                engine.specificImpulseS = 345.0;
                engine.attachPoints[0] = stackTop(-1.1f);
                engine.attachPointCount = 1;

                PartDefinition& fin = defs[2];
                fin.id = kPartFinBasic;
                fin.type = PartType::Wing;
                fin.name = "AV-F1 Fin";
                fin.dryMassKg = 90.0;
                fin.costCredits = 350.0;
                fin.volumeM3 = 0.4;
                fin.crashToleranceMps = 12.0;
                fin.breakingForceN = 1.5e5;
                fin.dragCoefficientArea = 0.25;
                fin.liftCoefficient = 1.1; // the future aero pass reads this
                fin.attachPoints[0] = radial(-0.9f, 0.0f);
                fin.attachPointCount = 1;

                PartDefinition& battery = defs[3];
                battery.id = kPartBatteryPack;
                battery.type = PartType::Battery;
                battery.name = "B-800 Battery";
                battery.dryMassKg = 60.0;
                battery.costCredits = 900.0;
                battery.volumeM3 = 0.12;
                battery.capacities[0] = {res::Resource::ElectricCharge, 800.0}; // kJ
                battery.crashToleranceMps = 10.0;
                battery.dragCoefficientArea = 0.1;
                battery.attachPoints[0] = radial(-0.35f, 0.0f);
                battery.attachPointCount = 1;

                PartDefinition& solar = defs[4];
                solar.id = kPartSolarWing;
                solar.type = PartType::SolarPanel;
                solar.name = "SP-2 Solar Wing";
                solar.dryMassKg = 75.0;
                solar.costCredits = 1500.0;
                solar.volumeM3 = 0.3;
                solar.crashToleranceMps = 6.0;
                solar.breakingForceN = 4.0e4;
                solar.dragCoefficientArea = 0.9;
                solar.chargeRateKw = 4.0; // kJ/s in sunlight
                solar.attachPoints[0] = radial(0.15f, 0.0f);
                solar.attachPointCount = 1;

                PartDefinition& dock = defs[5];
                dock.id = kPartDockingRing;
                dock.type = PartType::DockingPort;
                dock.name = "DR-1 Docking Ring";
                dock.dryMassKg = 320.0;
                dock.costCredits = 2200.0;
                dock.volumeM3 = 1.0;
                dock.crashToleranceMps = 8.0;
                dock.breakingForceN = 3.0e5;
                dock.dragCoefficientArea = 0.7;
                dock.attachPoints[0] = stackBottom(0.4f);
                dock.attachPoints[1] = stackTop(-0.4f); // the docking face
                dock.attachPointCount = 2;

                PartDefinition& decoupler = defs[6];
                decoupler.id = kPartDecouplerFlat;
                decoupler.type = PartType::Decoupler;
                decoupler.name = "DC-2 Decoupler";
                decoupler.dryMassKg = 140.0;
                decoupler.costCredits = 600.0;
                decoupler.volumeM3 = 0.5;
                decoupler.crashToleranceMps = 9.0;
                decoupler.breakingForceN = 2.5e5;
                decoupler.dragCoefficientArea = 0.4;
                decoupler.attachPoints[0] = stackTop(-0.25f);
                decoupler.attachPoints[1] = stackBottom(0.25f);
                decoupler.attachPointCount = 2;

                PartDefinition& cargo = defs[7];
                cargo.id = kPartCargoBaySmall;
                cargo.type = PartType::CargoBay;
                cargo.name = "CB-8 Cargo Bay";
                cargo.dryMassKg = 650.0;
                cargo.costCredits = 1800.0;
                cargo.volumeM3 = 8.0; // usable hold volume
                cargo.crashToleranceMps = 10.0;
                cargo.breakingForceN = 5.0e5;
                cargo.dragCoefficientArea = 1.4;
                cargo.attachPoints[0] = stackTop(-1.1f);
                cargo.attachPoints[1] = stackBottom(1.1f);
                cargo.attachPoints[2] = radial(1.25f, 0.0f);
                cargo.attachPoints[3] = radial(-1.25f, 0.0f);
                cargo.attachPointCount = 4;

                PartDefinition& core = defs[8];
                core.id = kPartCoreStructural;
                core.type = PartType::Structural;
                core.name = "SC-1 Command Core";
                core.dryMassKg = 1100.0;
                core.costCredits = 5200.0;
                core.volumeM3 = 5.0;
                core.crashToleranceMps = 14.0;
                core.breakingForceN = 8.0e5;
                core.dragCoefficientArea = 1.1;
                core.attachPoints[0] = stackTop(-1.3f);
                core.attachPoints[1] = stackBottom(1.3f);
                core.attachPoints[2] = radial(1.1f, 0.0f);
                core.attachPoints[3] = radial(-1.1f, 0.0f);
                core.attachPointCount = 4;

                return defs;
            }();
            return kDefinitions;
        }
    } // namespace

    std::span<const PartDefinition> catalog() { return definitions(); }

    const PartDefinition* findDefinition(u32 id)
    {
        for (const PartDefinition& definition : definitions())
        {
            if (definition.id == id)
            {
                return &definition;
            }
        }
        return nullptr;
    }

    // ------------------------------------------------------------------------
    // VesselAssemblySystem
    // ------------------------------------------------------------------------
    void VesselAssemblySystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        // Zero the accumulators.
        world.forEach<VesselComponent>([](ecs::Entity, VesselComponent& vessel) {
            vessel = VesselComponent{};
        });

        // Accumulate every part into its vessel.
        world.forEach<PartComponent>([&world](ecs::Entity entity, PartComponent& part) {
            auto* vessel = world.tryGetComponent<VesselComponent>(part.vessel);
            const PartDefinition* definition = findDefinition(part.definitionId);
            if (vessel == nullptr || definition == nullptr)
            {
                return;
            }
            vessel->dryMassKg += definition->dryMassKg;
            vessel->totalCostCredits += definition->costCredits;
            vessel->dragCoefficientArea += definition->dragCoefficientArea;
            vessel->solarChargeRateKw += definition->chargeRateKw;
            vessel->partCount += 1;
            if (definition->thrustNewtons > 0.0 && definition->specificImpulseS > 0.0)
            {
                vessel->maxThrustNewtons += definition->thrustNewtons;
                vessel->maxMassFlowKgps += definition->thrustNewtons /
                                           (definition->specificImpulseS * 9.80665);
            }

            // Carried resources weigh the vessel down (fuel above all).
            if (const auto* inventory =
                    world.tryGetComponent<factory::InventoryComponent>(entity))
            {
                for (const factory::InventorySlot& slot : inventory->slots)
                {
                    if (slot.resource != res::Resource::Count)
                    {
                        vessel->totalMassKg +=
                            slot.units * res::definition(slot.resource).massPerUnitKg;
                    }
                }
            }
        });

        // Push the aggregate into the vessel's rigid body.
        world.forEach<VesselComponent, phys::DynamicBodyComponent>(
            [](ecs::Entity, VesselComponent& vessel, phys::DynamicBodyComponent& body) {
                if (vessel.partCount == 0)
                {
                    return; // not part-built (EVA capsule, asteroid...)
                }
                vessel.totalMassKg += vessel.dryMassKg;
                body.mass = vessel.totalMassKg;
                body.ballisticFactor =
                    vessel.dragCoefficientArea / std::max(vessel.totalMassKg, 1.0);
            });
    }

    // ------------------------------------------------------------------------
    // PartAttachmentSystem
    // ------------------------------------------------------------------------
    void PartAttachmentSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        world.forEach<TransformComponent, PreviousTransformComponent, PartComponent>(
            [&world](ecs::Entity, TransformComponent& transform,
                     PreviousTransformComponent& previous, PartComponent& part) {
                const auto* vessel =
                    world.tryGetComponent<TransformComponent>(part.vessel);
                if (vessel == nullptr)
                {
                    return; // orphaned part: floats where it was
                }
                transform.position =
                    vessel->position + WorldVec3(vessel->rotation * part.localPosition);
                transform.rotation = vessel->rotation * part.localRotation;

                if (const auto* vesselPrevious =
                        world.tryGetComponent<PreviousTransformComponent>(part.vessel))
                {
                    previous.position =
                        vesselPrevious->position +
                        WorldVec3(vesselPrevious->rotation * part.localPosition);
                    previous.rotation = vesselPrevious->rotation * part.localRotation;
                }
                else
                {
                    previous.position = transform.position;
                    previous.rotation = transform.rotation;
                }
            });
    }
} // namespace sw::parts
