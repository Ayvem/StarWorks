#pragma once

// ============================================================================
// Gameplay/Parts.hpp
// THE PART SYSTEM — the foundation every future construction feature
// (rocket assembly, staging, docking, factories-on-wheels) builds on.
//
// Architecture, in three layers:
//
//  1. PartDefinition / PartCatalog — STATIC data. Every part type's mass,
//     cost, volume, resource capacities, strength, aerodynamics and attach
//     points live in a code-defined catalog (data files later; the lookup
//     API won't change). Definitions are addressed by a STABLE id.
//
//  2. PartComponent — one ECS ENTITY PER PART INSTANCE, referencing its
//     definition by id and its VESSEL by entity handle, with a vessel-local
//     pose. Entity-per-part is the property that makes the future free:
//     decoupling = reparenting part entities to a new vessel root; docking
//     = pointing them at a merged one; breaking = destroying one entity.
//     Resources carried by a part (fuel, charge) are an ordinary
//     factory::InventoryComponent ON the part entity — tanks are cargo.
//
//  3. Systems. VesselAssemblySystem aggregates parts into the vessel's
//     VesselComponent every physics tick (dry mass + carried resource mass
//     -> DynamicBody.mass, so the rocket equation simply EMERGES as fuel
//     burns; thrust, mass flow, drag area -> ballistic factor).
//     PartAttachmentSystem glues part transforms to their vessel's pose
//     (lockstep previous-transforms: parts interpolate with their vessel).
// ============================================================================

#include "ECS/System.hpp"
#include "Factory/FactoryComponents.hpp"
#include "Physics/PhysicsComponents.hpp"
#include "Resources/ResourceTypes.hpp"
#include "Scene/TransformComponents.hpp"

#include <span>
#include <string_view>

namespace sw::parts
{
    enum class PartType : u8
    {
        FuelTank = 0,
        Engine,
        Wing,
        Battery,
        SolarPanel,
        DockingPort,
        Decoupler,
        CargoBay,
        Structural,

        Count
    };

    /// A named attachment location on a part, in the part's local frame.
    struct AttachPoint
    {
        Vec3 position{0.0f};            // meters, part-local
        Vec3 direction{0.0f, 0.0f, 1.0f}; // outward normal of the joint
    };

    /// One resource capacity slot of a definition.
    struct ResourceCapacity
    {
        res::Resource resource = res::Resource::Count; // Count == unused
        f64 units = 0.0;                               // filled at build time
    };

    inline constexpr u32 kMaxAttachPoints = 6;
    inline constexpr u32 kMaxResourceCapacities = 2;

    /// Static description of a part model. Everything the game will ever
    /// ask about a part that is not per-instance state lives here.
    struct PartDefinition
    {
        u32 id = 0;                     // STABLE id (saved in instances)
        PartType type = PartType::Structural;
        std::string_view name;

        // ---- bulk properties -------------------------------------------------
        f64 dryMassKg = 100.0;
        f64 costCredits = 100.0;
        f64 volumeM3 = 1.0;

        // ---- resources carried (tanks, batteries...) --------------------------
        ResourceCapacity capacities[kMaxResourceCapacities]{};

        // ---- structure ---------------------------------------------------------
        f64 crashToleranceMps = 12.0;   // impact speed the part survives
        f64 breakingForceN = 2.0e5;     // joint strength (future structural sim)

        // ---- aerodynamics ------------------------------------------------------
        f64 dragCoefficientArea = 0.8;  // Cd * A, m^2 (feeds atmospheric drag)
        f64 liftCoefficient = 0.0;      // wings; used by the future aero pass

        // ---- function-specific -------------------------------------------------
        f64 thrustNewtons = 0.0;        // engines
        f64 specificImpulseS = 0.0;     // engines (fuel flow = F / (Isp*g0))
        f64 chargeRateKw = 0.0;         // solar panels: kJ/s generated

        // ---- connexions --------------------------------------------------------
        AttachPoint attachPoints[kMaxAttachPoints]{};
        u32 attachPointCount = 0;
    };

    /// The built-in catalog. Stable ids; lookup by id. Data-driven files
    /// can replace the storage later without touching call sites.
    [[nodiscard]] std::span<const PartDefinition> catalog();
    [[nodiscard]] const PartDefinition* findDefinition(u32 id);

    // Stable catalog ids (never renumber).
    inline constexpr u32 kPartFuelTankMedium = 1;
    inline constexpr u32 kPartEngineVector = 2;
    inline constexpr u32 kPartFinBasic = 3;
    inline constexpr u32 kPartBatteryPack = 4;
    inline constexpr u32 kPartSolarWing = 5;
    inline constexpr u32 kPartDockingRing = 6;
    inline constexpr u32 kPartDecouplerFlat = 7;
    inline constexpr u32 kPartCargoBaySmall = 8;
    inline constexpr u32 kPartCoreStructural = 9;

    // ---- per-instance components ------------------------------------------------

    struct PartComponent
    {
        u32 definitionId = 0;
        ecs::Entity vessel{};        // the vessel root this part belongs to
        Vec3 localPosition{0.0f};    // vessel-frame pose
        Quat localRotation{1.0f, 0.0f, 0.0f, 0.0f};
        f32 integrity = 1.0f;        // 1 = intact (future damage model)
    };

    /// On the vessel ROOT entity; refreshed by VesselAssemblySystem.
    struct VesselComponent
    {
        f64 dryMassKg = 0.0;
        f64 totalMassKg = 0.0;        // dry + carried resources
        f64 totalCostCredits = 0.0;
        f64 maxThrustNewtons = 0.0;   // all engines at full throttle
        f64 maxMassFlowKgps = 0.0;    // fuel burn at full throttle
        f64 dragCoefficientArea = 0.0;
        f64 solarChargeRateKw = 0.0;
        u32 partCount = 0;
    };

    static_assert(std::is_trivially_copyable_v<PartComponent>);
    static_assert(std::is_trivially_copyable_v<VesselComponent>);

    // ---- systems -----------------------------------------------------------------

    /// Physics lane, EARLY (before thrust/gravity): sums every part of every
    /// vessel into its VesselComponent and pushes mass/drag into the
    /// vessel's DynamicBody. Runs every tick — part counts are small and
    /// this is what makes fuel burn lighten the rocket.
    class VesselAssemblySystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "VesselAssemblySystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<VesselComponent>()
                .write<phys::DynamicBodyComponent>()
                .read<PartComponent>()
                .read<factory::InventoryComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };

    /// Physics lane, LATE (after integration/rails): parts ride their
    /// vessel rigidly — world pose = vessel pose composed with the local
    /// pose, previous derived from the vessel's previous (interpolation in
    /// lockstep, the same rule as surface anchors).
    class PartAttachmentSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "PartAttachmentSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<PartComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };
} // namespace sw::parts
