// ============================================================================
// PartsTests.cpp — the part system: catalog integrity, vessel aggregation
// (mass/thrust/drag from parts + carried resources) and rigid attachment.
// ============================================================================

#include "TestFramework.hpp"

#include <ECS/World.hpp>
#include <Gameplay/Parts.hpp>

#include <cmath>

using namespace sw;
using namespace sw::parts;

SW_TEST(PartCatalogCoversEveryTypeWithSaneData)
{
    // Every one of the 9 part types exists, ids are unique and stable,
    // and every definition exposes the full property sheet.
    bool typeSeen[static_cast<usize>(PartType::Count)] = {};
    u32 seenIds[64] = {};
    usize idCount = 0;
    for (const PartDefinition& definition : catalog())
    {
        typeSeen[static_cast<usize>(definition.type)] = true;
        for (usize i = 0; i < idCount; ++i)
        {
            SW_CHECK(seenIds[i] != definition.id); // unique ids
        }
        seenIds[idCount++] = definition.id;

        SW_CHECK(definition.dryMassKg > 0.0);
        SW_CHECK(definition.costCredits > 0.0);
        SW_CHECK(definition.volumeM3 > 0.0);
        SW_CHECK(definition.crashToleranceMps > 0.0);
        SW_CHECK(definition.breakingForceN > 0.0);
        SW_CHECK(definition.dragCoefficientArea > 0.0);
        SW_CHECK(definition.attachPointCount > 0); // every part connects
        SW_CHECK(!definition.name.empty());
        SW_CHECK(findDefinition(definition.id) == &definition);
    }
    for (usize type = 0; type < static_cast<usize>(PartType::Count); ++type)
    {
        SW_CHECK(typeSeen[type]);
    }
    // Function-specific data.
    SW_CHECK(findDefinition(kPartEngineVector)->thrustNewtons > 0.0);
    SW_CHECK(findDefinition(kPartEngineVector)->specificImpulseS > 0.0);
    SW_CHECK(findDefinition(kPartSolarWing)->chargeRateKw > 0.0);
    SW_CHECK(findDefinition(kPartFinBasic)->liftCoefficient > 0.0);
    SW_CHECK(findDefinition(kPartFuelTankMedium)->capacities[0].resource ==
             res::Resource::Fuel);
}

SW_TEST(VesselAssemblyAggregatesPartsAndCargo)
{
    ecs::World world;

    // Vessel root.
    const ecs::Entity root = world.createEntity();
    world.addComponent(root, TransformComponent{});
    world.addComponent(root, VesselComponent{});
    world.addComponent(root, phys::DynamicBodyComponent{{0.0, 0.0, 0.0}, 1.0});

    auto addPart = [&world, root](u32 definitionId, const Vec3& localPosition) {
        const ecs::Entity part = world.createEntity();
        world.addComponent(part, TransformComponent{});
        world.addComponent(part, PreviousTransformComponent{});
        PartComponent component{};
        component.definitionId = definitionId;
        component.vessel = root;
        component.localPosition = localPosition;
        world.addComponent(part, component);
        return part;
    };
    addPart(kPartCoreStructural, {0.0f, 0.0f, -3.0f});
    const ecs::Entity tank = addPart(kPartFuelTankMedium, {0.0f, 0.0f, 0.0f});
    addPart(kPartEngineVector, {0.0f, 0.0f, 3.0f});

    factory::InventoryComponent inventory{};
    inventory.volumeCapacityM3 = 21.0;
    factory::inventoryAdd(inventory, res::Resource::Fuel, 16000.0);
    world.addComponent(tank, inventory);

    VesselAssemblySystem assembly;
    assembly.update(world, 0.02f);

    const auto& vessel = world.getComponent<VesselComponent>(root);
    const f64 expectedDry = findDefinition(kPartCoreStructural)->dryMassKg +
                            findDefinition(kPartFuelTankMedium)->dryMassKg +
                            findDefinition(kPartEngineVector)->dryMassKg;
    SW_CHECK_EQ(vessel.partCount, 3u);
    SW_CHECK(std::abs(vessel.dryMassKg - expectedDry) < 1.0e-6);
    // Total = dry + 16 t of fuel (1 unit = 1 kg), pushed into the body.
    SW_CHECK(std::abs(vessel.totalMassKg - (expectedDry + 16000.0)) < 1.0e-6);
    const auto& body = world.getComponent<phys::DynamicBodyComponent>(root);
    SW_CHECK(std::abs(body.mass - vessel.totalMassKg) < 1.0e-6);
    SW_CHECK(std::abs(vessel.maxThrustNewtons - 4.0e5) < 1.0);
    // Mass flow = F / (Isp * g0).
    SW_CHECK(std::abs(vessel.maxMassFlowKgps - 4.0e5 / (345.0 * 9.80665)) < 1.0e-6);
    SW_CHECK(body.ballisticFactor > 0.0);

    // Burn half the fuel: the vessel gets lighter on the next pass — the
    // rocket equation emerges from cargo mass alone.
    factory::inventoryRemove(world.getComponent<factory::InventoryComponent>(tank),
                             res::Resource::Fuel, 8000.0);
    assembly.update(world, 0.02f);
    SW_CHECK(std::abs(world.getComponent<VesselComponent>(root).totalMassKg -
                      (expectedDry + 8000.0)) < 1.0e-6);
}

SW_TEST(PartsRideTheirVesselRigidly)
{
    ecs::World world;

    const ecs::Entity root = world.createEntity();
    TransformComponent rootTransform{};
    rootTransform.position = {1000.0, 2000.0, 3000.0};
    rootTransform.rotation =
        glm::angleAxis(1.2f, glm::normalize(Vec3{0.3f, 1.0f, 0.2f}));
    world.addComponent(root, rootTransform);
    world.addComponent(root, PreviousTransformComponent{{900.0, 2000.0, 3000.0},
                                                        rootTransform.rotation});

    const ecs::Entity part = world.createEntity();
    world.addComponent(part, TransformComponent{});
    world.addComponent(part, PreviousTransformComponent{});
    PartComponent component{};
    component.definitionId = kPartFuelTankMedium;
    component.vessel = root;
    component.localPosition = {0.0f, 0.0f, 4.0f};
    world.addComponent(part, component);

    PartAttachmentSystem attachment;
    attachment.update(world, 0.02f);

    const auto& transform = world.getComponent<TransformComponent>(part);
    const WorldVec3 expected =
        rootTransform.position +
        WorldVec3(rootTransform.rotation * Vec3{0.0f, 0.0f, 4.0f});
    SW_CHECK(glm::length(transform.position - expected) < 1.0e-4);
    // Previous derived from the vessel's previous: lockstep interpolation.
    const auto& previous = world.getComponent<PreviousTransformComponent>(part);
    SW_CHECK(std::abs(previous.position.x -
                      (900.0 + (expected.x - 1000.0))) < 1.0e-4);
}
