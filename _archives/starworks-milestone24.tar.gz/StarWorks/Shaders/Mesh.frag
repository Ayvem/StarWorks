#version 450

// ============================================================================
// Mesh.frag — the M21 visual overhaul.
//
//  - Blinn-Phong SPECULAR + fresnel sheen, driven by a per-vertex material
//    channel (uv.x = specular strength, uv.y = glossiness) — oceans glint,
//    hulls shine, regolith stays matte (uv = 0).
//  - AERIAL PERSPECTIVE: exponential distance fog toward the horizon color
//    + sky-scattered ambient, both fed per frame by the game from the
//    camera's altitude and the local sun elevation (sunsets included).
//  - ATMOSPHERE SHELLS (instance tint alpha > 2.5): fresnel limb glow —
//    a bright rim of air when seen from orbit, a glowing horizon band
//    from inside — lit day-side by the real sun direction.
//  - CINEMATIC GRADE (M24): Hable filmic curve (gentler shoulder than
//    ACES), tunable contrast / saturation / black lift, WRAP diffuse for a
//    soft terminator, penumbra'd eclipse shadows, and a hash dither that
//    kills gradient banding. All knobs are the named constants below.
// ============================================================================

layout(set = 0, binding = 0) uniform CameraUniforms
{
    mat4 viewProjection;
    vec4 cameraPosition;    // xyz = world position
    vec4 sunPosition;       // xyz = camera-relative sun position, w = shadow count
    vec4 shadowSpheres[8];  // xyz = camera-relative center, w = radius
    vec4 fogColorDensity;   // xyz = horizon color, w = fog density
    vec4 skyAmbient;        // xyz = sky-scattered ambient
} uCamera;

layout(location = 0) in vec3 vWorldNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUv;
layout(location = 3) in vec3 vWorldPosition;
layout(location = 4) flat in float vTintAlpha;
layout(location = 5) in vec3 vModelPosition;

layout(location = 0) out vec4 outColor;

const vec3 kSunColor = vec3(1.0, 0.96, 0.9);
const vec3 kAmbient = vec3(0.020, 0.024, 0.035); // faint cold space ambient

// ============================================================================
// Procedural planet noise — an EXACT GLSL port of Math/Noise.hpp. The CPU
// samples these very functions for terrain COLLISION and the cloud cover;
// matching them bit-for-bit keeps coastlines and mountains collision-true
// at per-fragment sharpness (the whole point of the M23 close-orbit path).
// ============================================================================
float hashToUnitFloat(uint x)
{
    x ^= 2747636419u;
    x *= 2654435769u;
    x ^= x >> 16;
    x *= 2654435769u;
    x ^= x >> 16;
    return float(x & 0xFFFFFFu) / 16777216.0;
}

float latticeHash(ivec3 cell, uint seed)
{
    const uint h = uint(cell.x) * 374761393u + uint(cell.y) * 668265263u +
                   uint(cell.z) * 1274126177u + seed * 2246822519u;
    return hashToUnitFloat(h);
}

float valueNoise3(vec3 p, uint seed)
{
    const vec3 cell = floor(p);
    const vec3 f = p - cell;
    const vec3 u = f * f * (3.0 - 2.0 * f);
    const ivec3 c = ivec3(cell);
    const float x00 = mix(latticeHash(c, seed),
                          latticeHash(c + ivec3(1, 0, 0), seed), u.x);
    const float x10 = mix(latticeHash(c + ivec3(0, 1, 0), seed),
                          latticeHash(c + ivec3(1, 1, 0), seed), u.x);
    const float x01 = mix(latticeHash(c + ivec3(0, 0, 1), seed),
                          latticeHash(c + ivec3(1, 0, 1), seed), u.x);
    const float x11 = mix(latticeHash(c + ivec3(0, 1, 1), seed),
                          latticeHash(c + ivec3(1, 1, 1), seed), u.x);
    return mix(mix(x00, x10, u.y), mix(x01, x11, u.y), u.z);
}

float fbm3(vec3 p, int octaves, uint seed)
{
    float sum = 0.0;
    float amplitude = 0.5;
    vec3 q = p;
    for (int i = 0; i < octaves; ++i)
    {
        sum += amplitude * valueNoise3(q, seed + uint(i) * 101u);
        q *= 2.03;
        amplitude *= 0.5;
    }
    return sum;
}

// Palettes mirror colorizeCelestial (the far-LOD vertex colors): the swap
// between vertex and fragment shading is invisible except for SHARPNESS.
// `detail` adds sub-vertex albedo variation the vertex path cannot carry.
void planetSurface(int style, vec3 dir, out vec3 albedo, out float specular,
                   out float gloss)
{
    specular = 0.0;
    gloss = 0.0;
    const float detail = fbm3(dir * 42.0, 3, 90210u) - 0.5;
    if (style == 0) // Terra
    {
        const float h = fbm3(dir * 2.3 + vec3(7.31, 1.17, 4.73), 5, 1337u);
        const float latitude = abs(dir.y);
        const float iceEdge = 0.91 + 0.03 * (fbm3(dir * 6.0, 3, 555u) - 0.5);
        if (latitude > iceEdge)
        {
            albedo = vec3(0.92, 0.94, 0.97) * (1.0 + detail * 0.12);
            specular = 0.30;
            gloss = 0.45;
        }
        else if (h < 0.50) // ocean: deep -> shelf -> turquoise shallows
        {
            const float depth = clamp(h / 0.50, 0.0, 1.0);
            const float shallow = clamp((h - 0.482) / 0.018, 0.0, 1.0);
            albedo = vec3(mix(mix(0.02, 0.06, depth), 0.07, shallow),
                          mix(mix(0.09, 0.24, depth), 0.35, shallow),
                          mix(mix(0.24, 0.42, depth), 0.44, shallow));
            albedo *= (1.0 + detail * 0.08);
            specular = 0.55;
            gloss = 0.80;
        }
        else // land: sand -> lowland -> highland -> peaks
        {
            const float relief = clamp((h - 0.50) / 0.30, 0.0, 1.0);
            const float sand = 1.0 - clamp((h - 0.50) / 0.035, 0.0, 1.0);
            const vec3 lowland =
                mix(vec3(0.16, 0.34, 0.13), vec3(0.62, 0.56, 0.38), sand);
            const vec3 highland = vec3(0.42, 0.34, 0.20);
            const vec3 peaks = vec3(0.48, 0.44, 0.40);
            const vec3 land = (relief < 0.6)
                                  ? mix(lowland, highland, relief / 0.6)
                                  : mix(highland, peaks, (relief - 0.6) / 0.4);
            albedo = land * (1.0 + detail * 0.30);
        }
    }
    else if (style == 1) // Luna: maria over cratered highlands
    {
        const float m = fbm3(dir * 3.1 + vec3(2.9, 8.1, 0.4), 4, 4242u);
        const float fine = fbm3(dir * 11.0, 3, 4343u);
        const float g = (m < 0.47 ? 0.24 : 0.42) + 0.16 * (fine - 0.5) +
                        detail * 0.10;
        albedo = vec3(g, g, g * 1.04);
    }
    else // Mars: rust with CO2 caps
    {
        const float h = fbm3(dir * 2.8 + vec3(5.5, 3.3, 9.9), 5, 900u);
        if (abs(dir.y) > 0.93)
        {
            albedo = vec3(0.90, 0.88, 0.86) * (1.0 + detail * 0.10);
            specular = 0.25;
            gloss = 0.40;
        }
        else
        {
            albedo = mix(vec3(0.36, 0.17, 0.09), vec3(0.66, 0.36, 0.18), h) *
                     (1.0 + detail * 0.24);
        }
    }
}

// ============================================================================
// CINEMATIC GRADE — the whole look lives in these knobs.
// ============================================================================
const float kExposure = 1.0;    // linear pre-exposure
const float kContrast = 0.90;   // < 1 = flatter, film-like (pivot 0.42)
const float kSaturation = 0.90; // < 1 = desaturated, cinematic
const vec3 kBlackLift = vec3(0.010, 0.012, 0.016); // faintly cool raised blacks
const float kDiffuseWrap = 0.22; // soft terminator (0 = hard lambert)
const float kPenumbra = 0.35;    // eclipse softness (fraction of occluder radius)

// Hable (Uncharted 2) filmic curve: gentler shoulder and far less
// saturation push than the ACES fit — highlights roll off instead of
// clipping toward primaries.
vec3 hable(vec3 x)
{
    const float A = 0.15;
    const float B = 0.50;
    const float C = 0.10;
    const float D = 0.20;
    const float E = 0.02;
    const float F = 0.30;
    return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
}

vec3 gradeCinematic(vec3 color)
{
    // Filmic curve, normalized to a 4.0 white point.
    const vec3 mapped = hable(color * kExposure) / hable(vec3(4.0)).x;
    // Contrast around a filmic pivot (in the tonemapped domain).
    vec3 graded = (mapped - 0.42) * kContrast + 0.42;
    // Desaturate toward luminance.
    const float luminance = dot(graded, vec3(0.2126, 0.7152, 0.0722));
    graded = mix(vec3(luminance), graded, kSaturation);
    // Raised, slightly cool blacks: shadows breathe instead of crushing.
    graded = kBlackLift + graded * (1.0 - kBlackLift);
    return clamp(graded, 0.0, 1.0);
}

// Screen-space hash dither: +-0.5/255 hides the banding that smooth sky
// and terminator gradients otherwise show on an 8-bit swapchain.
float ditherOffset(vec2 fragCoord)
{
    const float noise = fract(sin(dot(fragCoord, vec2(12.9898, 78.233))) * 43758.5453);
    return (noise - 0.5) / 255.0;
}

void main()
{
    const vec3 viewDir = normalize(-vWorldPosition); // camera at the origin
    const float fragmentDistance = length(vWorldPosition);

    // ---- PROCEDURAL PLANET SURFACE (instance tint alpha > 3.5) ---------------
    // Close orbit: vertex colors blur when the globe fills the screen, so
    // the game swaps the surface to per-fragment shading. The model-space
    // position IS the body-frame direction (the mesh rotates with the
    // planet), so features stay glued to the ground.
    vec3 surfaceAlbedo = vColor.rgb;
    float surfaceAlpha = vColor.a;
    float materialSpecular = clamp(vUv.x, 0.0, 1.0);
    float materialGloss = clamp(vUv.y, 0.0, 1.0);
    if (vTintAlpha > 3.5)
    {
        const int style = int(round((vTintAlpha - 3.6) * 10.0));
        planetSurface(style, normalize(vModelPosition), surfaceAlbedo,
                      materialSpecular, materialGloss);
        surfaceAlpha = 1.0;
    }
    // ---- ATMOSPHERE SHELL material (instance tint alpha in (2.5, 3.5]) -------
    // Fresnel limb glow: air is thickest along grazing view rays — the rim
    // of a planet from orbit, the horizon band from inside. Day side lit
    // by the true sun direction with a soft wrap (twilight ring).
    else if (vTintAlpha > 2.5)
    {
        const vec3 normal = normalize(vWorldNormal);
        const vec3 lightDir = normalize(uCamera.sunPosition.xyz - vWorldPosition);
        const float baseAlpha = clamp(vColor.a / 3.0, 0.0, 1.0);
        const float grazing = 1.0 - abs(dot(normal, viewDir));
        const float limb = pow(clamp(grazing, 0.0, 1.0), 2.4);
        const float dayWrap = clamp(dot(normal, lightDir) * 0.65 + 0.42, 0.0, 1.0);
        const vec3 air = vColor.rgb * (0.22 + 1.15 * dayWrap);
        const float alpha = baseAlpha * (0.30 + 1.55 * limb) * (0.15 + 0.85 * dayWrap);
        outColor = vec4(gradeCinematic(air) + ditherOffset(gl_FragCoord.xy),
                        clamp(alpha, 0.0, 1.0));
        return;
    }

    // ---- EMISSIVE convention: alpha in (1, 2] = self-lit --------------------
    // (star, beacons, plasma, glow discs). Opacity = alpha - 1; the 1..2
    // interpolation range gives soft radial falloffs for free.
    else if (vColor.a > 1.0001)
    {
        outColor = vec4(gradeCinematic(vColor.rgb),
                        clamp(vColor.a - 1.0, 0.0, 1.0));
        return;
    }

    const vec3 normal = normalize(vWorldNormal);

    // Light direction PER FRAGMENT from the star's actual position.
    const vec3 toSun = uCamera.sunPosition.xyz - vWorldPosition;
    const float distanceToSun = length(toSun);
    const vec3 lightDir = toSun / max(distanceToSun, 1.0e-3);
    // WRAP diffuse: light bleeds a little past the geometric terminator
    // (atmosphere/bounce stand-in) — the day/night line becomes a soft
    // gradient instead of a hard cut. Normalized so noon stays at 1.
    const float wrapped =
        (dot(normal, lightDir) + kDiffuseWrap) / (1.0 + kDiffuseWrap);
    const float lambert = max(wrapped, 0.0) * max(sign(wrapped), 0.0);

    // Analytic eclipse: no light behind a planet (stable small-number form).
    // Analytic eclipse with a PENUMBRA: instead of a binary hit test, the
    // ray's closest-approach distance to the occluder sphere fades the
    // light across kPenumbra of the radius — planetary shadows get the
    // soft edge a real sun's angular size produces.
    float shadow = 1.0;
    const int shadowCount = int(uCamera.sunPosition.w);
    for (int i = 0; i < shadowCount; ++i)
    {
        const vec3 m = vWorldPosition - uCamera.shadowSpheres[i].xyz;
        const float r = uCamera.shadowSpheres[i].w;
        const float b = dot(m, lightDir);
        if (b >= 0.0 || -b > distanceToSun)
        {
            continue; // occluder behind the fragment or beyond the sun
        }
        const float missSq = dot(m, m) - b * b; // closest approach, squared
        const float miss = sqrt(max(missSq, 0.0));
        const float inner = r * (1.0 - kPenumbra);
        const float occlusion = 1.0 - smoothstep(inner, r * (1.0 + kPenumbra), miss);
        shadow = min(shadow, 1.0 - occlusion);
        if (shadow <= 0.0)
        {
            break;
        }
    }

    // ---- material: uv.x = specular strength, uv.y = glossiness ----------------
    // (overridden by the procedural planet path above.)
    const float specularStrength = materialSpecular;
    const float glossiness = materialGloss;
    vec3 specular = vec3(0.0);
    if (specularStrength > 0.001 && lambert > 0.0)
    {
        const vec3 halfway = normalize(lightDir + viewDir);
        const float exponent = mix(12.0, 260.0, glossiness);
        const float highlight = pow(max(dot(normal, halfway), 0.0), exponent);
        // Fresnel-boosted at grazing angles (ocean sun glitter).
        const float fresnel =
            0.35 + 0.65 * pow(1.0 - max(dot(normal, viewDir), 0.0), 3.0);
        specular = kSunColor * (highlight * specularStrength * fresnel * shadow);
    }

    // Ambient = cold space floor + the game's sky-scattered light; a hint
    // of fill from the sky color on upward-facing surfaces.
    const vec3 ambient = kAmbient + uCamera.skyAmbient.xyz;
    const vec3 lit =
        surfaceAlbedo * (ambient + kSunColor * (lambert * shadow)) + specular;

    // ---- aerial perspective ----------------------------------------------------
    // Exponential extinction toward the horizon color. Density comes from
    // the camera's air density; the color already encodes day/sunset/night.
    const float fogDensity = uCamera.fogColorDensity.w;
    vec3 finalColor = lit;
    if (fogDensity > 0.0)
    {
        const float fogFactor =
            1.0 - exp(-fogDensity * fragmentDistance);
        finalColor = mix(lit, uCamera.fogColorDensity.xyz, clamp(fogFactor, 0.0, 0.97));
    }

    const vec3 graded =
        gradeCinematic(finalColor) + ditherOffset(gl_FragCoord.xy);
    outColor = vec4(graded, surfaceAlpha);
}
