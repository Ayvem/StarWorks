# StarWorks

An industrial space simulation game — mine, automate, build ships and stations, and grow a civilization that spans a star system. Powered by a bespoke C++20 / Vulkan engine written exclusively for this game.

## Current state — Milestone 4: Multi-rate simulation

Gameplay logic now runs in fixed-timestep simulation lanes (Physics 50 Hz, Logistics 10 Hz, Automation 5 Hz, Economy 2 Hz, World 1 Hz), fully decoupled from rendering: the renderer interpolates transforms between Physics ticks, pausing stops the simulation while the camera keeps flying, and time scale (0.25×–4× on keys 1/2/3, Space to pause) changes tick counts but never tick size. Structural ECS changes from parallel systems go through a deferred, thread-safe command buffer.

Milestone 3 foundations: archetype ECS with contiguous SoA storage, generation-checked handles, access-declared systems scheduled in conflict-free parallel stages on the engine thread pool, and a CTest-integrated unit suite (17 tests).

Milestone 2 foundations: VMA-backed GPU memory with RAII wrappers and staging uploads, reverse-Z depth buffer, per-frame camera UBO via descriptor sets, procedural primitives (cube/sphere/grid), cgltf-based glTF importer. `--cpu` selects a software Vulkan device (llvmpipe) with zero code differences — the whole engine runs CPU-only today and will use the GPU the moment one is preferred.

Milestone 1 foundations: logging, assertions/error handling, frame clock, GLFW window layer, input snapshots, camera + controller, Vulkan 1.3 (dynamic rendering, synchronization2), swapchain with live resize, build-time GLSL → SPIR-V compilation.

## Requirements

- CMake ≥ 3.24
- A C++20 compiler (Visual Studio 2022 on Windows, GCC 13+/Clang 16+ on Linux)
- The [Vulkan SDK](https://vulkan.lunarg.com/) (headers, loader, glslangValidator, validation layers)
- A GPU + driver supporting Vulkan 1.3

GLFW 3.4 and GLM 1.0.1 are fetched and built automatically by CMake.

## Building (Windows / Visual Studio 2022)

```powershell
cmake --preset windows-msvc
cmake --build --preset windows-debug
build\windows\bin\Debug\StarWorks.exe
```

Or open `build/windows/StarWorks.sln` in Visual Studio and run the `StarWorks` startup project (F5).

## Building (Linux)

```bash
cmake --preset linux-debug
cmake --build --preset linux-debug -j
./build/linux-debug/bin/StarWorks
```

## Running the tests

```powershell
ctest --test-dir build/windows -C Debug --output-on-failure   # Windows
ctest --test-dir build/linux-debug --output-on-failure        # Linux
```

## Controls

Hold the right mouse button to look around. `WASD` to move, `Q`/`E` down/up, `Shift` to boost, mouse wheel to change speed. `Space` pauses the simulation, `1`/`2`/`3` set the time scale to 0.25×/1×/4×. `Esc` quits.

## Useful flags

`--frames N` exits after N frames (soak testing); `--log-file path.log` mirrors the log to a file; `--cpu` prefers a software (CPU) Vulkan device over hardware GPUs.

## Repository layout

See `docs/Architecture.md` for the module map, engineering conventions, and the development log.
