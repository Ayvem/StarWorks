#version 450

// ============================================================================
// Mesh.vert — static mesh vertex shader.
// Camera data arrives in a per-frame UBO (set 0, binding 0); the model
// matrix arrives as a push constant. Both layouts are mirrored in
// Renderer.hpp (CameraUniforms / MeshPushConstants) — keep them in sync.
// ============================================================================

layout(set = 0, binding = 0) uniform CameraUniforms
{
    mat4 viewProjection;
    vec4 cameraPosition;  // xyz = world position
    vec4 sunDirection;    // xyz = direction from sun toward scene, normalized
} uCamera;

layout(push_constant) uniform MeshPushConstants
{
    mat4 model;
} pc;

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;
layout(location = 3) in vec2 inUv;

layout(location = 0) out vec3 vWorldNormal;
layout(location = 1) out vec4 vColor;
layout(location = 2) out vec2 vUv;
layout(location = 3) out vec3 vWorldPosition;

void main()
{
    const vec4 worldPosition = pc.model * vec4(inPosition, 1.0);
    gl_Position = uCamera.viewProjection * worldPosition;

    // Assumes uniform scale (engine convention for now). A dedicated normal
    // matrix will accompany skinned/non-uniformly-scaled meshes later.
    vWorldNormal = normalize(mat3(pc.model) * inNormal);
    vColor = inColor;
    vUv = inUv;
    vWorldPosition = worldPosition.xyz;
}
