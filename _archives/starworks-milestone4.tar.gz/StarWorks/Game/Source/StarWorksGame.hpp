#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 4: all gameplay logic runs inside the
// multi-rate Simulation (Physics 50 Hz, Logistics 10 Hz, World 1 Hz here);
// rendering interpolates transforms between Physics ticks and never drives
// the simulation. Space pauses, keys 1/2/3 change the time scale — the
// renderer keeps running at full rate either way.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        void buildScene();
        void collectRenderObjects();

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Mesh table: MeshComponent::meshIndex points in here (asset-ID
        // precursor; becomes the Assets registry in a later milestone).
        std::vector<sw::Mesh> m_meshes;

        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation

        std::vector<sw::RenderObject> m_renderObjects;
    };
} // namespace game
