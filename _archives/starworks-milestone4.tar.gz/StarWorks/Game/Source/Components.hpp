#pragma once

// ============================================================================
// Components.hpp — game-side ECS components.
// All components follow the engine rule: trivially copyable, no owning
// members. Meshes are referenced by index into the game's mesh table (an
// asset-ID precursor), never by pointer — save-file friendly by design.
// ============================================================================

#include <Engine.hpp>

namespace game
{
    struct TransformComponent
    {
        sw::Vec3 position{0.0f};
        sw::Quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
        sw::f32 uniformScale = 1.0f;

        [[nodiscard]] sw::Mat4 matrix() const
        {
            return glm::translate(sw::Mat4{1.0f}, position) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{uniformScale});
        }
    };

    /// Snapshot of the transform at the PREVIOUS Physics tick. Written by
    /// SnapshotSystem at the start of each tick; the renderer interpolates
    /// between this and TransformComponent using the Physics lane's alpha.
    struct PreviousTransformComponent
    {
        sw::Vec3 position{0.0f};
        sw::Quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
    };

    /// Constant-rate self rotation around a fixed axis.
    struct SpinComponent
    {
        sw::Vec3 axis{0.0f, 1.0f, 0.0f};
        sw::f32 radiansPerSecond = 1.0f;
    };

    /// Logistics-lane data: modulates a debris orbit speed over time.
    struct DebrisComponent
    {
        sw::f32 baseOrbitSpeed = 0.1f;
        sw::f32 modulationPhase = 0.0f;
    };

    /// Circular orbit around a fixed center (placeholder until real orbital
    /// mechanics arrive with the Physics module).
    struct OrbitComponent
    {
        sw::Vec3 center{0.0f};
        sw::f32 radius = 5.0f;
        sw::f32 radiansPerSecond = 0.3f;
        sw::f32 phase = 0.0f;      // current angle, integrated each tick
        sw::f32 verticalWobble = 0.0f;
    };

    /// Reference into StarWorksGame's mesh table.
    struct MeshComponent
    {
        sw::u32 meshIndex = 0;
    };

    static_assert(std::is_trivially_copyable_v<TransformComponent>);
    static_assert(std::is_trivially_copyable_v<PreviousTransformComponent>);
    static_assert(std::is_trivially_copyable_v<SpinComponent>);
    static_assert(std::is_trivially_copyable_v<OrbitComponent>);
    static_assert(std::is_trivially_copyable_v<DebrisComponent>);
    static_assert(std::is_trivially_copyable_v<MeshComponent>);
} // namespace game
