#pragma once

// ============================================================================
// Systems.hpp — game-side ECS systems.
//
// Access declarations drive the scheduler's staging:
//   OrbitSystem  writes Transform (position), reads Orbit (phase is written
//                too, so Orbit is declared written).
//   SpinSystem   writes Transform (rotation), reads Spin.
// Both write TransformComponent, so they land in consecutive stages and
// never race — verified by the scheduler unit tests.
// ============================================================================

#include "Components.hpp"

namespace game
{
    /// First system of the Physics lane: snapshots each transform so the
    /// renderer can interpolate between the previous and current tick.
    class SnapshotSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "SnapshotSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .read<TransformComponent>()
                .write<PreviousTransformComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// Logistics lane (10 Hz): slowly modulates debris orbital speeds — a
    /// first taste of low-frequency lanes driving high-frequency state.
    class DebrisFlowSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "DebrisFlowSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<DebrisComponent>()
                .write<OrbitComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    /// World lane (1 Hz): periodic simulation statistics to the log.
    class StatsSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "StatsSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return {}; // reads only entity counts — no component data access
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;

    private:
        sw::u64 m_ticks = 0;
    };

    class OrbitSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "OrbitSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<OrbitComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };

    class SpinSystem final : public sw::ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override { return "SpinSystem"; }

        [[nodiscard]] sw::ecs::SystemAccess access() const override
        {
            return sw::ecs::SystemAccess{}
                .write<TransformComponent>()
                .read<SpinComponent>();
        }

        void update(sw::ecs::World& world, sw::f32 deltaSeconds) override;
    };
} // namespace game
