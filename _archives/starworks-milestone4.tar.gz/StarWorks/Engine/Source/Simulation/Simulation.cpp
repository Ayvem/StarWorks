#include "Simulation/Simulation.hpp"

#include "Core/Assert.hpp"
#include "Core/Log.hpp"

#include <algorithm>
#include <cmath>

namespace sw::sim
{
    namespace
    {
        constexpr const char* kLogCat = "Simulation";
    } // namespace

    // ------------------------------------------------------------------------
    // SimulationLane
    // ------------------------------------------------------------------------
    SimulationLane::SimulationLane(const LaneConfig& config)
        : m_config(config)
    {
        SW_ASSERT(config.frequencyHz > 0.0f, "Lane '{}' needs a positive frequency",
                  config.name);
        SW_ASSERT(config.maxTicksPerFrame > 0, "Lane '{}' needs maxTicksPerFrame >= 1",
                  config.name);
        m_stepSeconds = 1.0 / static_cast<f64>(m_config.frequencyHz);
    }

    void SimulationLane::advance(f64 scaledDeltaSeconds, ecs::World& world, ThreadPool* pool)
    {
        m_accumulator += scaledDeltaSeconds;

        u32 ticksThisFrame = 0;
        const f32 fixedDt = static_cast<f32>(m_stepSeconds);
        while (m_accumulator >= m_stepSeconds && ticksThisFrame < m_config.maxTicksPerFrame)
        {
            m_scheduler.run(world, fixedDt, pool);
            m_accumulator -= m_stepSeconds;
            ++m_tickCount;
            ++ticksThisFrame;
        }

        // Catch-up bound hit: drop the backlog instead of spiraling. The
        // simulation slows down relative to wall clock but the app stays
        // responsive; log sparsely (first event, then every 64th).
        if (m_accumulator >= m_stepSeconds)
        {
            const f64 dropped = m_accumulator - std::fmod(m_accumulator, m_stepSeconds);
            m_accumulator = std::fmod(m_accumulator, m_stepSeconds);
            if ((m_droppedTimeEvents++ & 63) == 0)
            {
                SW_LOG_WARN(kLogCat,
                            "Lane '{}' dropped {:.3f}s of backlog (frame too slow for {} Hz "
                            "x{} catch-up ticks)",
                            m_config.name, dropped, m_config.frequencyHz,
                            m_config.maxTicksPerFrame);
            }
        }
    }

    // ------------------------------------------------------------------------
    // Simulation
    // ------------------------------------------------------------------------
    Simulation::Simulation(std::vector<LaneConfig> laneConfigs)
    {
        SW_ASSERT(!laneConfigs.empty(), "Simulation needs at least one lane");
        m_lanes.reserve(laneConfigs.size());
        for (const LaneConfig& config : laneConfigs)
        {
            m_lanes.push_back(std::make_unique<SimulationLane>(config));
            SW_LOG_INFO(kLogCat, "Lane '{}' at {} Hz (step {:.4f}s, catch-up {} ticks/frame)",
                        config.name, config.frequencyHz,
                        1.0 / static_cast<f64>(config.frequencyHz), config.maxTicksPerFrame);
        }
    }

    std::vector<LaneConfig> Simulation::defaultLanes()
    {
        return {
            {"Physics", 50.0f, 8},
            {"Logistics", 10.0f, 4},
            {"Automation", 5.0f, 4},
            {"Economy", 2.0f, 2},
            {"World", 1.0f, 2},
        };
    }

    void Simulation::advance(ecs::World& world, f32 frameDeltaSeconds, ThreadPool* pool)
    {
        if (m_paused || frameDeltaSeconds <= 0.0f)
        {
            return;
        }

        const f64 scaled = static_cast<f64>(frameDeltaSeconds) * m_timeScale;
        m_simulatedSeconds += scaled;

        // Fixed lane order == configuration order: deterministic.
        for (const std::unique_ptr<SimulationLane>& lane : m_lanes)
        {
            lane->advance(scaled, world, pool);
        }
    }

    SimulationLane* Simulation::findLane(std::string_view name)
    {
        for (const std::unique_ptr<SimulationLane>& lane : m_lanes)
        {
            if (lane->name() == name)
            {
                return lane.get();
            }
        }
        return nullptr;
    }

    void Simulation::setTimeScale(f32 scale)
    {
        m_timeScale = std::clamp(scale, 0.0f, 16.0f);
        SW_LOG_INFO(kLogCat, "Time scale set to x{:.2f}", m_timeScale);
    }
} // namespace sw::sim
