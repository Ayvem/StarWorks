#pragma once

// ============================================================================
// Renderer/Renderer.hpp
// Renderer front-end: owns the Vulkan objects and the frame loop's GPU side.
//
// Frame model:
//  - kFramesInFlight (2) frames are recorded/submitted in a ring so the CPU
//    prepares frame N+1 while the GPU renders frame N.
//  - Per frame in flight: command pool + primary command buffer, an
//    image-acquire semaphore, an in-flight fence, a persistently mapped
//    camera uniform buffer and its descriptor set.
//  - Per swapchain image: a render-finished semaphore (indexed by image, as
//    required for correct present synchronization).
//
// Depth: single depth attachment, reverse-Z (clear 0.0, GREATER tests) for
// f32 precision at planetary scales.
//
// Draw submission is data-driven: the game hands a span of RenderObject
// (mesh + transform) each frame. When the ECS lands, a render system will
// produce this list instead — this API will not change shape, it will just
// gain culling/instancing layers underneath.
// ============================================================================

#include "Core/Types.hpp"
#include "Math/Math.hpp"
#include "Renderer/Mesh.hpp"
#include "Renderer/Vulkan/VulkanMemory.hpp"

#include <vulkan/vulkan.h>

#include <array>
#include <memory>
#include <span>
#include <string>
#include <vector>

namespace sw
{
    class Window;
    class Camera;
} // namespace sw

namespace sw::vulkan
{
    class VulkanInstance;
    class VulkanDevice;
    class VulkanSwapchain;
    class VulkanPipeline;
} // namespace sw::vulkan

namespace sw
{
    struct RendererConfig
    {
        std::string applicationName = "StarWorks";
        bool enableValidation =
#if defined(SW_DEBUG)
            true;
#else
            false;
#endif
        /// Prefer a CPU/software Vulkan implementation (llvmpipe, SwiftShader)
        /// over hardware GPUs during device selection. Rendering code is
        /// identical either way — this only inverts the selection scoring.
        bool preferCpuDevice = false;
    };

    class Renderer
    {
    public:
        static constexpr u32 kFramesInFlight = 2;

        Renderer(Window& window, const RendererConfig& config);
        ~Renderer();

        Renderer(const Renderer&) = delete;
        Renderer& operator=(const Renderer&) = delete;
        Renderer(Renderer&&) = delete;
        Renderer& operator=(Renderer&&) = delete;

        /// Uploads a CPU mesh to the GPU. Valid for the renderer's lifetime.
        [[nodiscard]] Mesh createMesh(const MeshData& data);

        /// Records and submits one frame drawing the given objects. Handles
        /// swapchain recreation (resize, out-of-date) internally; never
        /// throws on those recoverable paths.
        void renderFrame(const Camera& camera, std::span<const RenderObject> objects);

        /// Called by the Application when the framebuffer size changes.
        void onFramebufferResized(u32 width, u32 height);

        /// Direction TOWARD the scene from the sun (world space, normalized).
        void setSunDirection(const Vec3& direction);

        /// Blocks until the GPU has finished all submitted work.
        void waitIdle() const;

        [[nodiscard]] f32 aspectRatio() const;

    private:
        /// Layout must match the Camera uniform block in Shaders/Mesh.vert.
        struct CameraUniforms
        {
            Mat4 viewProjection{1.0f};
            Vec4 cameraPosition{0.0f};
            Vec4 sunDirection{0.0f, -1.0f, 0.0f, 0.0f};
        };

        struct FrameResources
        {
            VkCommandPool commandPool = VK_NULL_HANDLE;
            VkCommandBuffer commandBuffer = VK_NULL_HANDLE;
            VkSemaphore imageAvailable = VK_NULL_HANDLE;
            VkFence inFlight = VK_NULL_HANDLE;
            vulkan::VulkanBuffer cameraUbo;      // persistently mapped
            VkDescriptorSet descriptorSet = VK_NULL_HANDLE;
        };

        void createDepthResources();
        void createDescriptorResources();
        void destroyDescriptorResources();
        void createFrameResources();
        void destroyFrameResources();
        void createSwapchainSemaphores();
        void destroySwapchainSemaphores();
        void recreateSwapchain();
        void recordCommands(VkCommandBuffer cmd, u32 imageIndex,
                            std::span<const RenderObject> objects) const;
        [[nodiscard]] VkFormat findDepthFormat() const;

        Window& m_window;

        std::unique_ptr<vulkan::VulkanInstance> m_instance;
        VkSurfaceKHR m_surface = VK_NULL_HANDLE;
        std::unique_ptr<vulkan::VulkanDevice> m_device;
        // m_memory must outlive every buffer/image below (declaration order
        // drives destruction order — do not reorder).
        std::unique_ptr<vulkan::VulkanMemory> m_memory;
        std::unique_ptr<vulkan::VulkanSwapchain> m_swapchain;
        vulkan::VulkanImage m_depthImage;
        std::unique_ptr<vulkan::VulkanPipeline> m_meshPipeline;

        VkDescriptorSetLayout m_descriptorSetLayout = VK_NULL_HANDLE;
        VkDescriptorPool m_descriptorPool = VK_NULL_HANDLE;

        std::array<FrameResources, kFramesInFlight> m_frames{};
        /// One per swapchain image, signaled when rendering to it completes.
        std::vector<VkSemaphore> m_renderFinished;

        Vec3 m_sunDirection{-0.45f, -0.8f, -0.4f};
        u32 m_currentFrame = 0;
        bool m_framebufferResized = false;
        u32 m_pendingWidth = 0;
        u32 m_pendingHeight = 0;
    };
} // namespace sw
