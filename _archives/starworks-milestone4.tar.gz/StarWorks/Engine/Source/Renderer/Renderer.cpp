#include "Renderer/Renderer.hpp"

#include "Core/FileSystem.hpp"
#include "Core/Log.hpp"
#include "Platform/Window.hpp"
#include "Renderer/Vertex.hpp"
#include "Renderer/Vulkan/VulkanCommon.hpp"
#include "Renderer/Vulkan/VulkanDevice.hpp"
#include "Renderer/Vulkan/VulkanInstance.hpp"
#include "Renderer/Vulkan/VulkanPipeline.hpp"
#include "Renderer/Vulkan/VulkanSwapchain.hpp"
#include "Scene/Camera.hpp"

#include <array>
#include <cstring>

namespace sw
{
    namespace
    {
        constexpr const char* kLogCat = "Renderer";

        /// Push-constant block layout shared with Shaders/Mesh.vert.
        struct MeshPushConstants
        {
            Mat4 model;
        };
        static_assert(sizeof(MeshPushConstants) == 64,
                      "Push constant layout must match Mesh.vert");
    } // namespace

    Renderer::Renderer(Window& window, const RendererConfig& config)
        : m_window(window)
    {
        // ---- instance + surface + device -------------------------------------
        vulkan::VulkanInstance::Config instanceConfig{};
        instanceConfig.applicationName = config.applicationName;
        instanceConfig.requiredExtensions = Window::requiredVulkanInstanceExtensions();
        instanceConfig.enableValidation = config.enableValidation;
        m_instance = std::make_unique<vulkan::VulkanInstance>(instanceConfig);

        m_surface = m_window.createVulkanSurface(m_instance->handle());
        vulkan::VulkanDevice::Options deviceOptions{};
        deviceOptions.preferCpuDevice = config.preferCpuDevice;
        m_device = std::make_unique<vulkan::VulkanDevice>(m_instance->handle(), m_surface,
                                                          deviceOptions);

        // ---- memory + swapchain + depth ---------------------------------------
        m_memory = std::make_unique<vulkan::VulkanMemory>(m_instance->handle(), *m_device);

        u32 width = 0;
        u32 height = 0;
        m_window.framebufferSize(width, height);
        m_swapchain =
            std::make_unique<vulkan::VulkanSwapchain>(*m_device, m_surface, width, height);
        createDepthResources();

        // ---- descriptors (camera UBO per frame in flight) ----------------------
        createDescriptorResources();
        createFrameResources();
        createSwapchainSemaphores();

        // ---- mesh pipeline ------------------------------------------------------
        vulkan::VulkanPipeline::Config pipelineConfig{};
        pipelineConfig.vertexSpirv =
            FileSystem::readBinaryFile(FileSystem::resolve("Shaders/Mesh.vert.spv"));
        pipelineConfig.fragmentSpirv =
            FileSystem::readBinaryFile(FileSystem::resolve("Shaders/Mesh.frag.spv"));
        pipelineConfig.colorAttachmentFormat = m_swapchain->imageFormat();
        pipelineConfig.depthAttachmentFormat = m_depthImage.format();
        pipelineConfig.depthTest = true;
        pipelineConfig.depthWrite = true;
        pipelineConfig.vertexBindings = {vulkan::VertexInput::binding()};
        const auto attrs = vulkan::VertexInput::attributes();
        pipelineConfig.vertexAttributes.assign(attrs.begin(), attrs.end());
        pipelineConfig.descriptorSetLayouts = {m_descriptorSetLayout};
        pipelineConfig.pushConstantSize = sizeof(MeshPushConstants);
        m_meshPipeline =
            std::make_unique<vulkan::VulkanPipeline>(m_device->handle(), pipelineConfig);

        SW_LOG_INFO(kLogCat, "Renderer initialized ({} frames in flight, reverse-Z depth)",
                    kFramesInFlight);
    }

    Renderer::~Renderer()
    {
        // Destruction order matters; wait for the GPU before touching anything.
        if (m_device)
        {
            m_device->waitIdle();
        }

        destroySwapchainSemaphores();
        destroyFrameResources();
        destroyDescriptorResources();
        m_meshPipeline.reset();
        m_depthImage.reset();
        m_swapchain.reset();
        m_memory.reset();
        m_device.reset();

        if (m_surface != VK_NULL_HANDLE && m_instance)
        {
            vkDestroySurfaceKHR(m_instance->handle(), m_surface, nullptr);
            m_surface = VK_NULL_HANDLE;
        }
        m_instance.reset();
    }

    Mesh Renderer::createMesh(const MeshData& data)
    {
        return Mesh(*m_memory, data);
    }

    void Renderer::onFramebufferResized(u32 width, u32 height)
    {
        m_framebufferResized = true;
        m_pendingWidth = width;
        m_pendingHeight = height;
    }

    void Renderer::setSunDirection(const Vec3& direction)
    {
        m_sunDirection = glm::normalize(direction);
    }

    void Renderer::waitIdle() const
    {
        if (m_device)
        {
            m_device->waitIdle();
        }
    }

    f32 Renderer::aspectRatio() const
    {
        const VkExtent2D extent = m_swapchain->extent();
        if (extent.height == 0)
        {
            return 16.0f / 9.0f;
        }
        return static_cast<f32>(extent.width) / static_cast<f32>(extent.height);
    }

    void Renderer::renderFrame(const Camera& camera, std::span<const RenderObject> objects)
    {
        // Never render while minimized (zero-sized swapchains are invalid).
        if (m_window.isMinimized())
        {
            return;
        }

        FrameResources& frame = m_frames[m_currentFrame];
        const VkDevice device = m_device->handle();

        // ---- wait until this frame slot is free -------------------------------
        vkWaitForFences(device, 1, &frame.inFlight, VK_TRUE, UINT64_MAX);

        if (m_framebufferResized)
        {
            recreateSwapchain();
            m_framebufferResized = false;
        }

        // ---- acquire ------------------------------------------------------------
        u32 imageIndex = 0;
        const VkResult acquireResult =
            m_swapchain->acquireNextImage(frame.imageAvailable, imageIndex);
        if (acquireResult == VK_ERROR_OUT_OF_DATE_KHR)
        {
            recreateSwapchain();
            return; // retry next frame with fresh images
        }
        if (acquireResult != VK_SUCCESS && acquireResult != VK_SUBOPTIMAL_KHR)
        {
            SW_LOG_ERROR(kLogCat, "vkAcquireNextImageKHR failed: {}",
                         vulkan::toString(acquireResult));
            return;
        }

        // Only reset the fence once we know work will be submitted.
        vkResetFences(device, 1, &frame.inFlight);

        // ---- update this frame's camera UBO --------------------------------------
        CameraUniforms uniforms{};
        uniforms.viewProjection = camera.viewProjectionMatrix();
        uniforms.cameraPosition = Vec4(camera.position(), 1.0f);
        uniforms.sunDirection = Vec4(m_sunDirection, 0.0f);
        std::memcpy(frame.cameraUbo.mappedData(), &uniforms, sizeof(uniforms));

        // ---- record --------------------------------------------------------------
        vkResetCommandPool(device, frame.commandPool, 0);

        VkCommandBufferBeginInfo beginInfo{};
        beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
        beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        SW_VK_CHECK(vkBeginCommandBuffer(frame.commandBuffer, &beginInfo));
        recordCommands(frame.commandBuffer, imageIndex, objects);
        SW_VK_CHECK(vkEndCommandBuffer(frame.commandBuffer));

        // ---- submit (synchronization2) --------------------------------------------
        VkSemaphoreSubmitInfo waitInfo{};
        waitInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO;
        waitInfo.semaphore = frame.imageAvailable;
        waitInfo.stageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

        VkSemaphoreSubmitInfo signalInfo{};
        signalInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO;
        signalInfo.semaphore = m_renderFinished[imageIndex];
        signalInfo.stageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

        VkCommandBufferSubmitInfo cmdInfo{};
        cmdInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO;
        cmdInfo.commandBuffer = frame.commandBuffer;

        VkSubmitInfo2 submitInfo{};
        submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO_2;
        submitInfo.waitSemaphoreInfoCount = 1;
        submitInfo.pWaitSemaphoreInfos = &waitInfo;
        submitInfo.commandBufferInfoCount = 1;
        submitInfo.pCommandBufferInfos = &cmdInfo;
        submitInfo.signalSemaphoreInfoCount = 1;
        submitInfo.pSignalSemaphoreInfos = &signalInfo;

        SW_VK_CHECK(vkQueueSubmit2(m_device->graphicsQueue(), 1, &submitInfo, frame.inFlight));

        // ---- present ---------------------------------------------------------------
        const VkResult presentResult = m_swapchain->present(
            m_device->presentQueue(), m_renderFinished[imageIndex], imageIndex);
        if (presentResult == VK_ERROR_OUT_OF_DATE_KHR || presentResult == VK_SUBOPTIMAL_KHR)
        {
            recreateSwapchain();
        }
        else if (presentResult != VK_SUCCESS)
        {
            SW_LOG_ERROR(kLogCat, "vkQueuePresentKHR failed: {}",
                         vulkan::toString(presentResult));
        }

        m_currentFrame = (m_currentFrame + 1) % kFramesInFlight;
    }

    void Renderer::recordCommands(VkCommandBuffer cmd, u32 imageIndex,
                                  std::span<const RenderObject> objects) const
    {
        const VkExtent2D extent = m_swapchain->extent();
        const VkImage swapImage = m_swapchain->image(imageIndex);

        VkImageSubresourceRange colorRange{};
        colorRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        colorRange.levelCount = 1;
        colorRange.layerCount = 1;

        VkImageSubresourceRange depthRange = colorRange;
        depthRange.aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT;

        // ---- transitions: color UNDEFINED->COLOR_ATTACHMENT,
        //                   depth UNDEFINED->DEPTH_ATTACHMENT (content discarded)
        {
            std::array<VkImageMemoryBarrier2, 2> barriers{};

            barriers[0].sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
            barriers[0].srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barriers[0].srcAccessMask = VK_ACCESS_2_NONE;
            barriers[0].dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barriers[0].dstAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
            barriers[0].oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            barriers[0].newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            barriers[0].srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barriers[0].dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barriers[0].image = swapImage;
            barriers[0].subresourceRange = colorRange;

            barriers[1].sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
            barriers[1].srcStageMask = VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT;
            barriers[1].srcAccessMask = VK_ACCESS_2_NONE;
            barriers[1].dstStageMask = VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT |
                                       VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT;
            barriers[1].dstAccessMask = VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT |
                                        VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
            barriers[1].oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            barriers[1].newLayout = VK_IMAGE_LAYOUT_DEPTH_ATTACHMENT_OPTIMAL;
            barriers[1].srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barriers[1].dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barriers[1].image = m_depthImage.handle();
            barriers[1].subresourceRange = depthRange;

            VkDependencyInfo dependency{};
            dependency.sType = VK_STRUCTURE_TYPE_DEPENDENCY_INFO;
            dependency.imageMemoryBarrierCount = static_cast<u32>(barriers.size());
            dependency.pImageMemoryBarriers = barriers.data();
            vkCmdPipelineBarrier2(cmd, &dependency);
        }

        // ---- dynamic rendering pass -------------------------------------------
        VkClearValue clearColor{};
        // Deep-space blue-black; linear values (swapchain is sRGB).
        clearColor.color = {{0.004f, 0.006f, 0.015f, 1.0f}};

        VkRenderingAttachmentInfo colorAttachment{};
        colorAttachment.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO;
        colorAttachment.imageView = m_swapchain->imageView(imageIndex);
        colorAttachment.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        colorAttachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        colorAttachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        colorAttachment.clearValue = clearColor;

        VkRenderingAttachmentInfo depthAttachment{};
        depthAttachment.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO;
        depthAttachment.imageView = m_depthImage.view();
        depthAttachment.imageLayout = VK_IMAGE_LAYOUT_DEPTH_ATTACHMENT_OPTIMAL;
        depthAttachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        depthAttachment.storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        depthAttachment.clearValue.depthStencil = {0.0f, 0}; // reverse-Z: far = 0

        VkRenderingInfo renderingInfo{};
        renderingInfo.sType = VK_STRUCTURE_TYPE_RENDERING_INFO;
        renderingInfo.renderArea = {{0, 0}, extent};
        renderingInfo.layerCount = 1;
        renderingInfo.colorAttachmentCount = 1;
        renderingInfo.pColorAttachments = &colorAttachment;
        renderingInfo.pDepthAttachment = &depthAttachment;

        vkCmdBeginRendering(cmd, &renderingInfo);

        VkViewport viewport{};
        viewport.width = static_cast<f32>(extent.width);
        viewport.height = static_cast<f32>(extent.height);
        viewport.minDepth = 0.0f;
        viewport.maxDepth = 1.0f;
        vkCmdSetViewport(cmd, 0, 1, &viewport);

        VkRect2D scissor{{0, 0}, extent};
        vkCmdSetScissor(cmd, 0, 1, &scissor);

        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, m_meshPipeline->handle());

        const FrameResources& frame = m_frames[m_currentFrame];
        vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                m_meshPipeline->layout(), 0, 1, &frame.descriptorSet, 0,
                                nullptr);

        for (const RenderObject& object : objects)
        {
            if (object.mesh == nullptr || !object.mesh->valid())
            {
                continue;
            }

            MeshPushConstants push{};
            push.model = object.transform;
            vkCmdPushConstants(cmd, m_meshPipeline->layout(), VK_SHADER_STAGE_VERTEX_BIT, 0,
                               sizeof(push), &push);

            const VkBuffer vertexBuffer = object.mesh->vertexBuffer();
            const VkDeviceSize offset = 0;
            vkCmdBindVertexBuffers(cmd, 0, 1, &vertexBuffer, &offset);
            vkCmdBindIndexBuffer(cmd, object.mesh->indexBuffer(), 0, VK_INDEX_TYPE_UINT32);
            vkCmdDrawIndexed(cmd, object.mesh->indexCount(), 1, 0, 0, 0);
        }

        vkCmdEndRendering(cmd);

        // ---- transition: COLOR_ATTACHMENT_OPTIMAL -> PRESENT_SRC ---------------
        {
            VkImageMemoryBarrier2 barrier{};
            barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
            barrier.srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
            barrier.srcAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
            barrier.dstStageMask = VK_PIPELINE_STAGE_2_NONE;
            barrier.dstAccessMask = VK_ACCESS_2_NONE;
            barrier.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            barrier.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            barrier.image = swapImage;
            barrier.subresourceRange = colorRange;

            VkDependencyInfo dependency{};
            dependency.sType = VK_STRUCTURE_TYPE_DEPENDENCY_INFO;
            dependency.imageMemoryBarrierCount = 1;
            dependency.pImageMemoryBarriers = &barrier;
            vkCmdPipelineBarrier2(cmd, &dependency);
        }
    }

    void Renderer::recreateSwapchain()
    {
        u32 width = 0;
        u32 height = 0;
        m_window.framebufferSize(width, height);
        if (width == 0 || height == 0)
        {
            return; // minimized; the frame loop skips rendering anyway
        }

        m_device->waitIdle();
        const u32 previousImageCount = m_swapchain->imageCount();
        m_swapchain->recreate(width, height);
        createDepthResources(); // depth must match the new extent

        // Semaphores are indexed per swapchain image; rebuild if the count moved.
        if (m_swapchain->imageCount() != previousImageCount)
        {
            destroySwapchainSemaphores();
            createSwapchainSemaphores();
        }

        SW_LOG_DEBUG(kLogCat, "Swapchain recreated: {}x{}", width, height);
    }

    VkFormat Renderer::findDepthFormat() const
    {
        constexpr std::array<VkFormat, 3> candidates = {
            VK_FORMAT_D32_SFLOAT,
            VK_FORMAT_D32_SFLOAT_S8_UINT,
            VK_FORMAT_D24_UNORM_S8_UINT,
        };
        for (VkFormat format : candidates)
        {
            VkFormatProperties props{};
            vkGetPhysicalDeviceFormatProperties(m_device->physicalHandle(), format, &props);
            if (props.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT)
            {
                return format;
            }
        }
        SW_THROW("No supported depth attachment format found");
    }

    void Renderer::createDepthResources()
    {
        m_depthImage.reset();
        m_depthImage = m_memory->createAttachmentImage(
            m_swapchain->extent(), findDepthFormat(),
            VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, VK_IMAGE_ASPECT_DEPTH_BIT);
    }

    void Renderer::createDescriptorResources()
    {
        const VkDevice device = m_device->handle();

        // ---- layout: one uniform buffer visible to VS + FS --------------------
        VkDescriptorSetLayoutBinding uboBinding{};
        uboBinding.binding = 0;
        uboBinding.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        uboBinding.descriptorCount = 1;
        uboBinding.stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;

        VkDescriptorSetLayoutCreateInfo layoutInfo{};
        layoutInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
        layoutInfo.bindingCount = 1;
        layoutInfo.pBindings = &uboBinding;
        SW_VK_CHECK(
            vkCreateDescriptorSetLayout(device, &layoutInfo, nullptr, &m_descriptorSetLayout));

        // ---- pool sized for the per-frame sets ---------------------------------
        VkDescriptorPoolSize poolSize{};
        poolSize.type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        poolSize.descriptorCount = kFramesInFlight;

        VkDescriptorPoolCreateInfo poolInfo{};
        poolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
        poolInfo.maxSets = kFramesInFlight;
        poolInfo.poolSizeCount = 1;
        poolInfo.pPoolSizes = &poolSize;
        SW_VK_CHECK(vkCreateDescriptorPool(device, &poolInfo, nullptr, &m_descriptorPool));
    }

    void Renderer::destroyDescriptorResources()
    {
        const VkDevice device = m_device ? m_device->handle() : VK_NULL_HANDLE;
        if (device == VK_NULL_HANDLE)
        {
            return;
        }
        if (m_descriptorPool != VK_NULL_HANDLE)
        {
            vkDestroyDescriptorPool(device, m_descriptorPool, nullptr);
            m_descriptorPool = VK_NULL_HANDLE;
        }
        if (m_descriptorSetLayout != VK_NULL_HANDLE)
        {
            vkDestroyDescriptorSetLayout(device, m_descriptorSetLayout, nullptr);
            m_descriptorSetLayout = VK_NULL_HANDLE;
        }
    }

    void Renderer::createFrameResources()
    {
        const VkDevice device = m_device->handle();

        for (FrameResources& frame : m_frames)
        {
            VkCommandPoolCreateInfo poolInfo{};
            poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
            poolInfo.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
            poolInfo.queueFamilyIndex = m_device->graphicsFamilyIndex();
            SW_VK_CHECK(vkCreateCommandPool(device, &poolInfo, nullptr, &frame.commandPool));

            VkCommandBufferAllocateInfo allocInfo{};
            allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
            allocInfo.commandPool = frame.commandPool;
            allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
            allocInfo.commandBufferCount = 1;
            SW_VK_CHECK(vkAllocateCommandBuffers(device, &allocInfo, &frame.commandBuffer));

            VkSemaphoreCreateInfo semaphoreInfo{};
            semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
            SW_VK_CHECK(
                vkCreateSemaphore(device, &semaphoreInfo, nullptr, &frame.imageAvailable));

            VkFenceCreateInfo fenceInfo{};
            fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
            fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT; // first wait must pass
            SW_VK_CHECK(vkCreateFence(device, &fenceInfo, nullptr, &frame.inFlight));

            // ---- camera UBO + descriptor set --------------------------------
            frame.cameraUbo = m_memory->createHostVisibleBuffer(
                sizeof(CameraUniforms), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT);

            VkDescriptorSetAllocateInfo setAllocInfo{};
            setAllocInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
            setAllocInfo.descriptorPool = m_descriptorPool;
            setAllocInfo.descriptorSetCount = 1;
            setAllocInfo.pSetLayouts = &m_descriptorSetLayout;
            SW_VK_CHECK(vkAllocateDescriptorSets(device, &setAllocInfo, &frame.descriptorSet));

            VkDescriptorBufferInfo bufferInfo{};
            bufferInfo.buffer = frame.cameraUbo.handle();
            bufferInfo.offset = 0;
            bufferInfo.range = sizeof(CameraUniforms);

            VkWriteDescriptorSet write{};
            write.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
            write.dstSet = frame.descriptorSet;
            write.dstBinding = 0;
            write.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
            write.descriptorCount = 1;
            write.pBufferInfo = &bufferInfo;
            vkUpdateDescriptorSets(device, 1, &write, 0, nullptr);
        }
    }

    void Renderer::destroyFrameResources()
    {
        const VkDevice device = m_device ? m_device->handle() : VK_NULL_HANDLE;
        if (device == VK_NULL_HANDLE)
        {
            return;
        }
        for (FrameResources& frame : m_frames)
        {
            if (frame.inFlight != VK_NULL_HANDLE)
            {
                vkDestroyFence(device, frame.inFlight, nullptr);
            }
            if (frame.imageAvailable != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(device, frame.imageAvailable, nullptr);
            }
            if (frame.commandPool != VK_NULL_HANDLE)
            {
                vkDestroyCommandPool(device, frame.commandPool, nullptr);
            }
            frame.cameraUbo.reset();
            // Descriptor sets are freed together with the pool.
            frame = {};
        }
    }

    void Renderer::createSwapchainSemaphores()
    {
        const VkDevice device = m_device->handle();
        m_renderFinished.resize(m_swapchain->imageCount(), VK_NULL_HANDLE);
        for (VkSemaphore& semaphore : m_renderFinished)
        {
            VkSemaphoreCreateInfo semaphoreInfo{};
            semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
            SW_VK_CHECK(vkCreateSemaphore(device, &semaphoreInfo, nullptr, &semaphore));
        }
    }

    void Renderer::destroySwapchainSemaphores()
    {
        const VkDevice device = m_device ? m_device->handle() : VK_NULL_HANDLE;
        if (device == VK_NULL_HANDLE)
        {
            return;
        }
        for (VkSemaphore semaphore : m_renderFinished)
        {
            if (semaphore != VK_NULL_HANDLE)
            {
                vkDestroySemaphore(device, semaphore, nullptr);
            }
        }
        m_renderFinished.clear();
    }
} // namespace sw
