#include "Assets/PrimitiveFactory.hpp"

#include <cmath>

namespace sw
{
    MeshData PrimitiveFactory::makeCube(f32 size, const Vec4& color)
    {
        const f32 h = size * 0.5f;

        // 6 faces * 4 vertices, flat normals; CCW when viewed from outside.
        struct Face
        {
            Vec3 normal;
            Vec3 corners[4]; // CCW order
        };
        const Face faces[6] = {
            {{0, 0, 1},  {{-h, -h, h}, {h, -h, h}, {h, h, h}, {-h, h, h}}},     // +Z
            {{0, 0, -1}, {{h, -h, -h}, {-h, -h, -h}, {-h, h, -h}, {h, h, -h}}}, // -Z
            {{1, 0, 0},  {{h, -h, h}, {h, -h, -h}, {h, h, -h}, {h, h, h}}},     // +X
            {{-1, 0, 0}, {{-h, -h, -h}, {-h, -h, h}, {-h, h, h}, {-h, h, -h}}}, // -X
            {{0, 1, 0},  {{-h, h, h}, {h, h, h}, {h, h, -h}, {-h, h, -h}}},     // +Y
            {{0, -1, 0}, {{-h, -h, -h}, {h, -h, -h}, {h, -h, h}, {-h, -h, h}}}, // -Y
        };
        const Vec2 uvs[4] = {{0.0f, 1.0f}, {1.0f, 1.0f}, {1.0f, 0.0f}, {0.0f, 0.0f}};

        MeshData mesh;
        mesh.vertices.reserve(24);
        mesh.indices.reserve(36);
        for (const Face& face : faces)
        {
            const u32 base = static_cast<u32>(mesh.vertices.size());
            for (u32 i = 0; i < 4; ++i)
            {
                mesh.vertices.push_back({face.corners[i], face.normal, color, uvs[i]});
            }
            mesh.indices.insert(mesh.indices.end(),
                                {base, base + 1, base + 2, base, base + 2, base + 3});
        }
        return mesh;
    }

    MeshData PrimitiveFactory::makeUvSphere(f32 radius, u32 rings, u32 segments,
                                            const Vec4& color)
    {
        MeshData mesh;
        mesh.vertices.reserve(static_cast<usize>(rings + 1) * (segments + 1));

        for (u32 ring = 0; ring <= rings; ++ring)
        {
            const f32 v = static_cast<f32>(ring) / static_cast<f32>(rings);
            const f32 phi = v * math::kPi; // 0 (north pole) .. pi (south pole)
            const f32 sinPhi = std::sin(phi);
            const f32 cosPhi = std::cos(phi);

            for (u32 segment = 0; segment <= segments; ++segment)
            {
                const f32 u = static_cast<f32>(segment) / static_cast<f32>(segments);
                const f32 theta = u * math::kTwoPi;

                const Vec3 normal{sinPhi * std::cos(theta), cosPhi,
                                  sinPhi * std::sin(theta)};
                mesh.vertices.push_back({normal * radius, normal, color, {u, v}});
            }
        }

        for (u32 ring = 0; ring < rings; ++ring)
        {
            for (u32 segment = 0; segment < segments; ++segment)
            {
                const u32 a = ring * (segments + 1) + segment;
                const u32 b = a + segments + 1;
                // CCW seen from outside (theta grows toward -Z first, so the
                // winding below is outward with our +Y-up convention).
                mesh.indices.insert(mesh.indices.end(), {a, b, a + 1, a + 1, b, b + 1});
            }
        }
        return mesh;
    }

    MeshData PrimitiveFactory::makeGridPlane(f32 extent, u32 cells, const Vec4& color)
    {
        MeshData mesh;
        const u32 verts = cells + 1;
        mesh.vertices.reserve(static_cast<usize>(verts) * verts);

        for (u32 z = 0; z < verts; ++z)
        {
            for (u32 x = 0; x < verts; ++x)
            {
                const f32 fx = (static_cast<f32>(x) / cells - 0.5f) * 2.0f * extent;
                const f32 fz = (static_cast<f32>(z) / cells - 0.5f) * 2.0f * extent;
                mesh.vertices.push_back({{fx, 0.0f, fz},
                                         {0.0f, 1.0f, 0.0f},
                                         color,
                                         {static_cast<f32>(x), static_cast<f32>(z)}});
            }
        }
        for (u32 z = 0; z < cells; ++z)
        {
            for (u32 x = 0; x < cells; ++x)
            {
                const u32 a = z * verts + x;
                const u32 b = a + verts;
                mesh.indices.insert(mesh.indices.end(), {a, b, a + 1, a + 1, b, b + 1});
            }
        }
        return mesh;
    }
} // namespace sw
