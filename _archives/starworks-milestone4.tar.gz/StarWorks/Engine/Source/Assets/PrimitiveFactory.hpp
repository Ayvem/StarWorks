#pragma once

// ============================================================================
// Assets/PrimitiveFactory.hpp
// Procedural generation of basic meshes. Used for engine testing, debug
// visualization, and as placeholder geometry until real assets exist.
// All primitives are indexed, counter-clockwise (engine convention), with
// correct normals.
// ============================================================================

#include "Assets/MeshData.hpp"

namespace sw
{
    class PrimitiveFactory
    {
    public:
        PrimitiveFactory() = delete;

        /// Axis-aligned cube centered at the origin (24 vertices, flat faces).
        [[nodiscard]] static MeshData makeCube(f32 size, const Vec4& color);

        /// UV sphere centered at the origin.
        [[nodiscard]] static MeshData makeUvSphere(f32 radius, u32 rings, u32 segments,
                                                   const Vec4& color);

        /// Flat grid on the XZ plane (for spatial orientation while flying).
        [[nodiscard]] static MeshData makeGridPlane(f32 extent, u32 cells, const Vec4& color);
    };
} // namespace sw
