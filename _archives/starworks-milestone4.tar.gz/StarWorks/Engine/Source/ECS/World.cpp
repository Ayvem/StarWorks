#include "ECS/World.hpp"

namespace sw::ecs
{
    World::World()
    {
        m_emptyArchetype = getOrCreateArchetype(Signature{0});
    }

    Entity World::createEntity()
    {
        u32 index = 0;
        if (!m_freeIndices.empty())
        {
            index = m_freeIndices.back();
            m_freeIndices.pop_back();
        }
        else
        {
            index = static_cast<u32>(m_records.size());
            m_records.emplace_back();
        }

        EntityRecord& record = m_records[index];
        record.alive = true;
        record.archetype = m_emptyArchetype;

        const Entity entity{index, record.generation};
        record.row = m_emptyArchetype->addRow(entity);
        ++m_aliveCount;
        return entity;
    }

    void World::destroyEntity(Entity entity)
    {
        SW_ASSERT(isAlive(entity), "destroyEntity on dead/stale entity ({})", entity.index);
        EntityRecord& record = m_records[entity.index];

        const Entity moved = record.archetype->removeRow(record.row);
        if (!moved.isNull())
        {
            m_records[moved.index].row = record.row;
        }

        record.alive = false;
        record.archetype = nullptr;
        ++record.generation; // stale handles become detectable
        m_freeIndices.push_back(entity.index);
        --m_aliveCount;
    }

    bool World::isAlive(Entity entity) const
    {
        return entity.index < m_records.size() && m_records[entity.index].alive &&
               m_records[entity.index].generation == entity.generation;
    }

    Archetype* World::getOrCreateArchetype(Signature signature)
    {
        if (const auto it = m_archetypes.find(signature); it != m_archetypes.end())
        {
            return it->second.get();
        }

        // Collect the ComponentInfo of every bit set in the signature.
        std::vector<ComponentInfo> infos;
        for (u32 id = 0; id < kMaxComponentTypes; ++id)
        {
            if ((signature & (Signature{1} << id)) != 0)
            {
                infos.push_back(componentInfo(id));
            }
        }

        auto archetype = std::make_unique<Archetype>(signature, infos);
        Archetype* pointer = archetype.get();
        m_archetypes.emplace(signature, std::move(archetype));
        m_archetypeList.push_back(pointer);
        return pointer;
    }

    void World::moveEntityToArchetype(Entity entity, EntityRecord& record, Archetype& target)
    {
        Archetype* source = record.archetype;
        const u32 sourceRow = record.row;

        const u32 targetRow = target.addRow(entity);
        target.copyCommonComponents(*source, sourceRow, targetRow);

        const Entity moved = source->removeRow(sourceRow);
        if (!moved.isNull())
        {
            m_records[moved.index].row = sourceRow;
        }

        record.archetype = &target;
        record.row = targetRow;
    }
} // namespace sw::ecs
