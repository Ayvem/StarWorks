#pragma once

// ============================================================================
// Scene/Camera.hpp
// Perspective camera.
//
// The camera is pure data + math: it does not read input and does not know
// about windows. Controllers (e.g. FreeCameraController) drive it; the
// renderer only consumes its matrices. The projection matrix is built for
// Vulkan conventions: depth [0, 1] and Y flipped relative to OpenGL.
// ============================================================================

#include "Math/Math.hpp"

namespace sw
{
    class Camera
    {
    public:
        Camera();

        void setPerspective(f32 verticalFovRadians, f32 nearPlane, f32 farPlane);
        void setAspectRatio(f32 aspect);

        void setPosition(const Vec3& position);
        void setOrientation(const Quat& orientation);

        [[nodiscard]] const Vec3& position() const { return m_position; }
        [[nodiscard]] const Quat& orientation() const { return m_orientation; }
        [[nodiscard]] f32 verticalFov() const { return m_verticalFov; }
        [[nodiscard]] f32 nearPlane() const { return m_nearPlane; }
        [[nodiscard]] f32 farPlane() const { return m_farPlane; }

        // Basis vectors in world space.
        [[nodiscard]] Vec3 forward() const;
        [[nodiscard]] Vec3 right() const;
        [[nodiscard]] Vec3 up() const;

        [[nodiscard]] Mat4 viewMatrix() const;
        [[nodiscard]] const Mat4& projectionMatrix() const;
        [[nodiscard]] Mat4 viewProjectionMatrix() const;

    private:
        void rebuildProjection();

        Vec3 m_position{0.0f, 0.0f, 0.0f};
        Quat m_orientation{1.0f, 0.0f, 0.0f, 0.0f}; // identity (w, x, y, z)

        f32 m_verticalFov = math::toRadians(60.0f);
        f32 m_aspectRatio = 16.0f / 9.0f;
        f32 m_nearPlane = 0.1f;
        f32 m_farPlane = 10000.0f;

        Mat4 m_projection{1.0f};
    };
} // namespace sw
