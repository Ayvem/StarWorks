#pragma once

// ============================================================================
// StarWorksGame.hpp
// The game layer. Milestone 8.5: flight information & accessibility.
//
//  - HUD (procedural bitmap font through the renderer's screen-space path):
//    control mode, speed (V toggles ORBital vs SuRFace-relative), altitude,
//    throttle, warp factor.
//  - Star map (M) now draws sampled Kepler trajectories as dotted ellipses
//    for every marked object, plus the beacons. Real scale everywhere.
//  - Terra has an exponential atmosphere (drag) and a SOLID surface with
//    friction: a gentle descent is a landing, a hard one is a crash.
//  - EVA (G): control switches to a capsule spawned beside the ship —
//    walk on the ground, fall ballistically in the air.
//  - Shift/Ctrl ramp the ship's main-engine throttle limiter.
// ============================================================================

#include "Components.hpp"

#include <Engine.hpp>

#include <array>
#include <string_view>
#include <vector>

namespace game
{
    class StarWorksGame final : public sw::Application
    {
    public:
        explicit StarWorksGame(const sw::ApplicationConfig& config);

    protected:
        void onUpdate(sw::f32 deltaSeconds) override;
        void onRender() override;

    private:
        [[nodiscard]] sw::u32 registerMesh(sw::Mesh mesh);
        [[nodiscard]] CelestialLodComponent makeSphereLodSet(const sw::Vec4& color);
        void buildScene();
        void buildGlyphMeshes();
        void updateWarp();
        void updateShipControls();
        void toggleEva();
        void updateChaseCamera();
        void collectDrawItems(const sw::Camera& activeCamera, bool mapView);
        void collectMapTrajectories(const sw::Camera& activeCamera);
        void collectHud();
        void hudText(std::string_view text, sw::f32 x, sw::f32 y, sw::f32 heightNdc,
                     const sw::Vec4& color);
        [[nodiscard]] sw::u32 selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const;
        [[nodiscard]] sw::ecs::Entity controlledEntity() const;
        [[nodiscard]] sw::WorldVec3 controlledVelocity() const;

        void buildSaveSchema();
        void saveGame();
        void loadGame();

        sw::Camera m_camera;
        sw::FreeCameraController m_cameraController;

        // Star map view (M): top-down system camera + zoom height.
        sw::Camera m_mapCamera;
        /// Default zoom frames the LEO traffic; wheel out to see Luna.
        sw::f64 m_mapHeightMeters = 6.0e7;
        bool m_mapView = false;

        // Control target: ship, or EVA capsule (G). Tab = pilot/free camera.
        sw::ecs::Entity m_shipEntity{};
        sw::ecs::Entity m_capsuleEntity{}; // null until first EVA
        bool m_shipMode = true;
        bool m_evaMode = false;

        // HUD state.
        bool m_speedSurfaceRelative = false; // V toggles ORB / SRF
        std::array<sw::u32, 128> m_glyphMeshIndex{};
        sw::u32 m_capsuleMeshIndex = 0;
        sw::u32 m_markerMeshIndex = 0;

        // Time warp (','/'.').
        sw::u32 m_warpIndex = 0;

        std::vector<sw::Mesh> m_meshes;
        sw::ecs::World m_world;
        sw::sim::Simulation m_simulation;
        sw::sim::SimulationLane* m_physicsLane = nullptr; // cached, owned by m_simulation
        sw::ecs::EntityCommandBuffer m_commands;
        sw::phys::SimulationBubbleSystem* m_bubbleSystem = nullptr;

        std::vector<sw::DrawItem> m_drawItems;
        sw::f64 m_lastStatsLogSeconds = 0.0;

        // Save/load (F5/F9): component schema with stable names.
        sw::save::Schema m_saveSchema;
    };
} // namespace game
