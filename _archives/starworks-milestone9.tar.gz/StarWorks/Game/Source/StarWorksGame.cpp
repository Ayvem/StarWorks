#include "StarWorksGame.hpp"

#include "Systems.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <format>

namespace game
{
    namespace
    {
        // ---- real-world dimensions and gravity (meters, m^3/s^2) --------------
        constexpr sw::f64 kTerraRadius = 6.371e6;    // Earth
        constexpr sw::f64 kMuTerra = 3.986004418e14; // Earth GM
        constexpr sw::f64 kLunaRadius = 1.7374e6;    // Moon
        constexpr sw::f64 kMuLuna = 4.9048695e12;    // Moon GM
        constexpr sw::f64 kLunaDistance = 3.844e8;   // Earth-Moon distance
        constexpr sw::f64 kStationAltitude = 4.0e5;  // 400 km (LEO)
        constexpr sw::f64 kStationOrbitRadius = kTerraRadius + kStationAltitude;
        constexpr sw::f64 kStationPhase = 4.71238898038468986; // 3*pi/2
        /// Terra sidereal angular velocity (rad/s) around +Y — used for the
        /// SuRFace-relative speed readout.
        constexpr sw::WorldVec3 kTerraAngularVelocity{0.0, 7.2921e-5, 0.0};

        constexpr sw::u32 kStationModuleCount = 8;

        constexpr sw::f64 kBubbleEnterRadius = 1.0e4; // 10 km
        constexpr sw::f64 kBubbleExitRadius = 1.5e4;  // 15 km (hysteresis)

        // Star map: constant on-screen marker size and zoom limits.
        constexpr sw::f32 kMarkerScreenFraction = 0.016f;
        constexpr sw::f64 kMapMinHeight = 2.0e7;
        constexpr sw::f64 kMapMaxHeight = 1.6e9;
        constexpr sw::u32 kTrajectorySamples = 72;

        // ---- time warp -----------------------------------------------------------
        constexpr sw::f32 kWarpLadder[] = {1.0f,    2.0f,     5.0f,     10.0f,   50.0f,
                                           100.0f, 1000.0f, 10000.0f, 100000.0f};
        constexpr sw::u32 kWarpSteps = static_cast<sw::u32>(std::size(kWarpLadder));

        [[nodiscard]] sw::f32 maxWarpForAltitude(sw::f64 altitudeMeters)
        {
            if (altitudeMeters < 1.2e5) { return 1.0f; }
            if (altitudeMeters < 3.0e5) { return 10.0f; }
            if (altitudeMeters < 1.0e6) { return 100.0f; }
            if (altitudeMeters < 5.0e6) { return 1000.0f; }
            if (altitudeMeters < 2.0e7) { return 10000.0f; }
            return 100000.0f;
        }

        /// Sphere LOD resolutions, most to least detailed (rings, segments).
        constexpr sw::u32 kLodRings[CelestialLodComponent::kLodLevels] = {64, 32, 16, 8, 6};
        constexpr sw::u32 kLodSegments[CelestialLodComponent::kLodLevels] = {96, 48, 24, 12, 9};
        constexpr sw::f32 kLodScreenFractions[CelestialLodComponent::kLodLevels - 1] = {
            0.5f, 0.15f, 0.04f, 0.008f};

        constexpr sw::f32 kCubeBoundsRadius = 0.8660254f;
        constexpr sw::Vec3 kSunDirection{-0.45f, -0.35f, -0.82f};
        constexpr const char* kGlyphCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,-+/%:";

        [[nodiscard]] sw::MeshData buildShipMesh()
        {
            using PF = sw::PrimitiveFactory;
            sw::MeshData ship = PF::makeBox({3.0f, 1.6f, 8.0f}, {0.72f, 0.74f, 0.78f, 1.0f});
            PF::append(ship, PF::makeBox({1.6f, 1.0f, 2.2f}, {0.25f, 0.55f, 0.75f, 1.0f}),
                       {0.0f, 2.2f, -4.5f});
            PF::append(ship, PF::makeBox({2.2f, 1.2f, 1.6f}, {0.30f, 0.30f, 0.33f, 1.0f}),
                       {0.0f, 0.0f, 9.0f});
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {4.0f, 0.0f, 2.0f});
            PF::append(ship, PF::makeBox({0.9f, 0.9f, 4.0f}, {0.55f, 0.57f, 0.62f, 1.0f}),
                       {-4.0f, 0.0f, 2.0f});
            return ship;
        }

        [[nodiscard]] sw::MeshData buildMarkerMesh()
        {
            sw::MeshData marker =
                sw::PrimitiveFactory::makeOctahedron(1.0f, {1.0f, 1.0f, 1.0f, 1.0f});
            const sw::Vec3 towardSun = -glm::normalize(kSunDirection);
            for (sw::Vertex& vertex : marker.vertices)
            {
                vertex.normal = towardSun;
            }
            return marker;
        }

        sw::f32 hash01(sw::u32 x)
        {
            x ^= 2747636419u;
            x *= 2654435769u;
            x ^= x >> 16;
            x *= 2654435769u;
            x ^= x >> 16;
            return static_cast<sw::f32>(x & 0xFFFFFF) / 16777216.0f;
        }
    } // namespace

    StarWorksGame::StarWorksGame(const sw::ApplicationConfig& config)
        : sw::Application(config)
        , m_cameraController(m_camera)
    {
        m_camera.setPerspective(sw::math::toRadians(60.0f), 0.5f, 1.0e9f);
        m_mapCamera.setPerspective(sw::math::toRadians(60.0f), 1.0e5f, 4.0e9f);
        m_glyphMeshIndex.fill(0xFFFFFFFFu);

        buildScene();
        buildGlyphMeshes();
        buildSaveSchema();

        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};
        m_cameraController.setPose(stationCenter + sw::WorldVec3{0.0, 250.0, 2000.0}, 0.0f,
                                   -0.08f);

        // ---- simulation lanes ---------------------------------------------------
        m_physicsLane = m_simulation.findLane("Physics");
        auto& physics = m_physicsLane->scheduler();
        physics.addSystem(std::make_unique<SnapshotSystem>());
        physics.addSystem(std::make_unique<sw::phys::GravityIntegrationSystem>());
        physics.addSystem(std::make_unique<ThrustSystem>());
        sw::phys::SurfaceInteractionSystem::Config surfaceConfig{};
        physics.addSystem(
            std::make_unique<sw::phys::SurfaceInteractionSystem>(surfaceConfig));
        physics.addSystem(std::make_unique<CapsuleMovementSystem>());
        physics.addSystem(std::make_unique<SpinSystem>());
        physics.addSystem(std::make_unique<CelestialSpinSystem>());
        // After the celestial spin: surface bases co-rotate with their body.
        physics.addSystem(std::make_unique<sw::phys::SurfaceAnchorSystem>());

        auto& automation = m_simulation.findLane("Automation")->scheduler();
        automation.addSystem(std::make_unique<sw::factory::MinerSystem>());
        automation.addSystem(std::make_unique<sw::factory::RefinerySystem>());

        auto& logistics = m_simulation.findLane("Logistics")->scheduler();
        logistics.addSystem(std::make_unique<sw::phys::RailsSystem>(m_simulation));
        logistics.addSystem(std::make_unique<sw::factory::TransferSystem>());
        sw::phys::SimulationBubbleSystem::Config bubbleConfig{};
        bubbleConfig.enterRadius = kBubbleEnterRadius;
        bubbleConfig.exitRadius = kBubbleExitRadius;
        auto bubble = std::make_unique<sw::phys::SimulationBubbleSystem>(
            m_commands, m_simulation, bubbleConfig);
        m_bubbleSystem = bubble.get();
        logistics.addSystem(std::move(bubble));

        m_simulation.findLane("World")->scheduler().addSystem(
            std::make_unique<StatsSystem>());

        SW_LOG_INFO("Game", "Milestone 8.5 scene ready: {} entities", m_world.aliveCount());
        SW_LOG_INFO("Game",
                    "Controls: Tab pilot/free | G EVA capsule | M map (wheel zoom) | V "
                    "speed ORB/SRF | Shift/Ctrl throttle | ,/. warp | W/S A/D arrows Q/E "
                    "X | Space pause | Esc quit");
    }

    sw::u32 StarWorksGame::registerMesh(sw::Mesh mesh)
    {
        m_meshes.push_back(std::move(mesh));
        return static_cast<sw::u32>(m_meshes.size() - 1);
    }

    CelestialLodComponent StarWorksGame::makeSphereLodSet(const sw::Vec4& color)
    {
        CelestialLodComponent lod{};
        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels; ++level)
        {
            lod.meshIndex[level] = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, kLodRings[level],
                                                   kLodSegments[level], color)));
        }
        return lod;
    }

    void StarWorksGame::buildGlyphMeshes()
    {
        for (const char* c = kGlyphCharset; *c != '\0'; ++c)
        {
            const sw::MeshData glyph = sw::ui::buildGlyphMesh(*c);
            if (!glyph.empty())
            {
                m_glyphMeshIndex[static_cast<sw::usize>(*c)] =
                    registerMesh(renderer().createMesh(glyph));
            }
        }
    }

    void StarWorksGame::buildScene()
    {
        // ---- meshes -------------------------------------------------------------
        const CelestialLodComponent terraLod =
            makeSphereLodSet({0.21f, 0.33f, 0.48f, 1.0f});
        const CelestialLodComponent lunaLod =
            makeSphereLodSet({0.42f, 0.41f, 0.43f, 1.0f});

        sw::u32 asteroidMeshId = 0;
        sw::f32 asteroidBoundsRadius = 2.5f;
        try
        {
            asteroidMeshId = registerMesh(renderer().createMesh(sw::GltfLoader::loadMesh(
                sw::FileSystem::resolve("Assets/Models/asteroid.glb"))));
        }
        catch (const sw::Exception& e)
        {
            SW_LOG_WARN("Game", "Asteroid asset unavailable ({}); using procedural sphere",
                        e.message());
            asteroidMeshId = registerMesh(renderer().createMesh(
                sw::PrimitiveFactory::makeUvSphere(1.0f, 24, 32, {0.45f, 0.41f, 0.38f, 1.0f})));
            asteroidBoundsRadius = 1.0f;
        }
        const sw::u32 moduleMeshId = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCube(1.0f, {0.75f, 0.78f, 0.82f, 1.0f})));
        const sw::u32 shipMeshId = registerMesh(renderer().createMesh(buildShipMesh()));
        m_capsuleMeshIndex = registerMesh(renderer().createMesh(
            sw::PrimitiveFactory::makeCapsule(0.5f, 0.5f, 12, 16,
                                              {0.9f, 0.6f, 0.2f, 1.0f})));
        m_markerMeshIndex = registerMesh(renderer().createMesh(buildMarkerMesh()));

        renderer().setSunDirection(kSunDirection);

        const sw::WorldVec3 stationCenter{0.0, 0.0, kStationOrbitRadius};

        auto snapshotOf = [](const TransformComponent& transform) {
            return PreviousTransformComponent{transform.position, transform.rotation};
        };

        // ---- Terra: gravity, SOLID SURFACE and ATMOSPHERE -----------------------
        sw::ecs::Entity terraEntity{};
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.uniformScale = static_cast<sw::f32>(kTerraRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, terraLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 7.2921e-5f});
            m_world.addComponent(e,
                                 sw::phys::GravitySourceComponent{kMuTerra, kTerraRadius});
            m_world.addComponent(e, sw::phys::AtmosphereComponent{1.225, 8500.0, 1.4e5});
            m_world.addComponent(e, MapMarkerComponent{{0.35f, 0.65f, 1.0f, 1.0f}});
            terraEntity = e;
        }

        // ---- GROUND OUTPOST: a mine built ON the planet surface -----------------
        // Anchored in Terra's rotating frame: it rides the planet's rotation
        // and survives save/load at its exact construction site — the model
        // every future surface factory will follow.
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.uniformScale = 40.0f; // 40 m mining rig
            m_world.addComponent(e, transform);
            m_world.addComponent(e, PreviousTransformComponent{});
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.35f, 0.3f, 1.0f}});
            m_world.addComponent(
                e, sw::phys::SurfaceAnchorComponent{
                       terraEntity, {0.0, 0.0, kTerraRadius + 18.0}}); // equator, +Z

            sw::factory::InventoryComponent pit{};
            pit.volumeCapacityM3 = 30.0;
            m_world.addComponent(e, pit);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 1.0, 0.0});
        }

        // ---- Luna: gravity + solid surface, no atmosphere ------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = {kLunaDistance, 0.0, 0.0};
            transform.uniformScale = static_cast<sw::f32>(kLunaRadius);
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{1.0f});
            m_world.addComponent(e, lunaLod);
            m_world.addComponent(e, SpinComponent{{0.0f, 1.0f, 0.0f}, 2.66e-6f});
            m_world.addComponent(e, sw::phys::GravitySourceComponent{kMuLuna, kLunaRadius});
            m_world.addComponent(e, MapMarkerComponent{{0.75f, 0.75f, 0.78f, 1.0f}});
        }

        // ---- asteroid: dynamic body + mining site ---------------------------------
        sw::ecs::Entity asteroidEntity{};
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{650.0, 120.0, -300.0};
            transform.uniformScale = 120.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{asteroidBoundsRadius});
            m_world.addComponent(e, MeshComponent{asteroidMeshId});
            m_world.addComponent(e, SpinComponent{{0.2f, 1.0f, 0.1f}, 0.05f});
            m_world.addComponent(e, MapMarkerComponent{{0.85f, 0.65f, 0.35f, 1.0f}});

            const sw::f64 radius = glm::length(transform.position);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(
                e, sw::phys::DynamicBodyComponent{{speed, 0.0, 0.0}, 5.0e8});

            sw::factory::InventoryComponent hopper{};
            hopper.volumeCapacityM3 = 40.0;
            m_world.addComponent(e, hopper);
            m_world.addComponent(e, sw::factory::MinerComponent{
                                        sw::res::Resource::IronOre, 2.0, 0.0});
            asteroidEntity = e;
        }

        // ---- the player ship ---------------------------------------------------------
        {
            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = stationCenter + sw::WorldVec3{-250.0, 60.0, 400.0};
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{13.0f});
            m_world.addComponent(e, MeshComponent{shipMeshId});
            m_world.addComponent(e, MapMarkerComponent{{0.3f, 1.0f, 0.5f, 1.0f}});
            m_world.addComponent(e, ShipComponent{});
            m_world.addComponent(e, ShipControlsComponent{});

            const sw::f64 radius = glm::length(transform.position);
            const sw::f64 speed = sw::phys::kepler::circularOrbitSpeed(kMuTerra, radius);
            m_world.addComponent(
                e, sw::phys::DynamicBodyComponent{{speed, 0.0, 0.0}, 5.0e4});
            m_shipEntity = e;
        }

        // ---- station modules (rails) + refinery / depot ---------------------------
        sw::ecs::Entity refineryEntity{};
        for (sw::u32 i = 0; i < kStationModuleCount; ++i)
        {
            const sw::f64 offset =
                (static_cast<sw::f64>(i) / kStationModuleCount - 0.5) * 1.0e-4;
            const sw::phys::KeplerOrbit orbit = sw::phys::kepler::fromElements(
                kMuTerra, {0.0, 0.0, 0.0},
                kStationOrbitRadius + (static_cast<sw::f64>(i) - 3.5) * 12.0, 0.0, 0.0,
                0.0, 0.0, kStationPhase + offset, 0.0);

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            sw::phys::kepler::evaluate(orbit, 0.0, transform.position);
            transform.uniformScale = 30.0f;
            m_world.addComponent(e, transform);
            m_world.addComponent(e, snapshotOf(transform));
            m_world.addComponent(e, BoundsComponent{kCubeBoundsRadius});
            m_world.addComponent(e, MeshComponent{moduleMeshId});
            m_world.addComponent(e, sw::phys::OnRailsComponent{orbit});
            m_world.addComponent(e, SpinComponent{{0.3f, 1.0f, 0.2f},
                                                  0.1f + hash01(i) * 0.1f});
            if (i == 0)
            {
                m_world.addComponent(e, MapMarkerComponent{{1.0f, 1.0f, 1.0f, 1.0f}});
                sw::factory::InventoryComponent tanks{};
                tanks.volumeCapacityM3 = 15.0;
                m_world.addComponent(e, tanks);
                m_world.addComponent(e, sw::factory::RefineryComponent{
                                            sw::res::Resource::IronOre,
                                            sw::res::Resource::Iron, 1.0, 0.9, 0.0});
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            asteroidEntity, sw::res::Resource::IronOre,
                                            1.5});
                refineryEntity = e;
            }
            else if (i == 1)
            {
                sw::factory::InventoryComponent silo{};
                silo.volumeCapacityM3 = 60.0;
                m_world.addComponent(e, silo);
                m_world.addComponent(e, sw::factory::ItemLinkComponent{
                                            refineryEntity, sw::res::Resource::Iron, 1.0});
            }
        }
    }

    void StarWorksGame::buildSaveSchema()
    {
        // Stable names + versions. Bump a version whenever the struct layout
        // changes; the loader refuses mismatches instead of guessing.
        m_saveSchema.registerComponent<sw::TransformComponent>("sw.Transform", 1);
        m_saveSchema.registerComponent<sw::PreviousTransformComponent>(
            "sw.PreviousTransform", 1);
        m_saveSchema.registerComponent<sw::phys::DynamicBodyComponent>("phys.DynamicBody",
                                                                       1);
        m_saveSchema.registerComponent<sw::phys::OnRailsComponent>("phys.OnRails", 1);
        m_saveSchema.registerComponent<sw::phys::GravitySourceComponent>(
            "phys.GravitySource", 1);
        m_saveSchema.registerComponent<sw::phys::AtmosphereComponent>("phys.Atmosphere", 1);
        m_saveSchema.registerComponent<sw::phys::SurfaceAnchorComponent>(
            "phys.SurfaceAnchor", 1);
        m_saveSchema.registerComponent<sw::factory::InventoryComponent>("factory.Inventory",
                                                                        1);
        m_saveSchema.registerComponent<sw::factory::MinerComponent>("factory.Miner", 1);
        m_saveSchema.registerComponent<sw::factory::RefineryComponent>("factory.Refinery",
                                                                       1);
        m_saveSchema.registerComponent<sw::factory::ItemLinkComponent>("factory.ItemLink",
                                                                       1);
        m_saveSchema.registerComponent<BoundsComponent>("game.Bounds", 1);
        m_saveSchema.registerComponent<SpinComponent>("game.Spin", 1);
        m_saveSchema.registerComponent<MeshComponent>("game.Mesh", 1);
        m_saveSchema.registerComponent<CelestialLodComponent>("game.CelestialLod", 1);
        m_saveSchema.registerComponent<ShipComponent>("game.Ship", 1);
        m_saveSchema.registerComponent<ShipControlsComponent>("game.ShipControls", 1);
        m_saveSchema.registerComponent<CapsuleComponent>("game.Capsule", 1);
        m_saveSchema.registerComponent<MapMarkerComponent>("game.MapMarker", 1);
    }

    void StarWorksGame::saveGame()
    {
        sw::ser::BinaryWriter writer;
        writer.write<sw::u32>(0x53575347); // "SWSG"
        writer.write<sw::u32>(1);          // game save version

        sw::save::saveWorld(m_world, m_saveSchema, writer);
        sw::save::saveSimulation(m_simulation, writer);

        // Player/session state.
        writer.write(m_shipEntity);
        writer.write(m_capsuleEntity);
        writer.write(static_cast<sw::u8>(m_evaMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_shipMode ? 1 : 0));
        writer.write(static_cast<sw::u8>(m_speedSurfaceRelative ? 1 : 0));
        writer.write(m_warpIndex);
        writer.write(m_mapHeightMeters);
        writer.write(m_camera.position());
        writer.write(m_camera.orientation());

        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        sw::FileSystem::writeBinaryFile(path, writer.bytes());
        SW_LOG_INFO("Game", "Saved to '{}' ({} KB, {} entities, t={:.1f}s)", path.string(),
                    writer.size() / 1024, m_world.aliveCount(),
                    m_simulation.simulatedSeconds());
    }

    void StarWorksGame::loadGame()
    {
        const auto path = sw::FileSystem::executableDirectory() / "starworks.sav";
        const std::vector<sw::u8> bytes = sw::FileSystem::readBinaryFile(path);
        sw::ser::BinaryReader reader(bytes);

        if (reader.read<sw::u32>() != 0x53575347)
        {
            SW_THROW("'{}' is not a StarWorks save", path.string());
        }
        if (const sw::u32 version = reader.read<sw::u32>(); version != 1)
        {
            SW_THROW("Unsupported save version {}", version);
        }

        sw::save::loadWorld(m_world, m_saveSchema, reader);
        sw::save::loadSimulation(m_simulation, reader);

        m_shipEntity = reader.read<sw::ecs::Entity>();
        m_capsuleEntity = reader.read<sw::ecs::Entity>();
        m_evaMode = reader.read<sw::u8>() != 0;
        m_shipMode = reader.read<sw::u8>() != 0;
        m_speedSurfaceRelative = reader.read<sw::u8>() != 0;
        m_warpIndex = reader.read<sw::u32>();
        m_mapHeightMeters = reader.read<sw::f64>();
        m_camera.setPosition(reader.read<sw::WorldVec3>());
        m_camera.setOrientation(reader.read<sw::Quat>());

        if (!m_shipMode)
        {
            const sw::Vec3 forward = m_camera.forward();
            m_cameraController.setPose(
                m_camera.position(), std::atan2(-forward.x, -forward.z),
                std::asin(std::clamp(forward.y, -1.0f, 1.0f)));
        }

        SW_LOG_INFO("Game", "Loaded '{}': {} entities, t={:.1f}s, warp x{:g}",
                    path.string(), m_world.aliveCount(), m_simulation.simulatedSeconds(),
                    kWarpLadder[m_warpIndex]);
    }

    sw::ecs::Entity StarWorksGame::controlledEntity() const
    {
        return (m_evaMode && !m_capsuleEntity.isNull()) ? m_capsuleEntity : m_shipEntity;
    }

    sw::WorldVec3 StarWorksGame::controlledVelocity() const
    {
        const sw::ecs::Entity entity = controlledEntity();
        auto& world = const_cast<sw::ecs::World&>(m_world);
        if (const auto* body =
                world.tryGetComponent<sw::phys::DynamicBodyComponent>(entity))
        {
            return body->velocity;
        }
        if (const auto* rails = world.tryGetComponent<sw::phys::OnRailsComponent>(entity))
        {
            sw::WorldVec3 position{};
            sw::WorldVec3 velocity{};
            sw::phys::kepler::evaluate(rails->orbit, m_simulation.simulatedSeconds(),
                                       position, &velocity);
            return velocity;
        }
        return {0.0, 0.0, 0.0};
    }

    void StarWorksGame::toggleEva()
    {
        if (!m_evaMode && m_capsuleEntity.isNull())
        {
            // First EVA: spawn the capsule beside the ship, co-moving.
            const auto& shipTransform =
                m_world.getComponent<TransformComponent>(m_shipEntity);
            const sw::WorldVec3 shipVelocity = controlledVelocity();

            const sw::ecs::Entity e = m_world.createEntity();
            TransformComponent transform{};
            transform.position = shipTransform.position +
                                 sw::WorldVec3(shipTransform.rotation *
                                               sw::Vec3{12.0f, 0.0f, 0.0f});
            m_world.addComponent(
                e, PreviousTransformComponent{transform.position, transform.rotation});
            m_world.addComponent(e, transform);
            m_world.addComponent(e, BoundsComponent{1.2f});
            m_world.addComponent(e, MeshComponent{m_capsuleMeshIndex});
            m_world.addComponent(e, MapMarkerComponent{{1.0f, 0.8f, 0.2f, 1.0f}});
            m_world.addComponent(e, CapsuleComponent{});
            m_world.addComponent(e, ShipControlsComponent{});
            sw::phys::DynamicBodyComponent body{};
            body.velocity = shipVelocity;
            body.mass = 120.0;
            body.ballisticFactor = 0.01; // draggier than the ship
            m_world.addComponent(e, body);
            m_capsuleEntity = e;
        }
        m_evaMode = !m_evaMode;
        SW_LOG_INFO("Game", "{}", m_evaMode ? "EVA: controlling capsule"
                                            : "Back aboard: controlling ship");
    }

    void StarWorksGame::updateWarp()
    {
        if (input().wasKeyPressed(sw::KeyCode::Period) && m_warpIndex + 1 < kWarpSteps)
        {
            ++m_warpIndex;
        }
        if (input().wasKeyPressed(sw::KeyCode::Comma) && m_warpIndex > 0)
        {
            --m_warpIndex;
        }

        const sw::WorldVec3 focusPosition =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;
        sw::f64 minAltitude = 1.0e18;
        m_world.forEach<TransformComponent, sw::phys::GravitySourceComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                sw::phys::GravitySourceComponent& source) {
                const sw::f64 altitude =
                    glm::length(focusPosition - transform.position) - source.bodyRadius;
                minAltitude = std::min(minAltitude, altitude);
            });

        const sw::f32 maxAllowed = maxWarpForAltitude(minAltitude);
        while (m_warpIndex > 0 && kWarpLadder[m_warpIndex] > maxAllowed)
        {
            --m_warpIndex;
            SW_LOG_INFO("Game", "Warp limited to x{:g} (altitude {:.0f} km)",
                        kWarpLadder[m_warpIndex], minAltitude / 1000.0);
        }

        m_simulation.setTimeScale(kWarpLadder[m_warpIndex]);
        m_bubbleSystem->setForceRails(m_warpIndex > 0);
    }

    void StarWorksGame::updateShipControls()
    {
        // Idle both control blocks, then feed the controlled one.
        auto& shipControls = m_world.getComponent<ShipControlsComponent>(m_shipEntity);
        shipControls = {};
        ShipControlsComponent* capsuleControls = nullptr;
        if (!m_capsuleEntity.isNull())
        {
            capsuleControls =
                m_world.tryGetComponent<ShipControlsComponent>(m_capsuleEntity);
            if (capsuleControls != nullptr)
            {
                *capsuleControls = {};
            }
        }

        if (!m_shipMode || m_mapView || m_warpIndex > 0)
        {
            return; // engines idle when not piloting (or while warping)
        }

        ShipControlsComponent& controls =
            (m_evaMode && capsuleControls != nullptr) ? *capsuleControls : shipControls;

        if (input().isKeyDown(sw::KeyCode::W)) { controls.thrustAxis += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::S)) { controls.thrustAxis -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Up)) { controls.rotationInput.x -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Down)) { controls.rotationInput.x += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::A)) { controls.rotationInput.y += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::D)) { controls.rotationInput.y -= 1.0f; }
        if (input().isKeyDown(sw::KeyCode::Q)) { controls.rotationInput.z += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::E)) { controls.rotationInput.z -= 1.0f; }
        controls.killRotation = input().isKeyDown(sw::KeyCode::X) ? 1u : 0u;
        // Throttle limiter (ship only; the capsule ignores it).
        if (input().isKeyDown(sw::KeyCode::LeftShift)) { controls.throttleDelta += 1.0f; }
        if (input().isKeyDown(sw::KeyCode::LeftControl))
        {
            controls.throttleDelta -= 1.0f;
        }
    }

    void StarWorksGame::updateChaseCamera()
    {
        const sw::ecs::Entity target = controlledEntity();
        const auto& transform = m_world.getComponent<TransformComponent>(target);
        const auto& previous = m_world.getComponent<PreviousTransformComponent>(target);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::WorldVec3 position =
            glm::mix(previous.position, transform.position, static_cast<sw::f64>(alpha));
        const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);

        const sw::Vec3 chaseOffset =
            m_evaMode ? sw::Vec3{0.0f, 2.0f, 9.0f} : sw::Vec3{0.0f, 12.0f, 42.0f};
        const sw::WorldVec3 cameraPosition =
            position + sw::WorldVec3(rotation * chaseOffset);
        m_camera.setPosition(cameraPosition);

        const sw::Vec3 forward = glm::normalize(sw::Vec3(position - cameraPosition));
        const sw::Vec3 targetUp = rotation * sw::Vec3{0.0f, 1.0f, 0.0f};
        const sw::Vec3 right = glm::normalize(glm::cross(forward, targetUp));
        const sw::Vec3 up = glm::cross(right, forward);
        m_camera.setOrientation(glm::quat_cast(sw::Mat3{right, up, -forward}));
    }

    void StarWorksGame::onUpdate(sw::f32 deltaSeconds)
    {
        if (input().wasKeyPressed(sw::KeyCode::Escape))
        {
            window().requestClose();
            return;
        }

        // --- mode toggles -------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::M))
        {
            m_mapView = !m_mapView;
            SW_LOG_INFO("Game", "Star map {}", m_mapView ? "opened" : "closed");
        }
        if (input().wasKeyPressed(sw::KeyCode::G) && !m_mapView)
        {
            toggleEva();
        }
        if (input().wasKeyPressed(sw::KeyCode::V))
        {
            m_speedSurfaceRelative = !m_speedSurfaceRelative;
        }
        if (input().wasKeyPressed(sw::KeyCode::Tab))
        {
            m_shipMode = !m_shipMode;
            if (!m_shipMode)
            {
                const sw::Vec3 forward = m_camera.forward();
                const sw::f32 yaw = std::atan2(-forward.x, -forward.z);
                const sw::f32 pitch = std::asin(std::clamp(forward.y, -1.0f, 1.0f));
                m_cameraController.setPose(m_camera.position(), yaw, pitch);
            }
            SW_LOG_INFO("Game", "{}", m_shipMode ? "Chase camera" : "Free camera");
        }
        if (input().wasKeyPressed(sw::KeyCode::Space))
        {
            m_simulation.setPaused(!m_simulation.isPaused());
            SW_LOG_INFO("Game", "Simulation {}", m_simulation.isPaused() ? "paused" : "resumed");
        }

        // --- save / load ----------------------------------------------------------
        if (input().wasKeyPressed(sw::KeyCode::F5))
        {
            try
            {
                saveGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Save failed: {}", e.message());
            }
        }
        if (input().wasKeyPressed(sw::KeyCode::F9))
        {
            try
            {
                loadGame();
            }
            catch (const sw::Exception& e)
            {
                SW_LOG_ERROR("Game", "Load failed: {}", e.message());
            }
        }

        updateWarp();

        // --- per-mode camera & controls ------------------------------------------
        if (m_mapView)
        {
            const sw::f32 scroll = input().scrollDeltaY();
            if (scroll != 0.0f)
            {
                m_mapHeightMeters = std::clamp(
                    m_mapHeightMeters * std::pow(1.3, static_cast<sw::f64>(-scroll)),
                    kMapMinHeight, kMapMaxHeight);
            }
            m_mapCamera.setPosition({0.0, m_mapHeightMeters, 0.0});
            m_mapCamera.setOrientation(
                glm::quat_cast(sw::Mat3{{1, 0, 0}, {0, 0, -1}, {0, 1, 0}}));
            m_mapCamera.setAspectRatio(renderer().aspectRatio());
        }
        else if (!m_shipMode)
        {
            m_cameraController.update(input(), window(), deltaSeconds);
        }
        m_camera.setAspectRatio(renderer().aspectRatio());

        updateShipControls();

        m_bubbleSystem->setFocus(
            m_world.getComponent<TransformComponent>(controlledEntity()).position);

        m_simulation.advance(m_world, deltaSeconds, &threadPool());
        m_commands.playback(m_world);

        if (m_shipMode && !m_mapView)
        {
            updateChaseCamera();
        }

        // --- periodic statistics ------------------------------------------------
        const sw::f64 now = clock().totalSeconds();
        if (now - m_lastStatsLogSeconds > 5.0)
        {
            m_lastStatsLogSeconds = now;
            const sw::RenderStats& stats = renderer().stats();
            SW_LOG_INFO("Game",
                        "render: {} submitted, {} culled, {} instances in {} draw calls | "
                        "sim: {} dynamic / {} rails, warp x{:g} ({:.0f} FPS, prepare "
                        "{:.1f} ms)",
                        stats.itemsSubmitted, stats.itemsCulled, stats.instancesDrawn,
                        stats.drawCalls, m_world.count<sw::phys::DynamicBodyComponent>(),
                        m_world.count<sw::phys::OnRailsComponent>(),
                        kWarpLadder[m_warpIndex], clock().smoothedFps(),
                        stats.cpuPrepareMs);
        }
    }

    sw::u32 StarWorksGame::selectLodLevel(sw::f64 distance, sw::f64 worldRadius) const
    {
        const sw::f64 clampedDistance = std::max(distance, worldRadius * 1.0001);
        const sw::f64 angularDiameter = 2.0 * std::atan(worldRadius / clampedDistance);
        const sw::f32 fraction =
            static_cast<sw::f32>(angularDiameter) / m_camera.verticalFov();

        for (sw::u32 level = 0; level < CelestialLodComponent::kLodLevels - 1; ++level)
        {
            if (fraction >= kLodScreenFractions[level])
            {
                return level;
            }
        }
        return CelestialLodComponent::kLodLevels - 1;
    }

    void StarWorksGame::hudText(std::string_view text, sw::f32 x, sw::f32 y,
                                sw::f32 heightNdc, const sw::Vec4& color)
    {
        const sw::f32 aspect = renderer().aspectRatio();
        const sw::f32 scaleX = (5.0f / 7.0f) * heightNdc / aspect;
        const sw::f32 advance = sw::ui::kGlyphAdvance * heightNdc / aspect;

        sw::f32 penX = x;
        for (const char character : text)
        {
            const auto index = static_cast<sw::usize>(
                static_cast<unsigned char>(std::toupper(character)));
            const sw::u32 meshIndex =
                (index < m_glyphMeshIndex.size()) ? m_glyphMeshIndex[index] : 0xFFFFFFFFu;
            if (meshIndex != 0xFFFFFFFFu)
            {
                sw::DrawItem item{};
                item.mesh = &m_meshes[meshIndex];
                item.transform = glm::translate(sw::Mat4{1.0f}, {penX, y, 0.0f}) *
                                 glm::scale(sw::Mat4{1.0f}, {scaleX, heightNdc, 1.0f});
                item.screenSpace = true;
                item.tint = color;
                m_drawItems.push_back(item);
            }
            penX += advance;
        }
    }

    void StarWorksGame::collectHud()
    {
        constexpr sw::f32 kLine = 0.052f;
        constexpr sw::f32 kX = -0.98f;
        sw::f32 y = -0.97f;
        const sw::Vec4 main{0.65f, 0.95f, 0.75f, 0.95f};
        const sw::Vec4 dim{0.55f, 0.75f, 0.85f, 0.9f};

        // ---- mode ----------------------------------------------------------------
        const char* mode = m_mapView ? "MAP" : (m_evaMode ? "EVA" : "NAV");
        hudText(std::format("{} {}", mode, m_shipMode || m_mapView ? "" : "CAM LIBRE"), kX,
                y, kLine, main);
        y += kLine * 1.3f;

        // ---- speed (V toggles orbital vs surface-relative) -------------------------
        const sw::WorldVec3 velocity = controlledVelocity();
        const sw::WorldVec3 position =
            m_world.getComponent<TransformComponent>(controlledEntity()).position;
        sw::f64 speed = 0.0;
        if (m_speedSurfaceRelative)
        {
            // Surface velocity of the rotating planet at this position.
            const sw::WorldVec3 surfaceVelocity =
                glm::cross(kTerraAngularVelocity, position);
            speed = glm::length(velocity - surfaceVelocity);
        }
        else
        {
            speed = glm::length(velocity);
        }
        hudText(std::format("SPD {} {:.1f} M/S", m_speedSurfaceRelative ? "SRF" : "ORB",
                            speed),
                kX, y, kLine, main);
        y += kLine * 1.3f;

        // ---- altitude above Terra ---------------------------------------------------
        const sw::f64 altitude = glm::length(position) - kTerraRadius;
        hudText(std::format("ALT {:.1f} KM", altitude / 1000.0), kX, y, kLine, main);
        y += kLine * 1.3f;

        // ---- throttle + warp -----------------------------------------------------------
        const auto& ship = m_world.getComponent<ShipComponent>(m_shipEntity);
        hudText(std::format("THR {:.0f}%  WARP X{:g}", ship.throttle * 100.0f,
                            kWarpLadder[m_warpIndex]),
                kX, y, kLine, dim);
    }

    void StarWorksGame::collectMapTrajectories(const sw::Camera& activeCamera)
    {
        const sw::WorldVec3 cameraPosition = activeCamera.position();
        const sw::f32 markerFactor =
            kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);
        const sw::f64 time = m_simulation.simulatedSeconds();

        auto plotOrbit = [&](const sw::phys::KeplerOrbit& orbit, const sw::Vec4& color) {
            const sw::f64 period = sw::phys::kepler::period(orbit);
            for (sw::u32 sample = 0; sample < kTrajectorySamples; ++sample)
            {
                sw::WorldVec3 point{};
                sw::phys::kepler::evaluate(
                    orbit,
                    time + period * static_cast<sw::f64>(sample) / kTrajectorySamples,
                    point);

                const sw::Vec3 relative = sw::Vec3(point - cameraPosition);
                const sw::f32 scale = glm::length(relative) * markerFactor * 0.22f;
                sw::DrawItem item{};
                item.mesh = &m_meshes[m_markerMeshIndex];
                item.transform = glm::translate(sw::Mat4{1.0f}, relative) *
                                 glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                item.boundsCenter = relative;
                item.boundsRadius = scale;
                item.tint = {color.r, color.g, color.b, 0.85f};
                m_drawItems.push_back(item);
            }
        };

        m_world.forEach<sw::phys::OnRailsComponent, MapMarkerComponent>(
            [&](sw::ecs::Entity, sw::phys::OnRailsComponent& rails,
                MapMarkerComponent& marker) {
                plotOrbit(rails.orbit, marker.color * 0.6f);
            });

        m_world.forEach<TransformComponent, sw::phys::DynamicBodyComponent,
                        MapMarkerComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                sw::phys::DynamicBodyComponent& body, MapMarkerComponent& marker) {
                sw::phys::KeplerOrbit orbit{};
                if (sw::phys::kepler::fromStateVectors(kMuTerra, {0.0, 0.0, 0.0},
                                                       transform.position, body.velocity,
                                                       time, orbit))
                {
                    plotOrbit(orbit, marker.color * 0.6f);
                }
            });
    }

    void StarWorksGame::collectDrawItems(const sw::Camera& activeCamera, bool mapView)
    {
        m_drawItems.clear();
        m_drawItems.reserve(m_world.aliveCount() + 512);

        const sw::f32 alpha = m_physicsLane->alpha();
        const sw::f64 alpha64 = static_cast<sw::f64>(alpha);
        const sw::WorldVec3 cameraPosition = activeCamera.position();

        auto makeTransform = [&](const TransformComponent& transform,
                                 const PreviousTransformComponent& previous,
                                 sw::Vec3& outRelative) {
            const sw::WorldVec3 position =
                glm::mix(previous.position, transform.position, alpha64);
            const sw::Quat rotation = glm::slerp(previous.rotation, transform.rotation, alpha);
            outRelative = sw::Vec3(position - cameraPosition);
            return glm::translate(sw::Mat4{1.0f}, outRelative) * glm::mat4_cast(rotation) *
                   glm::scale(sw::Mat4{1.0f}, sw::Vec3{transform.uniformScale});
        };

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        MeshComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                MeshComponent& mesh) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                m_drawItems.push_back({&m_meshes[mesh.meshIndex], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        m_world.forEach<TransformComponent, PreviousTransformComponent, BoundsComponent,
                        CelestialLodComponent>(
            [&](sw::ecs::Entity, TransformComponent& transform,
                PreviousTransformComponent& previous, BoundsComponent& bounds,
                CelestialLodComponent& lod) {
                sw::Vec3 relative{};
                const sw::Mat4 model = makeTransform(transform, previous, relative);
                const sw::f64 worldRadius = static_cast<sw::f64>(transform.uniformScale);
                const sw::f64 distance =
                    glm::length(transform.position - cameraPosition);
                const sw::u32 level = selectLodLevel(distance, worldRadius);
                m_drawItems.push_back({&m_meshes[lod.meshIndex[level]], model, relative,
                                       bounds.localRadius * transform.uniformScale});
            });

        if (mapView)
        {
            const sw::f32 markerFactor =
                kMarkerScreenFraction * 2.0f * std::tan(activeCamera.verticalFov() * 0.5f);

            m_world.forEach<TransformComponent, BoundsComponent, MapMarkerComponent>(
                [&](sw::ecs::Entity, TransformComponent& transform, BoundsComponent& bounds,
                    MapMarkerComponent& marker) {
                    const sw::WorldVec3 toCamera = cameraPosition - transform.position;
                    const sw::f64 distance = glm::length(toCamera);
                    if (distance < 1.0)
                    {
                        return;
                    }
                    const sw::f64 surfaceOffset =
                        static_cast<sw::f64>(bounds.localRadius * transform.uniformScale) *
                        1.05;
                    const sw::WorldVec3 beaconPosition =
                        transform.position + (toCamera / distance) * surfaceOffset;

                    const sw::f32 scale =
                        static_cast<sw::f32>(glm::length(beaconPosition - cameraPosition)) *
                        markerFactor;
                    const sw::Vec3 relative = sw::Vec3(beaconPosition - cameraPosition);
                    const sw::Mat4 model = glm::translate(sw::Mat4{1.0f}, relative) *
                                           glm::scale(sw::Mat4{1.0f}, sw::Vec3{scale});
                    m_drawItems.push_back(
                        {&m_meshes[m_markerMeshIndex], model, relative, scale, marker.color});
                });

            collectMapTrajectories(activeCamera);
        }

        collectHud();
    }

    void StarWorksGame::onRender()
    {
        const sw::Camera& activeCamera = m_mapView ? m_mapCamera : m_camera;
        collectDrawItems(activeCamera, m_mapView);
        renderer().renderFrame(activeCamera, m_drawItems);
    }
} // namespace game
