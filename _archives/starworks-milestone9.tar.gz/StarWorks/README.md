# StarWorks

An industrial space simulation game — mine, automate, build ships and stations, and grow a civilization that spans a star system. Powered by a bespoke C++20 / Vulkan engine written exclusively for this game.

## Current state — Milestone 9: Save/Load & surface anchoring

`F5` saves, `F9` loads — the whole universe: every entity and component (columns are memcpy'd thanks to the trivially-copyable rule), simulation clocks (on-rails orbits resume to the exact position), factory state mid-production (bitwise deterministic afterwards, unit-tested), warp, camera and EVA state. Saves identify components by stable names with strict version/size checks. And the first SURFACE BASE exists: a mining outpost anchored to Terra's equator in the planet's rotating frame — it rides the rotation and reloads exactly where it was built, the model every future planet/asteroid factory will follow.

## Previously — Milestone 8.5: Flight information & accessibility

A flight HUD (procedural bitmap font, no assets) shows your control mode, speed — `V` toggles orbital vs surface-relative — altitude, throttle and warp factor. The star map now draws every tracked orbit as a dotted Kepler ellipse at real scale. Terra gained an exponential atmosphere (real drag) and a solid surface with friction: descend gently and you land, arrive hard and it's logged as the crash it is. `G` steps out into an EVA capsule that walks on the ground and falls ballistically off it. `Shift`/`Ctrl` ramp the main-engine throttle limiter.

## Previously — Milestone 8: Factory foundations & time warp

The industrial loop is alive: a drill on the asteroid mines iron ore, a station refinery converts it to iron at 90% yield, a depot stores the output — all volume-bounded with real material densities, matter-conserving, running in the Automation/Logistics simulation lanes. Time warp (`,` slower / `.` faster) climbs ×1, ×2, ×5, ×10, ×50, ×100, ×1000, ×10⁴, ×10⁵: during warp everything rides analytic Kepler rails (no integration, exact at any speed), factories keep producing at exactly warped rates thanks to bulk catch-up ticks, and the warp factor is capped by your altitude above the nearest body (auto-downshift included).

## Previously — Milestone 7: Pilotable ship & star map

You now fly. The game boots in the pilot seat of a 50-ton vessel in 400 km orbit: `W/S` main engine (400 kN, F=ma on the dynamic body, on top of real gravity), `A/D` yaw, arrows pitch, `Q/E` roll, `X` kills rotation, chase camera follows the interpolated ship pose; `Tab` switches to the free camera. `M` opens the star map: a top-down system view at REAL scale — Luna sits at its true 384,400 km — with color-coded beacons of constant on-screen size marking Terra, Luna, the station, the asteroid and your ship (mouse wheel zooms from 20,000 km to 1.6M km). The debris belt is gone (it was pure load); the instanced mass-rendering path remains for real content.

Milestone 6 foundations: two-regime physics — distant objects on analytic Kepler rails (never integrated), objects near the player truly simulated under f64 Newtonian gravity at 50 Hz, continuous conversions at the bubble boundary, real GM values.

Milestone 5 foundations: real astronomical scale (f64 world positions, f32 camera-relative rendering), angular-size LOD for celestial bodies, CPU frustum culling + one instanced draw per mesh, RenderStats with CPU timings.

Milestone 3–4 foundations: archetype ECS (SoA storage, generation-checked handles, parallel stage scheduler), multi-rate fixed-step simulation lanes (Physics 50 Hz … World 1 Hz) with pause/time-scale and render interpolation, deferred structural command buffer, CTest suite (20 tests).

Milestone 2 foundations: VMA-backed GPU memory with RAII wrappers and staging uploads, reverse-Z depth buffer, per-frame camera UBO via descriptor sets, procedural primitives (cube/sphere/grid), cgltf-based glTF importer. `--cpu` selects a software Vulkan device (llvmpipe) with zero code differences — the whole engine runs CPU-only today and will use the GPU the moment one is preferred.

Milestone 1 foundations: logging, assertions/error handling, frame clock, GLFW window layer, input snapshots, camera + controller, Vulkan 1.3 (dynamic rendering, synchronization2), swapchain with live resize, build-time GLSL → SPIR-V compilation.

## Requirements

- CMake ≥ 3.24
- A C++20 compiler (Visual Studio 2022 on Windows, GCC 13+/Clang 16+ on Linux)
- The [Vulkan SDK](https://vulkan.lunarg.com/) (headers, loader, glslangValidator, validation layers)
- A GPU + driver supporting Vulkan 1.3

GLFW 3.4 and GLM 1.0.1 are fetched and built automatically by CMake.

## Building (Windows / Visual Studio 2022)

```powershell
cmake --preset windows-msvc
cmake --build --preset windows-debug
build\windows\bin\Debug\StarWorks.exe
```

Or open `build/windows/StarWorks.sln` in Visual Studio and run the `StarWorks` startup project (F5).

## Building (Linux)

```bash
cmake --preset linux-debug
cmake --build --preset linux-debug -j
./build/linux-debug/bin/StarWorks
```

## Running the tests

```powershell
ctest --test-dir build/windows -C Debug --output-on-failure   # Windows
ctest --test-dir build/linux-debug --output-on-failure        # Linux
```

## Controls

**Ship (default mode):** `W`/`S` main engine forward/retro, `A`/`D` yaw, `↑`/`↓` pitch, `Q`/`E` roll, `X` kill rotation, `Shift`/`Ctrl` throttle up/down. `Tab` switches between pilot and free camera. `G` goes EVA (capsule: `W`/`S` walk, `A`/`D` turn — grounded walking, ballistic otherwise). `V` toggles the HUD speed between orbital and surface-relative.

**Free camera:** hold the right mouse button to look around, `WASD` to move, `Q`/`E` down/up, `Shift` to boost, mouse wheel to change speed.

**Star map:** `M` toggles the system view (real scale, beacon markers); mouse wheel zooms.

**Time warp:** `.` faster / `,` slower (×1 → ×100,000, altitude-limited; engines only work at ×1). `Space` pauses. `F5` saves, `F9` loads. `Esc` quits.

## Useful flags

`--frames N` exits after N frames (soak testing); `--log-file path.log` mirrors the log to a file; `--cpu` prefers a software (CPU) Vulkan device over hardware GPUs.

## Repository layout

See `docs/Architecture.md` for the module map, engineering conventions, and the development log.
