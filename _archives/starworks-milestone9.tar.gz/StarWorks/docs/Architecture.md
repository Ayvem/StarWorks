# StarWorks — Engine Architecture

This document is the living reference for the engine's structure and the reasoning behind it. It is updated at every milestone.

## Vision

A single-purpose engine for an industrial space simulation: hundreds of thousands of rendered objects, a multi-rate simulation that never depends on rendering, seamless space-to-planet transitions, and save files with no memory-pointer dependencies. The engine is not a general-purpose product; every design decision is allowed to exploit that.

## Ground rules

Modularity with minimal dependencies; no God objects; strong cohesion inside a module, weak coupling between modules. Game code talks to the engine only through `Engine.hpp` and the `Application` hooks — never to GLFW or Vulkan directly. GLM is quarantined behind `Math/Math.hpp` so a future in-house math library (notably f64 large-world coordinates) is a one-module change.

## Module map

| Module | State | Responsibility |
|---|---|---|
| `Core` | active | types, log, assert, errors, clock, filesystem, Application/main loop |
| `Platform` | active | GLFW window, surface creation, raw event callbacks |
| `Input` | active | keyboard/mouse snapshots (down / just-pressed / just-released) |
| `Math` | active | math façade over GLM; f64 world coordinates (WorldVec3); frustum culling; engine-wide conventions |
| `Scene` | active | camera, free camera controller (scene graph later) |
| `Renderer` | active | Vulkan 1.3 front-end: instance, device, swapchain, pipelines, frame loop |
| `RenderGraph` | planned | pass scheduling, automatic barriers, transient resources |
| `Assets` | active | MeshData/Vertex, procedural primitives, glTF import (cgltf); streaming later |
| `ECS` | active | archetype ECS: generation-checked entity handles, contiguous SoA columns, access-declared systems, parallel stage scheduler |
| `Physics` | active | Kepler on-rails orbits, f64 Newtonian gravity integration, simulation bubble (rails↔dynamic); rigid bodies/docking/assembly later |
| `Simulation` | active | fixed-rate lanes (Physics 50 Hz, Logistics 10, Automation 5, Economy 2, World 1), pause/time-scale, catch-up bounds, interpolation alpha |
| `Resources` | active | resource catalogue with real mass/volume per unit (ores, metals, water, gases) |
| `Factory` | active | volume-bounded inventories, miner/refinery/transfer systems, matter conservation |
| `Space` / `Planet` | planned | star system model, procedural planet surfaces |
| `UI` | active | procedural 5x7 bitmap font + renderer screen-space path (flight HUD); retained UI later |
| `Gameplay` / `Audio` / `Network` | planned | game rules, sound, (much) later multiplayer |
| (game layer) | active | pilotable ship (thrust/RCS via ThrustSystem), chase camera, star-map view with constant-screen-size beacons |
| `Serialization` | active | bounds-checked binary writer/reader (throws on corruption) |
| `Save` | active | schema-named world snapshots, entity index+generation preserved, simulation clocks |
| `Tools` / `Editor` | planned | offline cookers, in-engine inspection |

Dependency direction (only downward):
`Game → {Scene, Renderer, Input, Core} → {Platform, Math, Core}`. `Platform` knows nothing about `Renderer`; `Input` knows nothing about GLFW; `Scene` knows nothing about Vulkan.

## Key decisions & rationale

**Vulkan 1.3 + dynamic rendering + synchronization2, no legacy render passes.** The future RenderGraph will compute image layouts and barriers itself; VkRenderPass objects would fight it. Dynamic rendering removes framebuffer/renderpass lifetime management entirely. Minimum driver requirement is explicit and enforced at device selection.

**Frame model.** 2 frames in flight; per-frame transient command pool (whole-pool reset each frame — cheapest reuse pattern); image-available semaphore + in-flight fence per frame; render-finished semaphores indexed *per swapchain image* (required for correct present semantics when image count > frames in flight).

**Error policy.** Initialization and asset failures throw `sw::Exception` (caught once in `main`). Per-frame code never throws for recoverable states — `VK_ERROR_OUT_OF_DATE_KHR`/`VK_SUBOPTIMAL_KHR` are handled as values. Programmer errors use `SW_ASSERT`.

**Logging.** Static facility with level check before message formatting, category tags, ANSI colors (enabled on Windows via VT processing), optional file sink. Validation-layer output is routed through the same log.

**Coordinates & conventions.** Right-handed, +Y up, -Z forward; radians everywhere; depth [0,1] (`GLM_FORCE_DEPTH_ZERO_TO_ONE`); projection Y-flip done once in `Camera`; geometry authored CCW with `VK_FRONT_FACE_COUNTER_CLOCKWISE` and back-face culling (verified by rendering test). sRGB swapchain: shaders write linear color.

**GPU memory via VMA behind an engine-owned façade.** `VulkanMemory` is the single entry point (device buffers, host-visible mapped buffers, attachment images, staging uploads); RAII wrappers (`VulkanBuffer`/`VulkanImage`) make leaks structurally impossible. VMA/cgltf implementations live in dedicated warning-silenced TUs; engine code keeps the full warning set.

**Reverse-Z depth.** Projection maps near→1, far→0 (`glm::perspective` with swapped planes), depth clear is 0.0, comparisons are `GREATER_OR_EQUAL`. This is the only depth scheme that keeps f32 precision at planetary/orbital distances; adopted before any content existed so nothing ever depends on standard-Z.

**CPU/GPU device choice is a config bit, not an architecture.** `--cpu` (RendererConfig::preferCpuDevice) inverts the device-type scoring so a software implementation (llvmpipe/SwiftShader) wins; every rendering feature runs identically on both. CI runs the engine on CPU; players run the same binary on hardware.

**ECS design.** Archetype-based: entities with identical component sets share one archetype whose components live in contiguous per-type byte columns (SoA) — queries are linear walks of packed arrays. Entity handles are index+generation (stale handles detected, no pointers, serializable as-is). Components must be trivially copyable/destructible and ≤16-byte aligned (compile-time enforced): rows migrate with `memcpy`, columns never run constructors, and component memory is directly serializable — non-trivial data belongs in assets or ID-referenced side tables. Signatures are 64-bit masks (cheap compare/hash; limit is one static_assert away from widening). Row removal is swap-remove O(1).

**System parallelism by declaration, not by luck.** Every system declares read/write component masks; the scheduler builds order-preserving stages where no two systems conflict (write-write or read-write), then runs each stage's systems concurrently on the Core ThreadPool. Determinism holds regardless of thread timing because concurrent systems have disjoint access by construction. Structural changes (create/destroy/add/remove) are owner-thread only — deferred command buffers arrive with the Simulation milestone.

**Real astronomical scale via f64 world + f32 camera-relative rendering.** The game world uses REAL dimensions (Terra 6,371 km radius, Luna at 384,400 km). f32 breaks at that scale (~0.5 m ULP at Earth radius), so all world POSITIONS are `WorldVec3` (f64): ECS transforms, orbits, the camera. The GPU only ever sees f32 *camera-relative* values: positions are subtracted from the camera position in f64, then narrowed — precision is highest exactly where the player looks. The view matrix carries rotation only. Combined with reverse-Z, near=0.5 m and far=1e9 m coexist in one frame.

**Distance-based LOD for celestial bodies.** A body's LOD level derives from its ANGULAR diameter relative to the FOV (5 sphere levels, 64×96 down to 6×9). A moon at true distance costs a few dozen triangles; the planet you orbit gets full silhouette geometry; nothing ever renders surface detail from far away. The Planet module's quadtree terrain will later replace level 0 near the ground, behind the same component.

**Mass rendering: cull, then instance.** Frame flow: game submits `DrawItem`s (mesh + camera-relative transform + bounding sphere) → CPU frustum culling (6 planes extracted from the actual VP matrix, so reverse-Z/Y-flip are automatic; unit-tested at planet-scale radii) → survivors sorted by mesh → transforms written to a per-frame storage buffer → ONE `vkCmdDrawIndexed` per distinct mesh, vertex shader indexes the SSBO via `gl_InstanceIndex`. 12k+ submitted items cost 0.1–0.2 ms of prepare (release build). `RenderStats` exposes submitted/culled/instances/draw-calls plus CPU timings (fence wait, prepare, total) — measured, not guessed.

**Two-regime physics: simulate only what is near the player.** Every distant object is ON RAILS: it stores nothing but Kepler orbital elements (with a precomputed perifocal basis), and its position is a closed-form function of time — no integration, no drift, evaluated at 10 Hz by the RailsSystem (and skippable entirely when invisible). Only objects inside the simulation bubble around the camera (10 km enter / 15 km exit hysteresis) carry a DynamicBody and get true f64 Newtonian gravity, integrated with symplectic (semi-implicit) Euler at 50 Hz. The BubbleSystem converts between regimes with position/velocity continuity in both directions (state vectors from elements on entry, elements from state vectors on exit; unbound trajectories stay dynamic), via the deferred command buffer. Per-tick cost therefore scales with the bubble population (~hundreds), not the world population (tens of thousands) — the architecture that lets a whole star system exist at once.

**Time warp = rails + bulk catch-up + altitude limits.** The warp ladder (×1 … ×100,000) is a Simulation time scale plus two guarantees. First, warping forces EVERYTHING onto rails (BubbleSystem force-rails): analytic orbits are exact at any speed while numerical integration is not, so integration simply doesn't run above ×1 (thrust is disabled — you burn at ×1, you coast at warp). Second, rate-based lanes (Logistics/Automation/Economy/World) use *bulk catch-up*: backlog beyond their tick bound is consumed in one big-dt tick — exact for `amount = rate × dt` systems, so factories produce precisely warp-scaled output; the Physics lane instead keeps strict fixed steps and drops backlog. Warp is capped by the controlled ship's altitude above the nearest body (e.g. ×100 at 400 km LEO) with automatic downshift on approach — warping hard near a planet is how you tunnel through it.

**Factories move real matter.** Inventories are bounded by VOLUME with real densities (1 m³ holds 2,500 units of ore but 7,870 of iron); refineries reserve output space before consuming input, so a full tank stalls the machine and matter is conserved by construction (unit-tested end-to-end across the real simulation lanes). Machine graphs use entity links (`ItemLinkComponent`) — the pull-based abstraction that real conveyor entities will later implement.

**Saves: stable names, exact identities, strict failures.** Component columns are written under STABLE string names registered in a `save::Schema` (never runtime type ids — those depend on registration order). Loading restores entity indices AND generations exactly, so entity references inside components (factory links, surface anchors) survive untouched — the day-one "no pointers in components" rule exists for this moment. Trivially-copyable columns memcpy in and out; the free list is rebuilt canonically so entity creation stays deterministic after a load; unknown names or size/version mismatches abort with precise errors (migrations later, silent reinterpretation never). Simulation clocks (master time, per-lane tick counts and accumulators) are part of the snapshot: on-rails orbits — pure functions of time — resume to the exact millimeter. Round-trip factory determinism is asserted bitwise in tests.

**Surface bases live in their body's rotating frame.** Factories built on planets or asteroids carry a `SurfaceAnchorComponent` (parent body entity + body-fixed local position); the `SurfaceAnchorSystem` recomputes their world pose from the body's current rotation each tick. Saving stores the ANCHOR, not a world position — the planet may rotate arbitrarily far, the base reloads exactly where it was built. This is the foundation every surface factory will stand on.

**Simulation never driven by rendering.** The frame loop feeds wall-clock time into `Simulation::advance`; each lane accumulates it and runs zero or more ticks with its *exact* fixed step (systems always see 1/Hz seconds — time scale changes tick count, never tick size). Tick counts are provably independent of frame slicing (unit-tested). Catch-up per frame is bounded per lane; excess backlog is dropped with a throttled warning instead of spiraling. Pause simply stops feeding time — the renderer keeps running. Rendering reads simulation state through interpolation: `PreviousTransform` is snapshotted at the start of each Physics tick and the render list lerps/slerps with `lane.alpha()`.

**Deferred structural changes.** Systems must not create/destroy entities or add/remove components while stages run in parallel; they record into a thread-safe `EntityCommandBuffer` and the owner thread plays it back at a defined point. Commands on entities that died before playback are skipped (standard deferred-destruction semantics).

**Unit tests from Milestone 3 onward.** `StarWorksTests` (in-house harness, CTest-integrated, no window/GPU needed) covers entity lifetime/generations, archetype migration, swap-remove integrity, query semantics, a 10k-entity stress test, ThreadPool completeness and scheduler staging/parallel correctness. Every future engine module ships with tests.

**Explicit source lists in CMake** (no GLOB): adding a file is a deliberate, reviewable act.

**`--frames N` headless soak mode** from day one, so every milestone can be smoke-tested in CI without a human.

## Development log

### Milestone 1 — Bootstrap (done)
Window + main loop + logging + error handling + clock + input + free camera + Vulkan 1.3 init (instance/validation, device selection & scoring, swapchain + live resize/minimize handling, graphics pipeline with push constants) + first triangle via build-time-compiled GLSL.

### Milestone 2 — GPU memory & geometry (done)
VMA-backed memory layer (`VulkanMemory` + RAII buffer/image wrappers, staging uploads), depth buffer with reverse-Z, vertex input pipeline (position/normal/color/uv), per-frame camera UBO through descriptor sets, model matrix via push constants, Lambert+ambient shading, procedural primitives (cube, UV sphere, grid), glTF import via cgltf (node transforms applied), `Tools/generate_asteroid.py` producing the deterministic test asset, `--cpu` device preference. Verified: 240-frame soak on llvmpipe, screenshot-checked scene (occlusion, lighting, glTF geometry).

### Milestone 3 — ECS core (done)
Archetype ECS (`ECS/`): Entity index+generation, Component registration with signature masks, Archetype SoA columns with swap-remove and memcpy migration, World API (create/destroy/add/remove/get/forEach/count), System + SystemAccess declarations, SystemScheduler with conflict-free parallel stages, Core ThreadPool. Game scene fully migrated to ECS: 150 entities (asteroid, station ring, deterministic debris field) driven by OrbitSystem/SpinSystem through the scheduler; render list collected from a `<Transform, Mesh>` query. Verified: 8 unit tests green (CTest), 240-frame soak at 37 FPS on llvmpipe, screenshot check.

### Milestone 4 — Multi-rate simulation (done)
`Simulation` module: configurable fixed-step lanes with per-lane SystemScheduler, bounded catch-up with backlog dropping, pause and time scale (0–16×), interpolation alpha. `EntityCommandBuffer` for deferred, thread-safe structural changes. Game fully migrated: Snapshot/Orbit/Spin on the Physics lane (50 Hz), DebrisFlow on Logistics (10 Hz), Stats on World (1 Hz); render transforms interpolated (lerp/slerp) between Physics ticks; Space = pause, 1/2/3 = time scale. Verified: 17 unit tests green (exact tick counts on power-of-two lanes, frame-slicing independence, catch-up bound, pause/scale semantics, deferred playback, parallel recording), 300-frame soak at 38 FPS on llvmpipe.

### Milestone 5 — Real scale & mass rendering (done)
f64 world coordinates + camera-relative rendering; angular-size LOD for celestial bodies; CPU frustum culling + per-mesh instancing through a per-frame SSBO; RenderStats with CPU timings. Scene: Terra (6,371 km, real sidereal spin) + Luna (1,737 km at 384,400 km) + 12,000-object debris belt in 400 km LEO at true orbital angular velocity. Verified: 20 unit tests green (incl. frustum at planet-scale radii), release soak at 27 FPS on a 2-core llvmpipe container (culling 12k items in 0.15 ms; cost dominated by software rasterization of the full-screen planet). Debugging note: a "progressive slowdown" turned out to be a Clock FPS-smoothing artifact (EMA seeded by the meaningless first-frame delta) — fixed and the lesson kept: never trust a smoothed metric without a raw counterpart.

### Milestone 6 — Two-regime Newtonian physics (done)
Physics module: `KeplerOrbit` (fromElements / fromStateVectors / evaluate, Y-up convention, Newton-solved Kepler equation, precomputed perifocal basis), `GravityIntegrationSystem` (symplectic Euler, multiple point-mass sources with real GM values), `RailsSystem` (10 Hz analytic refresh), `SimulationBubbleSystem` (hysteresis, continuous rails↔dynamic conversion through the command buffer). TransformComponents promoted to the engine. Game: debris belt on real orbital elements (a/e/i/Ω/ω), asteroid as a true dynamic body held in orbit by gravity alone, per-tick work restricted to bubble contents (Snapshot/Spin require DynamicBody). Verified: 25 unit tests green (circular geometry & period, element↔state round-trip, unbound rejection, 100 s integrator energy/radius drift < 0.05%, bubble conversion continuity both ways); release soak shows live regime migration (284 dynamic → 0 as the belt leaves the bubble) at stable FPS.

### Milestone 7 — Pilotable ship & star map (done)
Debris belt removed (performance request — the mass-rendering path stays, ready for real content). Player ship: compound mesh assembled from box primitives (`PrimitiveFactory::makeBox`/`append`), `ThrustSystem` in the Physics lane applying F=ma main thrust and RCS attitude control (body-frame angular velocity, kill-rotation) on top of gravity; chase camera follows the interpolated ship pose; Tab toggles pilot/free camera (with pose hand-off); bubble focus follows the ship. Star map (M): top-down system camera at REAL scale (Luna at its true 384,400 km), wheel zoom (20,000 km → 1.6M km height), and octahedron beacons on marked entities whose scale grows with distance for constant on-screen size, lifted off surfaces so planets don't occlude their own marker. Renderer gained per-instance color tint (InstanceData mat4+vec4). App now boots in the pilot seat: a static camera would watch the whole scene recede at 7.7 km/s of orbital velocity. Verified: 28 unit tests green, release soak with live regime migration, screenshot checks of both views.

### Milestone 8 — Factory foundations & time warp (done)
Resources module (real mass/volume catalogue), Factory module (volume-bounded inventories, MinerSystem/RefinerySystem in the Automation lane, TransferSystem links in Logistics), first production chain live: asteroid drill → station refinery (90% yield) → storage depot. Time warp ladder ×1–×100,000 (`,`/`.`): rails-only above ×1 (bubble force-rails), bulk catch-up for rate-based lanes (warp-exact production), altitude-capped with auto-downshift. Also fixed a real Input defect the warp tests exposed: sub-frame key taps (press+release within one frame) were lost — press events are now latched. Verified: 32 unit tests green (inventory bounds, refinery conservation/stall, full chain through real lanes, bulk catch-up exactness, force-rails conversions), release soak climbing the ladder to the ×100 altitude cap with warp-scaled factory output in the logs.

### Milestone 8.5 — Flight information & accessibility (done)
HUD through a new renderer screen-space path (`DrawItem::screenSpace`: NDC transforms, unlit, alpha-blended, no depth, drawn after the world in the same dynamic-rendering pass) fed by a dependency-free procedural 5x7 bitmap font (`UI/HudFont`, one mesh per glyph, one instanced item per character). Readouts: control mode, speed with `V` toggling ORBital vs SuRFace-relative (planet-rotation aware), altitude, throttle, warp. Star map draws sampled Kepler ellipses as dotted trajectories for every marked object (dynamic bodies via fromStateVectors), default zoom framing LEO. `SurfaceInteractionSystem` (engine): exponential-density quadratic drag inside atmospheres, solid body surfaces with position clamping, impact classification (crash > 8 m/s vertical), tangential friction to rest, `isGrounded` flag (surface co-rotation deliberately deferred). EVA (`G`): capsule (new `makeCapsule` primitive) spawned co-moving beside the ship, kept upright along the local vertical, walks on the ground when grounded. Ship throttle limiter ramped by Shift/Ctrl, applied by ThrustSystem. Input hardening: sub-frame key taps latched (found by injected-input testing). Verified: 35 unit tests green (drag/landing/rest, capsule and glyph geometry), screenshot checks of HUD, map trajectories and EVA.

### Milestone 9 — Save/Load & surface anchoring (done)
Serialization module (bounds-checked binary writer/reader), Save module (schema-named world snapshots with exact entity identity restoration, simulation clock persistence), `SurfaceAnchorComponent`/`SurfaceAnchorSystem` (body-frame attachment for surface factories — co-rotation with the planet, save-proof by construction), ground mining outpost on Terra's equator as the first surface base. In-game: `F5` save / `F9` load (world + simulation + player state incl. warp, camera, EVA). ECS gained a documented serialization-support API (column introspection, exact-identity restore, canonical free list). Verified: 39 unit tests green — including BITWISE factory determinism after a mid-production save/load and anchor persistence across snapshots — plus a live in-game save → warp ×10 → load cycle returning to the exact saved second.

### Milestone 10 — Space module & Kepler-driven celestials (next)
Star system description (bodies with orbits of their own — Luna actually orbiting Terra), moving gravity-source frames for rails/anchors, star map body trails, groundwork for multi-system worlds.
