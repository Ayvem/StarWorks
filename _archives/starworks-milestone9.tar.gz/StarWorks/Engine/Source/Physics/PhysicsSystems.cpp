#include "Physics/PhysicsSystems.hpp"

#include "Core/Log.hpp"
#include "ECS/World.hpp"
#include "Simulation/Simulation.hpp"

#include <algorithm>
#include <cmath>

namespace sw::phys
{
    // ------------------------------------------------------------------------
    // GravityIntegrationSystem
    // ------------------------------------------------------------------------
    void GravityIntegrationSystem::update(ecs::World& world, f32 deltaSeconds)
    {
        // Collect gravity sources (a handful of celestial bodies).
        m_sources.clear();
        world.forEach<TransformComponent, GravitySourceComponent>(
            [this](ecs::Entity, TransformComponent& transform,
                   GravitySourceComponent& source) {
                m_sources.push_back({transform.position, source.mu});
            });

        const f64 dt = static_cast<f64>(deltaSeconds);

        // Semi-implicit (symplectic) Euler: v then p — stable for orbits.
        world.forEach<TransformComponent, DynamicBodyComponent>(
            [this, dt](ecs::Entity, TransformComponent& transform,
                       DynamicBodyComponent& body) {
                WorldVec3 acceleration{0.0};
                for (const Source& source : m_sources)
                {
                    const WorldVec3 toSource = source.position - transform.position;
                    const f64 distanceSq = glm::dot(toSource, toSource);
                    if (distanceSq > 1.0)
                    {
                        const f64 distance = std::sqrt(distanceSq);
                        acceleration += toSource * (source.mu / (distanceSq * distance));
                    }
                }
                body.velocity += acceleration * dt;
                transform.position += body.velocity * dt;
            });
    }

    // ------------------------------------------------------------------------
    // SurfaceAnchorSystem
    // ------------------------------------------------------------------------
    void SurfaceAnchorSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        world.forEach<TransformComponent, PreviousTransformComponent,
                      SurfaceAnchorComponent>(
            [&world](ecs::Entity, TransformComponent& transform,
                     PreviousTransformComponent& previous,
                     SurfaceAnchorComponent& anchor) {
                const auto* body =
                    world.tryGetComponent<TransformComponent>(anchor.body);
                if (body == nullptr)
                {
                    return; // body destroyed: anchor idles (structure floats)
                }

                // Rotate the body-fixed local position into world space in
                // f64 (planet-radius offsets need the precision).
                const glm::dquat bodyRotation{body->rotation};
                transform.position = body->position + bodyRotation * anchor.localPosition;
                transform.rotation = body->rotation;
                previous.position = transform.position;
                previous.rotation = transform.rotation;
            });
    }

    // ------------------------------------------------------------------------
    // SurfaceInteractionSystem
    // ------------------------------------------------------------------------
    void SurfaceInteractionSystem::update(ecs::World& world, f32 deltaSeconds)
    {
        const f64 dt = static_cast<f64>(deltaSeconds);

        m_surfaces.clear();
        world.forEach<TransformComponent, GravitySourceComponent>(
            [this, &world](ecs::Entity entity, TransformComponent& transform,
                           GravitySourceComponent& source) {
                if (source.bodyRadius <= 0.0)
                {
                    return;
                }
                Surface surface{transform.position, source.bodyRadius, false, {}};
                if (const auto* atmosphere =
                        world.tryGetComponent<AtmosphereComponent>(entity))
                {
                    surface.hasAtmosphere = true;
                    surface.atmosphere = *atmosphere;
                }
                m_surfaces.push_back(surface);
            });

        world.forEach<TransformComponent, DynamicBodyComponent>(
            [this, dt](ecs::Entity, TransformComponent& transform,
                       DynamicBodyComponent& body) {
                body.isGrounded = 0;

                for (const Surface& surface : m_surfaces)
                {
                    const WorldVec3 radial = transform.position - surface.center;
                    const f64 distance = glm::length(radial);
                    if (distance <= 1.0)
                    {
                        continue; // degenerate (the body itself)
                    }
                    const WorldVec3 up = radial / distance;
                    const f64 altitude = distance - surface.radius;

                    // ---- atmosphere: quadratic drag, exponential density --
                    if (surface.hasAtmosphere &&
                        altitude < surface.atmosphere.topAltitude)
                    {
                        const f64 density =
                            surface.atmosphere.surfaceDensity *
                            std::exp(-std::max(altitude, 0.0) /
                                     surface.atmosphere.scaleHeight);
                        const f64 speed = glm::length(body.velocity);
                        if (speed > 1.0e-6)
                        {
                            const f64 deceleration = 0.5 * density * speed * speed *
                                                     body.ballisticFactor;
                            // Never reverse the velocity within one step.
                            const f64 dv = std::min(deceleration * dt, speed);
                            body.velocity -= (body.velocity / speed) * dv;
                        }
                    }

                    // ---- solid ground -------------------------------------
                    if (altitude <= 0.0)
                    {
                        transform.position = surface.center + up * surface.radius;

                        const f64 radialSpeed = glm::dot(body.velocity, up);
                        if (radialSpeed < 0.0)
                        {
                            if (-radialSpeed > m_config.crashSpeedThreshold)
                            {
                                SW_LOG_WARN("Physics",
                                            "Surface impact at {:.1f} m/s — that was a "
                                            "crash, not a landing",
                                            -radialSpeed);
                            }
                            else if (-radialSpeed > 0.5)
                            {
                                SW_LOG_INFO("Physics", "Touchdown at {:.1f} m/s",
                                            -radialSpeed);
                            }
                            body.velocity -= up * radialSpeed; // absorb impact
                        }

                        // Tangential friction until rest.
                        const f64 decay = std::max(
                            0.0, 1.0 - m_config.groundFrictionPerSecond * dt);
                        body.velocity *= decay;
                        body.isGrounded = 1;
                    }
                }
            });
    }

    // ------------------------------------------------------------------------
    // RailsSystem
    // ------------------------------------------------------------------------
    void RailsSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        const f64 time = m_simulation.simulatedSeconds();

        world.forEach<TransformComponent, PreviousTransformComponent, OnRailsComponent>(
            [time](ecs::Entity, TransformComponent& transform,
                   PreviousTransformComponent& previous, OnRailsComponent& rails) {
                WorldVec3 position{};
                kepler::evaluate(rails.orbit, time, position);
                transform.position = position;
                // No interpolation for rails objects: they are distant by
                // definition, and mirroring avoids a stale-previous sweep.
                previous.position = position;
                previous.rotation = transform.rotation;
            });
    }

    // ------------------------------------------------------------------------
    // SimulationBubbleSystem
    // ------------------------------------------------------------------------
    SimulationBubbleSystem::SimulationBubbleSystem(ecs::EntityCommandBuffer& commands,
                                                   const sim::Simulation& simulation,
                                                   const Config& config)
        : m_commands(commands)
        , m_simulation(simulation)
        , m_config(config)
    {
        SW_ASSERT(m_config.exitRadius > m_config.enterRadius,
                  "Bubble hysteresis requires exitRadius ({}) > enterRadius ({})",
                  m_config.exitRadius, m_config.enterRadius);
    }

    void SimulationBubbleSystem::update(ecs::World& world, f32 /*deltaSeconds*/)
    {
        const f64 time = m_simulation.simulatedSeconds();
        const WorldVec3 focus = m_focus;

        // Cache the dominant gravity source (largest mu) for conversions.
        m_primaryMu = 0.0;
        world.forEach<TransformComponent, GravitySourceComponent>(
            [this](ecs::Entity, TransformComponent& transform,
                   GravitySourceComponent& source) {
                if (source.mu > m_primaryMu)
                {
                    m_primaryMu = source.mu;
                    m_primaryCenter = transform.position;
                }
            });
        if (m_primaryMu <= 0.0)
        {
            return; // no gravity source: nothing to convert against
        }

        const f64 enterSq = m_config.enterRadius * m_config.enterRadius;
        const f64 exitSq = m_config.exitRadius * m_config.exitRadius;
        const bool forceRails = m_forceRails;

        // ---- rails -> dynamic (entering the bubble) --------------------------
        world.forEach<TransformComponent, OnRailsComponent>(
            [&](ecs::Entity entity, TransformComponent& transform, OnRailsComponent& rails) {
                if (forceRails)
                {
                    return; // warp: nothing leaves the rails
                }
                const WorldVec3 delta = transform.position - focus;
                if (glm::dot(delta, delta) >= enterSq)
                {
                    return;
                }

                // Exact state vectors at conversion time: the hand-off is
                // continuous in both position and velocity.
                WorldVec3 position{};
                WorldVec3 velocity{};
                kepler::evaluate(rails.orbit, time, position, &velocity);

                m_commands.defer([entity, position, velocity](ecs::World& w) {
                    if (!w.isAlive(entity) ||
                        !w.hasComponent<OnRailsComponent>(entity))
                    {
                        return;
                    }
                    auto& t = w.getComponent<TransformComponent>(entity);
                    t.position = position;
                    if (auto* prev = w.tryGetComponent<PreviousTransformComponent>(entity))
                    {
                        prev->position = position;
                        prev->rotation = t.rotation;
                    }
                    w.removeComponent<OnRailsComponent>(entity);
                    w.addComponent(entity, DynamicBodyComponent{velocity, 1000.0});
                });
            });

        // ---- dynamic -> rails (leaving the bubble) -----------------------------
        const WorldVec3 primaryCenter = m_primaryCenter;
        const f64 primaryMu = m_primaryMu;
        world.forEach<TransformComponent, DynamicBodyComponent>(
            [&](ecs::Entity entity, TransformComponent& transform,
                DynamicBodyComponent& body) {
                // Gravity sources themselves are never bubble-managed.
                if (world.hasComponent<GravitySourceComponent>(entity))
                {
                    return;
                }
                const WorldVec3 delta = transform.position - focus;
                // Warp railifies EVERYTHING; otherwise only bubble leavers.
                if (!forceRails && glm::dot(delta, delta) <= exitSq)
                {
                    return;
                }

                KeplerOrbit orbit{};
                if (!kepler::fromStateVectors(primaryMu, primaryCenter, transform.position,
                                              body.velocity, time, orbit))
                {
                    return; // unbound trajectory: keep it truly simulated
                }

                m_commands.defer([entity, orbit](ecs::World& w) {
                    if (!w.isAlive(entity) ||
                        !w.hasComponent<DynamicBodyComponent>(entity))
                    {
                        return;
                    }
                    w.removeComponent<DynamicBodyComponent>(entity);
                    w.addComponent(entity, OnRailsComponent{orbit});
                });
            });
    }
} // namespace sw::phys
