#pragma once

// ============================================================================
// Physics/PhysicsComponents.hpp
// The two mutually exclusive motion regimes of the engine:
//
//  - DynamicBodyComponent : TRULY simulated. Newtonian gravity integrated
//    every Physics tick (50 Hz). Reserved for objects near the player —
//    the BubbleSystem enforces this.
//  - OnRailsComponent     : analytic Kepler orbit. No integration ever; the
//    RailsSystem refreshes the transform at low frequency from the closed-
//    form solution. This is the default state of every distant object.
//
//  - GravitySourceComponent marks celestial bodies that generate gravity.
// ============================================================================

#include "Physics/Kepler.hpp"

namespace sw::phys
{
    struct DynamicBodyComponent
    {
        WorldVec3 velocity{0.0}; // m/s, world frame
        f64 mass = 1000.0;       // kg (used by thrust; gravity is mass-free)
        /// Effective drag coefficient x area / mass (m^2/kg): atmosphere
        /// deceleration = 0.5 * rho * v^2 * ballistic. ~0.002 for a ship.
        f64 ballisticFactor = 0.002;
        /// Set by SurfaceInteractionSystem while resting on a body surface.
        u32 isGrounded = 0;
    };

    struct OnRailsComponent
    {
        KeplerOrbit orbit{};
    };

    struct GravitySourceComponent
    {
        f64 mu = 0.0;         // GM, m^3/s^2
        f64 bodyRadius = 0.0; // meters — solid surface + altitude rules
    };

    /// Rigidly attaches an entity to a celestial body's SURFACE: the local
    /// position is expressed in the body's rotating frame, so anchored
    /// structures (mines, factories, launch pads) co-rotate with the planet
    /// or asteroid they are built on. This — not absolute coordinates — is
    /// what makes surface bases save/load-proof: the body may have rotated
    /// arbitrarily far while the game was closed, the base stays exactly
    /// where it was built.
    struct SurfaceAnchorComponent
    {
        ecs::Entity body{};          // the gravity source this is built on
        WorldVec3 localPosition{0.0}; // body-fixed frame, meters
    };

    /// Optional exponential atmosphere around a gravity source.
    struct AtmosphereComponent
    {
        f64 surfaceDensity = 1.225; // kg/m^3 at altitude 0 (Earth-like)
        f64 scaleHeight = 8500.0;   // meters (density /e per scale height)
        f64 topAltitude = 1.4e5;    // no drag above this altitude
    };

    static_assert(std::is_trivially_copyable_v<DynamicBodyComponent>);
    static_assert(std::is_trivially_copyable_v<OnRailsComponent>);
    static_assert(std::is_trivially_copyable_v<GravitySourceComponent>);
    static_assert(std::is_trivially_copyable_v<AtmosphereComponent>);
    static_assert(std::is_trivially_copyable_v<SurfaceAnchorComponent>);
} // namespace sw::phys
