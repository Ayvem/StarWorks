#pragma once

// ============================================================================
// Physics/PhysicsSystems.hpp
// Engine systems implementing the two-regime physics architecture.
//
//  GravityIntegrationSystem (Physics lane, 50 Hz)
//      Semi-implicit Euler in f64 over every DynamicBody: only the handful
//      of objects inside the simulation bubble ever pay this cost.
//
//  RailsSystem (Logistics lane, 10 Hz)
//      Writes the CURRENT analytic position of every on-rails object into
//      its transform (Previous == current: rails objects are far away and
//      need no interpolation). 10 Hz for thousands of objects costs
//      milliseconds per second — this is the "not really simulated" tier.
//
//  SimulationBubbleSystem (Logistics lane, after RailsSystem)
//      Classifies objects by distance to the focus (the player/camera):
//      rails objects entering the bubble become dynamic (state vectors from
//      the analytic orbit — position/velocity continuous); dynamic objects
//      leaving it are converted back to rails (elements from state vectors).
//      Hysteresis (exit > enter radius) prevents churn at the boundary.
//      Conversions are structural, so they go through the command buffer
//      and apply at the owner thread's playback point.
// ============================================================================

#include "ECS/CommandBuffer.hpp"
#include "ECS/System.hpp"
#include "Physics/PhysicsComponents.hpp"
#include "Scene/TransformComponents.hpp"

#include <vector>

namespace sw::sim
{
    class Simulation;
} // namespace sw::sim

namespace sw::phys
{
    class GravityIntegrationSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "GravityIntegrationSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<DynamicBodyComponent>()
                .read<GravitySourceComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        struct Source
        {
            WorldVec3 position;
            f64 mu;
        };
        std::vector<Source> m_sources; // scratch, rebuilt each tick
    };

    /// Keeps surface-anchored entities glued to their (rotating) body:
    /// world position = body position + body rotation * local position.
    /// Runs after the celestial spin update. Previous mirrors current
    /// (anchored structures don't interpolate — the spin is imperceptible
    /// per frame). Anchored entities must NOT also be DynamicBody/OnRails.
    class SurfaceAnchorSystem final : public ecs::System
    {
    public:
        [[nodiscard]] std::string_view name() const override
        {
            return "SurfaceAnchorSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<SurfaceAnchorComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;
    };

    /// Atmosphere drag + solid ground (Physics lane, after gravity/thrust).
    ///
    ///  - Drag: quadratic, exponential density profile, applied inside a
    ///    body's atmosphere; deceleration never reverses the velocity.
    ///  - Ground: the body surface is solid. Bodies below it are clamped to
    ///    the surface, inward radial velocity is absorbed (a hard impact is
    ///    logged as a crash, a gentle one as a landing) and tangential
    ///    velocity decays under friction until the object rests. Sets
    ///    DynamicBody::isGrounded for movement/controller code.
    ///
    /// Current simplification (documented): the surface does not co-rotate
    /// with the body's spin — friction stops objects in the inertial frame.
    class SurfaceInteractionSystem final : public ecs::System
    {
    public:
        struct Config
        {
            f64 crashSpeedThreshold = 8.0; // m/s vertical: crash vs landing
            f64 groundFrictionPerSecond = 2.5;
        };

        explicit SurfaceInteractionSystem(const Config& config) : m_config(config) {}

        [[nodiscard]] std::string_view name() const override
        {
            return "SurfaceInteractionSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<DynamicBodyComponent>()
                .read<GravitySourceComponent>()
                .read<AtmosphereComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        struct Surface
        {
            WorldVec3 center;
            f64 radius;
            bool hasAtmosphere;
            AtmosphereComponent atmosphere;
        };

        Config m_config;
        std::vector<Surface> m_surfaces; // scratch, rebuilt each tick
    };

    class RailsSystem final : public ecs::System
    {
    public:
        /// Reads the simulation clock for the analytic evaluation time.
        explicit RailsSystem(const sim::Simulation& simulation)
            : m_simulation(simulation)
        {
        }

        [[nodiscard]] std::string_view name() const override { return "RailsSystem"; }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            return ecs::SystemAccess{}
                .write<TransformComponent>()
                .write<PreviousTransformComponent>()
                .read<OnRailsComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        const sim::Simulation& m_simulation;
    };

    class SimulationBubbleSystem final : public ecs::System
    {
    public:
        struct Config
        {
            f64 enterRadius = 1.0e4; // rails -> dynamic below this distance
            f64 exitRadius = 1.5e4;  // dynamic -> rails beyond this distance
        };

        SimulationBubbleSystem(ecs::EntityCommandBuffer& commands,
                               const sim::Simulation& simulation, const Config& config);

        /// World-space focus of the bubble (typically the camera/player).
        void setFocus(const WorldVec3& focus) { m_focus = focus; }

        /// Time-warp mode: while true, NOTHING is truly simulated — every
        /// dynamic body (except gravity sources) is converted to rails and
        /// no rails object may enter the bubble. Analytic orbits are exact
        /// at any time scale; integration is not.
        void setForceRails(bool force) { m_forceRails = force; }
        [[nodiscard]] bool forceRails() const { return m_forceRails; }

        [[nodiscard]] std::string_view name() const override
        {
            return "SimulationBubbleSystem";
        }

        [[nodiscard]] ecs::SystemAccess access() const override
        {
            // Read-only over component data; conversions are deferred
            // through the command buffer.
            return ecs::SystemAccess{}
                .read<TransformComponent>()
                .read<OnRailsComponent>()
                .read<DynamicBodyComponent>()
                .read<GravitySourceComponent>();
        }

        void update(ecs::World& world, f32 deltaSeconds) override;

    private:
        ecs::EntityCommandBuffer& m_commands;
        const sim::Simulation& m_simulation;
        Config m_config;
        WorldVec3 m_focus{0.0};
        bool m_forceRails = false;
        /// Gravity parameters of the dominant source, cached per update for
        /// dynamic->rails conversions.
        WorldVec3 m_primaryCenter{0.0};
        f64 m_primaryMu = 0.0;
    };
} // namespace sw::phys
